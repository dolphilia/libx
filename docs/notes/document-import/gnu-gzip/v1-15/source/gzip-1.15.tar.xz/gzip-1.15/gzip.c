/* gzip (GNU zip) -- compress files with zip algorithm and 'compress' interface

   Copyright (C) 1999, 2001-2002, 2006-2007, 2009-2026 Free Software
   Foundation, Inc.
   Copyright (C) 1992-1993 Jean-loup Gailly

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 3, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/*
 * The unzip code was written and put in the public domain by Mark Adler.
 * Portions of the lzw code are derived from the public domain 'compress'
 * written by Spencer Thomas, Joe Orost, James Woods, Jim McKie, Steve Davies,
 * Ken Turkowski, Dave Mack and Peter Jannesen.
 *
 * See the license_msg below and the file COPYING for the software license.
 * See the file algorithm.doc for the compression algorithms and file formats.
 */

static char const license_msg[] =
  "%s %s\n"
  "Copyright (C) 2026 Free Software Foundation, Inc.\n"
  "Copyright (C) 1993 Jean-loup Gailly.\n"
  "This is free software.  You may redistribute copies of it under the terms of\n"
  "the GNU General Public License <https://www.gnu.org/licenses/gpl.html>.\n"
  "There is NO WARRANTY, to the extent permitted by law.\n"
  ;

/* Compress files with zip algorithm and 'compress' interface.
 * See help() function below for all options.
 * Outputs:
 *        file.gz:   compressed file with same mode, owner, and utimes
 *     or stdout with -c option or if stdin used as input.
 * If the output file name had to be truncated, the original name is kept
 * in the compressed file.
 * On MSDOS, file.tmp -> file.tmz.
 *
 * Using gz on MSDOS would create too many file name conflicts. For
 * example, foo.txt -> foo.tgz (.tgz must be reserved as shorthand for
 * tar.gz). Similarly, foo.dir and foo.doc would both be mapped to foo.dgz.
 * I also considered 12345678.txt -> 12345txt.gz but this truncates the name
 * too heavily. There is no ideal solution given the MSDOS 8+3 limitation.
 *
 * For the meaning of all compilation flags, see comments in Makefile.in.
 */

#include <config.h>

#include "tailor.h"

#include "gzip.h"
#include "lzw.h"
#include "revision.h"
#include "version.h"

#include <dirname.h>
#include <filename.h>
#include <ignore-value.h>
#include <intprops.h>
#include <stat-time.h>
#include <stdopen.h>
#include <timespec.h>
#include <xalloc.h>
#include <yesno.h>

#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <inttypes.h>
#include <limits.h>
#include <locale.h>
#include <signal.h>
#include <stdcountof.h>
#include <stddef.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#ifndef NO_DIR
# define NO_DIR (!HAVE_FDOPENDIR && !HAVE_OPENDIR)
#endif
#if !NO_DIR
# include <dirent.h>
# include <savedir.h>
#endif

#ifndef NO_UTIME
#  include <utimens.h>
#endif

#ifndef MAX_PATH_LEN
#  define MAX_PATH_LEN   1024 /* max pathname length */
#endif

#ifndef SEEK_END
#  define SEEK_END 2
#endif

#ifdef off_t
  off_t lseek (int fd, off_t offset, int whence);
#endif

#ifndef HAVE_WORKING_O_NOFOLLOW
# define HAVE_WORKING_O_NOFOLLOW 0
#endif

/* Use openat+unlinkat only when they work, i.e., they conform to POSIX.1-2008
   or later.  It's not worth the porting hassle otherwise.  */
#if HAVE_OPENAT && HAVE_UNLINKAT && !defined UNLINK_READONLY_BUG
# define USE_ATFUNCS true
#else
# define USE_ATFUNCS false
#endif

#if !USE_ATFUNCS
static int
gzip_openat (_GL_ATTRIBUTE_MAYBE_UNUSED int fd,
             char const *file, int flags, mode_t mode)
{
  return open (file, flags, mode);
}
# undef openat
# define openat gzip_openat

static int
gzip_unlinkat (_GL_ATTRIBUTE_MAYBE_UNUSED int fd, char const *file, int flags)
{
  int r = unlink (file);

# ifdef UNLINK_READONLY_BUG
  if (r < 0)
    {
      int unlink_errno = errno;
      if (chmod (file, S_IWUSR) < 0)
        {
          errno = unlink_errno;
          return -1;
        }
      r = unlink (file);
    }
# endif

  return r;
}
# undef unlinkat
# define unlinkat gzip_unlinkat
#endif

/* Separator for file name parts (see shorten_name()) */
#ifdef NO_MULTIPLE_DOTS
#  define PART_SEP "-"
#else
#  define PART_SEP "."
#endif

                /* global buffers */

/* With IBM_Z_DFLTCC, DEFLATE COMPRESSION works faster with
   page-aligned input and output buffers, and requires page-aligned
   windows; the alignment requirement is 4096.  On other platforms
   alignment doesn't hurt, and alignment up to 4096 is portable so
   let's do that.  */
#if defined HAVE_C_ALIGNASOF || defined alignas
# define BUFFER_ALIGNED alignas (4096)
#else
# define BUFFER_ALIGNED /**/
#endif
DECLARE(uch BUFFER_ALIGNED, inbuf,  INBUFSIZ +INBUF_EXTRA);
DECLARE(uch BUFFER_ALIGNED, outbuf, OUTBUFSIZ+OUTBUF_EXTRA);
DECLARE(ush, d_buf,  DIST_BUFSIZE);
DECLARE(uch BUFFER_ALIGNED, window, 2L*WSIZE);
#ifndef MAXSEG_64K
    DECLARE(ush, tab_prefix, 1L<<BITS);
#else
    DECLARE(ush, tab_prefix0, 1L<<(BITS-1));
    DECLARE(ush, tab_prefix1, 1L<<(BITS-1));
#endif

                /* local variables */

/* If true, pretend that standard input is a tty.  This option
   is deliberately not documented, and only for testing.  */
static bool presume_input_tty;

/* If true, transfer output data to the output file's storage device
   when supported.  Otherwise, if the system crashes around the time
   gzip is run, the user might lose both input and output data.  See:
   Pillai TS et al.  All file systems are not created equal: on the
   complexity of crafting crash-consistent applications. OSDI'14. 2014:433-48.
   https://www.usenix.org/conference/osdi14/technical-sessions/presentation/pillai */
static bool synchronous;

static int ascii = 0;        /* convert end-of-lines to local OS conventions */
       int to_stdout = 0;    /* output to stdout (-c) */
static int decompress = 0;   /* decompress (-d) */
static int force = 0;        /* don't ask questions, compress links (-f) */
static int keep = 0;         /* keep (don't delete) input files */
static int no_name = -1;     /* don't save or restore the original file name */
static int no_time = -1;     /* don't save or restore the original file time */
static int recursive = 0;    /* recurse through directories (-r) */
static int list = 0;         /* list the file contents (-l) */
#ifndef DEBUG
static
#endif
       int verbose = 0;      /* be verbose (-v) */
       int quiet = 0;        /* be very quiet (-q) */
       int test = 0;         /* test .gz file integrity */
static int foreground = 0;   /* set if program run in foreground */
       char *program_name;   /* program name */
       int maxbits = BITS;   /* max bits per code for LZW */
       int method = DEFLATED;/* compression method */
       int level = 6;        /* compression level */
       int exit_code = OK;   /* program exit code */
       int save_orig_name;   /* set if original name must be saved */
static int last_member;      /* set for .zip and .Z files */
static int part_nb;          /* number of parts in .gz file */
       off_t ifile_size;      /* input file size, -1 for devices (debug only) */
static char *env;            /* contents of GZIP env variable */
static char const *z_suffix; /* default suffix (can be set with --suffix) */
static size_t z_len;         /* strlen(z_suffix) */

/* The original timestamp (modification time).  If the original is
   unknown, TIME_STAMP.tv_nsec is negative.  If the original is
   greater than struct timespec range, TIME_STAMP is the maximal
   struct timespec value; this can happen on hosts with 32-bit signed
   time_t because the gzip format's MTIME is 32-bit unsigned.
   The original cannot be less than struct timespec range.  */
struct timespec time_stamp;

/* The set of signals that are caught.  */
static sigset_t caught_signals;

/* If remove_ofname_fd is nonnegative, close it and call
   unlinkat (remove_ofname_dfd, remove_ofname, 0) on error.  */
static int volatile remove_ofname_fd = -1;
static int volatile remove_ofname_dfd = AT_FDCWD;
static char volatile remove_ofname[MAX_PATH_LEN];

static bool stdin_was_read;

off_t bytes_in;             /* number of input bytes */
off_t bytes_out;            /* number of output bytes */
static off_t total_in;      /* input bytes for all files */
static off_t total_out;     /* Output bytes for all files.  */
char ifname[MAX_PATH_LEN]; /* input file name */
char ofname[MAX_PATH_LEN]; /* output file name */
static char dfname[MAX_PATH_LEN]; /* name of dir containing output file */
static struct stat istat;         /* status for input file */
int  ifd;                  /* input file descriptor */
int  ofd;                  /* output file descriptor */
static int dfd = AT_FDCWD; /* output directory file descriptor */
static int syncdfd = -1;   /* likewise, but for --synchronous */
unsigned insize;           /* valid bytes in inbuf */
unsigned inptr;            /* index of next byte to be processed in inbuf */
unsigned outcnt;           /* bytes in output buffer */
int rsync = 0;             /* make rsyncable chunks */

static int handled_sig[] =
  {
    /* SIGINT must be first, as 'foreground' depends on it.  */
    SIGINT

#ifdef SIGHUP
    , SIGHUP
#endif
#ifdef SIGPIPE
    , SIGPIPE
#endif
#ifdef SIGTERM
    , SIGTERM
#endif
#ifdef SIGXCPU
    , SIGXCPU
#endif
#ifdef SIGXFSZ
    , SIGXFSZ
#endif
  };

/* For long options that have no equivalent short option, use a
   non-character as a pseudo short option, starting with CHAR_MAX + 1.  */
enum
{
  PRESUME_INPUT_TTY_OPTION = CHAR_MAX + 1,
  RSYNCABLE_OPTION,
  SYNCHRONOUS_OPTION,
};

static char const shortopts[] = "ab:cdfhH?klLmMnNqrS:tvVZ123456789";

static const struct option longopts[] =
{
 /* { name  has_arg  *flag  val } */
    {"ascii",      0, NULL, 'a'}, /* ascii text mode */
    {"to-stdout",  0, NULL, 'c'}, /* write output on standard output */
    {"stdout",     0, NULL, 'c'}, /* write output on standard output */
    {"decompress", 0, NULL, 'd'}, /* decompress */
    {"uncompress", 0, NULL, 'd'}, /* decompress */
 /* {"encrypt",    0, NULL, 'e'},    encrypt */
    {"force",      0, NULL, 'f'}, /* force overwrite of output file */
    {"help",       0, NULL, 'h'}, /* give help */
 /* {"pkzip",      0, NULL, 'k'},    force output in pkzip format */
    {"keep",       0, NULL, 'k'}, /* keep (don't delete) input files */
    {"list",       0, NULL, 'l'}, /* list .gz file contents */
    {"license",    0, NULL, 'L'}, /* display software license */
    {"no-name",    0, NULL, 'n'}, /* don't save or restore original name & time */
    {"name",       0, NULL, 'N'}, /* save or restore original name & time */
    {"-presume-input-tty", no_argument, NULL, PRESUME_INPUT_TTY_OPTION},
    {"quiet",      0, NULL, 'q'}, /* quiet mode */
    {"silent",     0, NULL, 'q'}, /* quiet mode */
    {"synchronous",0, NULL, SYNCHRONOUS_OPTION}, /* output data synchronously */
    {"recursive",  0, NULL, 'r'}, /* recurse through directories */
    {"suffix",     1, NULL, 'S'}, /* use given suffix instead of .gz */
    {"test",       0, NULL, 't'}, /* test compressed file integrity */
    {"verbose",    0, NULL, 'v'}, /* verbose mode */
    {"version",    0, NULL, 'V'}, /* display version number */
    {"fast",       0, NULL, '1'}, /* compress faster */
    {"best",       0, NULL, '9'}, /* compress better */
    {"lzw",        0, NULL, 'Z'}, /* make output compatible with old compress */
    {"bits",       1, NULL, 'b'}, /* max number of bits per code (implies -Z) */
    {"rsyncable",  0, NULL, RSYNCABLE_OPTION}, /* make rsync-friendly archive */
    { NULL, 0, NULL, 0 }
};

/* local functions */

_Noreturn static void try_help (void);
static void help (void);
static void license (void);
static void version (void);
static int input_eof (void);
static void treat_stdin (void);
static void treat_file (int parentfd, char *iname);
static int create_outfile (int parentfd);
static char *get_suffix (char *name);
static int  open_input_file (int parentfd, char *iname, struct stat *sbuf);
static void discard_input_bytes (size_t nbytes, unsigned int flags);
static int  make_ofname (void);
static void shorten_name (char *name);
static int get_method (int in, bool first);
static void do_list (int method);
static int  check_ofname (int atfd);
static void copy_stat (struct stat *ifstat);
static void install_signal_handlers (void);
static void remove_output_file (bool);
static void abort_gzip_signal (int);
_Noreturn static void do_exit (int exitcode);
static void finish_out (void);
      int main          (int argc, char **argv);
static int (*work) (int infile, int outfile) = zip; /* function to call */

#if ! NO_DIR
static void treat_dir (int fd, char *dir);
#endif

#define strequ(s1, s2) (strcmp((s1),(s2)) == 0)

static void
putstring (char const *string)
{
  fputs (string, stdout);
}
static void
eputstring (char const *string)
{
  fputs (string, stderr);
}

static void
try_help ()
{
  fprintf (stderr, "Try `%s --help' for more information.\n",
           program_name);
  do_exit (ERROR);
}

/* ======================================================================== */
static void
help ()
{
  static char const help_msg[] =
 "Usage: %s [OPTION]... [FILE]...\n"
 "Compress or uncompress FILEs (by default, compress FILES in-place).\n"
 "\n"
 "Mandatory arguments to long options are mandatory for short options too.\n"
 "\n"
#if O_BINARY
 "  -a, --ascii       ascii text; convert end-of-line using local conventions\n"
#endif
 "  -c, --stdout      write on standard output, keep original files unchanged\n"
 "  -d, --decompress  decompress\n"
/*  -e, --encrypt     encrypt */
 "  -f, --force       force overwrite of output file and compress links\n"
 "  -h, --help        give this help\n"
/*  -k, --pkzip       force output in pkzip format */
 "  -k, --keep        keep (don't delete) input files\n"
 "  -l, --list        list compressed file contents\n"
 "  -L, --license     display software license\n"
#ifdef UNDOCUMENTED
 "  -m                do not save or restore the original modification time\n"
 "  -M, --time        save or restore the original modification time\n"
#endif
 "  -n, --no-name     do not save or restore the original name and timestamp\n"
 "  -N, --name        save or restore the original name and timestamp\n"
 "  -q, --quiet       suppress all warnings\n"
#if ! NO_DIR
 "  -r, --recursive   operate recursively on directories\n"
#endif
 "      --rsyncable   make rsync-friendly archive\n"
 "  -S, --suffix=SUF  use suffix SUF on compressed files\n"
 "      --synchronous synchronous output (safer if system crashes, but slower)\n"
 "  -t, --test        test compressed file integrity\n"
 "  -v, --verbose     verbose mode\n"
 "  -V, --version     display version number\n"
 "  -1, --fast        compress faster\n"
 "  -9, --best        compress better\n"
 "\n"
 "With no FILE, or when FILE is -, read standard input.\n"
 "\n"
 "Report bugs to <bug-gzip@gnu.org>.\n"
    ;

  printf (help_msg, program_name);
}

/* ======================================================================== */
static void
license ()
{
  printf (license_msg, program_name, Version);
}

/* ======================================================================== */
static void
version ()
{
    license ();
    putstring ("\nWritten by Jean-loup Gailly.\n");
}

static void
progerror (char const *string)
{
    fprintf (stderr, "%s: %s: %s\n", program_name,
             string ? quotef (string) : "standard input", strerror (errno));
    exit_code = ERROR;
}

/* ======================================================================== */
int main (int argc, char **argv)
{
    int file_count;     /* number of files to process */
    size_t proglen;     /* length of program_name */
    char **argv_copy;
    int env_argc;
    char **env_argv;

    setlocale (LC_ALL, "");

    EXPAND(argc, argv); /* wild card expansion if necessary */

    program_name = gzip_base_name (argv[0]);
    proglen = strlen (program_name);

    /* Suppress .exe for MSDOS and OS/2: */
    if (4 < proglen && strequ (program_name + proglen - 4, ".exe"))
      program_name[proglen - 4] = '\0';

    /* Add options in GZIP environment variable if there is one */
    argv_copy = argv;
    env = add_envopt (&env_argc, &argv_copy, OPTIONS_VAR);
    env_argv = env ? argv_copy : NULL;
    opterr = !env;

#ifndef GNU_STANDARD
# define GNU_STANDARD 1
#endif
#if !GNU_STANDARD
    /* For compatibility with old compress, use program name as an option.
     * Unless you compile with -DGNU_STANDARD=0, this program will behave as
     * gzip even if it is invoked under the name gunzip or zcat.
     *
     * Systems which do not support links can still use -d or -dc.
     * Ignore an .exe extension for MSDOS and OS/2.
     */
    if (strncmp (program_name, "un",  2) == 0     /* ungzip, uncompress */
        || strncmp (program_name, "gun", 3) == 0) /* gunzip */
        decompress = 1;
    else if (strequ (program_name + 1, "cat")     /* zcat, pcat, gcat */
             || strequ (program_name, "gzcat"))   /* gzcat */
        decompress = to_stdout = 1;
#endif

    z_suffix = Z_SUFFIX;
    z_len = strlen(z_suffix);

    while (true) {
        int optc;

        if (env_argv)
          {
            /* Get the next option taken from the GZIP environment variable
               that affects only performance (including compression level).
               Silently ignore other options, non-options, invalid options,
               and option syntax errors, so that bad GZIP values do
               not unduly interfere with normal gzip operation.  */
            do
              {
                optc = getopt_long (env_argc, env_argv, shortopts, longopts,
                                    NULL);
                if (optc < 0)
                  {
                    /* Start processing ARGC and ARGV instead.  */
                    free (env_argv);
                    env_argv = NULL;
                    opterr = 1;
                    optind = 1;
                    break;
                  }
              }
            while (! (('1' <= optc && optc <= '9')
                      || optc == RSYNCABLE_OPTION
                      || optc == SYNCHRONOUS_OPTION));
          }

        if (!env_argv)
          optc = getopt_long (argc, argv, shortopts, longopts, NULL);
        if (optc < 0)
          break;

        switch (optc) {
        case 'a':
            ascii = 1; break;
        case 'b':
            maxbits = atoi(optarg);
            for (; *optarg; optarg++)
              if (! ('0' <= *optarg && *optarg <= '9'))
                {
                  fprintf (stderr, "%s: -b operand is not an integer\n",
                           program_name);
                  try_help ();
                }
            break;
        case 'c':
            to_stdout = 1; break;
        case 'd':
            decompress = 1; break;
        case 'f':
            force++; break;
        case 'h': case 'H':
            help (); finish_out (); break;
        case 'k':
            keep = 1; break;
        case 'l':
            list = decompress = test = to_stdout = 1; break;
        case 'L':
            license (); finish_out (); break;
        case 'm': /* undocumented, may change later */
            no_time = 1; break;
        case 'M': /* undocumented, may change later */
            no_time = 0; break;
        case 'n':
            no_name = no_time = 1; break;
        case 'N':
            no_name = no_time = 0; break;
        case PRESUME_INPUT_TTY_OPTION:
            presume_input_tty = true; break;
        case 'q':
            quiet = 1; verbose = 0; break;
        case 'r':
#if NO_DIR
            fprintf (stderr, "%s: -r not supported on this system\n",
                     program_name);
            try_help ();
#else
            recursive = 1;
#endif
            break;

        case RSYNCABLE_OPTION:
            rsync = 1;
            break;
        case 'S':
#ifdef NO_MULTIPLE_DOTS
            if (*optarg == '.') optarg++;
#endif
            for (z_len = 0; optarg[z_len]; z_len++)
              if (optarg[z_len] == '/')
                {
                  fprintf (stderr, "%s: suffix contains '/'\n", program_name);
                  do_exit (ERROR);
                }
            z_suffix = optarg;
            break;
        case SYNCHRONOUS_OPTION:
            synchronous = true;
            break;
        case 't':
            test = decompress = to_stdout = 1;
            break;
        case 'v':
            verbose++; quiet = 0; break;
        case 'V':
            version (); finish_out (); break;
        case 'Z':
            fprintf(stderr, "%s: -Z not supported in this version\n",
                    program_name);
            try_help ();
            break;
        case '1':  case '2':  case '3':  case '4':
        case '5':  case '6':  case '7':  case '8':  case '9':
            level = optc - '0';
            break;

        default:
            try_help ();
        }
    } /* loop on all arguments */

    /* By default, save name and timestamp on compression but do not
     * restore them on decompression.
     */
    if (no_time < 0) no_time = decompress;
    if (no_name < 0) no_name = decompress;

    file_count = argc - optind;

#if O_BINARY
#else
    if (ascii && !quiet) {
        fprintf(stderr, "%s: option --ascii ignored on this system\n",
                program_name);
    }
#endif
    if (z_len == 0 || z_len > MAX_SUFFIX) {
        fprintf (stderr, "%s: %s: invalid suffix\n", program_name,
                 quotef (z_suffix));
        do_exit(ERROR);
    }

    /* Allocate all global buffers (for DYN_ALLOC option) */
    ALLOC(uch, inbuf,  INBUFSIZ +INBUF_EXTRA);
    ALLOC(uch, outbuf, OUTBUFSIZ+OUTBUF_EXTRA);
    ALLOC(ush, d_buf,  DIST_BUFSIZE);
    ALLOC(uch, window, 2L*WSIZE);
#ifndef MAXSEG_64K
    ALLOC(ush, tab_prefix, 1L<<BITS);
#else
    ALLOC(ush, tab_prefix0, 1L<<(BITS-1));
    ALLOC(ush, tab_prefix1, 1L<<(BITS-1));
#endif

    int stdopen_err = stdopen ();
    if (stdopen_err)
      {
        fprintf (stdout, "%s: standard file descriptors: %s\n",
                 program_name, strerror (stdopen_err));
        do_exit (ERROR);
      }

    /* And get to work */
    if (file_count != 0) {
        if (to_stdout && !test && (!decompress || !ascii)) {
            SET_BINARY_MODE (STDOUT_FILENO);
        }
        while (optind < argc) {
          treat_file(-1, argv[optind++]);
        }
    } else {  /* Standard input */
        treat_stdin();
    }
    if (stdin_was_read && close (STDIN_FILENO) != 0)
      {
        strcpy (ifname, "stdin");
        read_error ();
      }
    if (list)
      {
        /* Output any totals, and check for output errors.  */
        if (!quiet && 1 < file_count)
          do_list (-1);
        if (fflush (stdout) != 0)
          write_error ();
        if (ferror (stdout))
          write_err (EIO);
      }
    if (to_stdout
        && ((synchronous
             && fdatasync (STDOUT_FILENO) != 0 && errno != EINVAL)
            || close (STDOUT_FILENO) != 0)
        && errno != EBADF)
      write_error ();
    do_exit(exit_code);
}

/* Return nonzero when at end of file on input.  */
static int
input_eof ()
{
  if (!decompress || last_member)
    return 1;

  if (inptr == insize)
    {
      if (insize != INBUFSIZ || fill_inbuf (1) == EOF)
        return 1;

      /* Unget the char that fill_inbuf got.  */
      inptr = 0;
    }

  return 0;
}

static void
get_input_size_and_time (void)
{
  ifile_size = -1;
  time_stamp.tv_nsec = -1;

  /* Record the input file's size and timestamp only if it is a
     regular file.  Doing this for the timestamp helps to keep gzip's
     output more reproducible when it is used as part of a
     pipeline.  */

  if (S_ISREG (istat.st_mode))
    {
      ifile_size = istat.st_size;
      if (!no_time || list)
        time_stamp = get_stat_mtime (&istat);
    }
}

/* ========================================================================
 * Compress or decompress stdin
 */
static void
treat_stdin ()
{
    if (!force && !list
        && (presume_input_tty
            || isatty (decompress ? STDIN_FILENO : STDOUT_FILENO))) {
        /* Do not send compressed data to the terminal or read it from
         * the terminal. We get here when user invoked the program
         * without parameters, so be helpful. According to the GNU standards:
         *
         *   If there is one behavior you think is most useful when the output
         *   is to a terminal, and another that you think is most useful when
         *   the output is a file or a pipe, then it is usually best to make
         *   the default behavior the one that is useful with output to a
         *   terminal, and have an option for the other behavior.
         *
         * Here we use the --force option to get the other behavior.
         */
        if (! quiet)
          fprintf (stderr,
                   ("%s: compressed data not %s a terminal."
                    " Use -f to force %scompression.\n"
                    "For help, type: %s -h\n"),
                   program_name,
                   decompress ? "read from" : "written to",
                   decompress ? "de" : "",
                   program_name);
        do_exit(ERROR);
    }

    if (decompress || !ascii) {
      SET_BINARY_MODE (STDIN_FILENO);
    }
    if (!test && (!decompress || !ascii)) {
      SET_BINARY_MODE (STDOUT_FILENO);
    }
    strcpy(ifname, "stdin");
    strcpy(ofname, "stdout");

    /* Get the file's timestamp and size.  */
    if (fstat (STDIN_FILENO, &istat) != 0)
      {
        progerror (NULL);
        do_exit (ERROR);
      }

    get_input_size_and_time ();

    clear_bufs(); /* clear input and output buffers */
    to_stdout = 1;
    part_nb = 0;
    ifd = STDIN_FILENO;
    stdin_was_read = true;

    if (decompress) {
        method = get_method (ifd, true);
        if (method < 0) {
            do_exit(exit_code); /* error message already emitted */
        }
    }

    /* Actually do the compression/decompression. Loop over zipped members.
     */
    for (;;) {
        if (work (STDIN_FILENO, STDOUT_FILENO) != OK)
          return;

        if (input_eof ())
          break;

        method = get_method (ifd, false);
        if (method < 0) return; /* error message already emitted */
    }

    if (list)
      {
        do_list (method);
        return;
      }

    if (verbose) {
        if (test) {
            eputstring (" OK\n");

        } else if (!decompress) {
            display_ratio(bytes_in-(bytes_out-header_bytes), bytes_in, stderr);
            eputstring ("\n");
#ifdef DISPLAY_STDIN_RATIO
        } else {
            display_ratio(bytes_out-(bytes_in-header_bytes), bytes_out,stderr);
            eputstring ("\n");
#endif
        }
    }
}

static char const dot = '.';

/* True if the cached directory for calls to openat etc. is DIR, with
   length DIRLEN.  DIR need not be null-terminated.  DIRLEN must be
   less than MAX_PATH_LEN.  */
static bool
atdir_eq (char const *dir, ptrdiff_t dirlen)
{
  if (dirlen == 0)
    dir = &dot, dirlen = 1;
  return memcmp (dfname, dir, dirlen) == 0 && !dfname[dirlen];
}

enum { ATDIR_SET_ERROR = -1 - (AT_FDCWD == -1) };

/* Return the directory used for calls to openat etc., given the directory
   with file descriptor PARENTFD (if PARENTFD is nonnegative) and with name
   DIR, with length DIRLEN.  DIR need not be null-terminated.
   DIRLEN must be less than MAX_PATH_LEN.  Update the static variables
   DFD and SYNCDFD as needed.  Return AT_FDCWD if that
   suffices, otherwise a file descriptor for the directory,
   or ATDIR_SET_ERR if the fd could not be obtained.  */
static int
atdir_set (int parentfd, char const *dir, ptrdiff_t dirlen)
{
  if (to_stdout || atdir_eq (dir, dirlen))
    return dfd;
  if (USE_ATFUNCS && 0 <= parentfd)
    return parentfd;

  if (dirlen == 0)
    dir = &dot, dirlen = 1;
  char dirbuf[sizeof dfname];
  memcpy (dirbuf, dir, dirlen);
  dirbuf[dirlen] = '\0';

  int new_syncdfd = synchronous ? open (dirbuf, O_RDONLY | O_DIRECTORY) : -1;
  if (synchronous && new_syncdfd < 0)
    return ATDIR_SET_ERROR;

  int new_dfd;
  if (!USE_ATFUNCS)
    new_dfd = AT_FDCWD;
  else if (0 <= new_syncdfd)
    new_dfd = new_syncdfd;
  else if (dirbuf[0] == '.'
           && (dirlen < 2 || (dirlen == 2 && ISSLASH (dirbuf[1]))))
    new_dfd = AT_FDCWD;  /* Avoid an unnecessary open.  */
  else
    {
      #if defined O_PATH && O_SEARCH == O_RDONLY
        enum { search_flag = O_PATH };
      #else
        enum { search_flag = O_SEARCH };
      #endif
      new_dfd = open (dirbuf, search_flag | O_DIRECTORY);
      if (new_dfd < 0)
        return ATDIR_SET_ERROR;
    }

  if (0 <= syncdfd)
    close (syncdfd);
  if (0 <= dfd && dfd != syncdfd)
    close (dfd);

  memcpy (dfname, dirbuf, dirlen + 1);
  syncdfd = new_syncdfd;
  dfd = new_dfd;

  return new_dfd;
}

/* ========================================================================
 * Compress or decompress the given file
 */
static void
treat_file (int parentfd, char *iname)
{
    /* Accept "-" as synonym for stdin */
    if (strequ(iname, "-")) {
        int cflag = to_stdout;
        treat_stdin();
        to_stdout = cflag;
        return;
    }

    /* Check if the input file is present, set ifname and istat: */
    ifd = open_input_file (parentfd, iname, &istat);
    if (ifd < 0)
      return;

    /* If the input name is that of a directory, recurse or ignore: */
    if (S_ISDIR(istat.st_mode)) {
#if ! NO_DIR
        if (recursive) {
            treat_dir (ifd, iname);
            /* Warning: ifname is now garbage */
            return;
        }
#endif
        close (ifd);
        WARN ((stderr, "%s: %s is a directory -- ignored\n",
               program_name, quotef (ifname)));
        return;
    }

    if (! to_stdout)
      {
        if (! S_ISREG (istat.st_mode))
          {
            WARN ((stderr,
                   "%s: %s is not a directory or a regular file - ignored\n",
                   program_name, quotef (ifname)));
            close (ifd);
            return;
          }
        if (istat.st_mode & S_ISUID)
          {
            WARN ((stderr, "%s: %s is set-user-ID on execution - ignored\n",
                   program_name, quotef (ifname)));
            close (ifd);
            return;
          }
        if (istat.st_mode & S_ISGID)
          {
            WARN ((stderr, "%s: %s is set-group-ID on execution - ignored\n",
                   program_name, quotef (ifname)));
            close (ifd);
            return;
          }

        if (! force)
          {
            if (istat.st_mode & S_ISVTX)
              {
                WARN ((stderr,
                       "%s: %s has the sticky bit set - file ignored\n",
                       program_name, quotef (ifname)));
                close (ifd);
                return;
              }
            if (2 <= istat.st_nlink)
              {
                WARN ((stderr, "%s: %s has %ju other link%s -- file ignored\n",
                       program_name, quotef (ifname),
                       (uintmax_t) {istat.st_nlink - 1},
                       istat.st_nlink == 2 ? "" : "s"));
                close (ifd);
                return;
              }
          }
      }

    get_input_size_and_time ();

    /* Generate output file name. For -r and (-t or -l), skip files
     * without a valid gzip suffix (check done in make_ofname).
     */
    if (to_stdout && !test) {
        strcpy(ofname, "stdout");

    } else if (make_ofname() != OK) {
        close (ifd);
        return;
    }

    clear_bufs(); /* clear input and output buffers */
    part_nb = 0;

    if (decompress) {
        method = get_method (ifd, true); /* Update ofname if original given.  */
        if (method < 0) {
            close(ifd);
            return;               /* error message already emitted */
        }
    }

    /* If compressing to a file, check if ofname is not ambiguous
     * because the operating system truncates names. Otherwise, generate
     * a new ofname and save the original name in the compressed file.
     */
    if (to_stdout) {
        ofd = STDOUT_FILENO;
        /* Keep remove_ofname_fd negative.  */
    } else {
        if (create_outfile (parentfd) != OK)
          return;

        if (!decompress && save_orig_name && !verbose && !quiet) {
            fprintf(stderr, "%s: %s compressed to %s\n",
                    program_name, quotef_n (0, ifname), quotef_n (1, ofname));
        }
    }
    /* Keep the name even if not truncated except with --no-name: */
    if (!save_orig_name) save_orig_name = !no_name;

    if (verbose && !list) {
      fprintf (stderr, "%s:\t", quotef (ifname));
    }

    /* Actually do the compression/decompression. Loop over zipped members.
     */
    for (;;) {
        if ((*work)(ifd, ofd) != OK) {
            method = -1; /* force cleanup */
            break;
        }

        if (input_eof ())
          break;

        method = get_method (ifd, false);
        if (method < 0) break;    /* error message already emitted */
    }

    if (close (ifd) != 0)
      read_error ();

    if (list)
      {
        do_list (method);
        return;
      }

    if (!to_stdout)
      {
        copy_stat (&istat);

        int sfd = parentfd < 0 ? syncdfd : parentfd;

        if ((synchronous
             && ((0 <= sfd && fdatasync (sfd) < 0
                  && ((errno != EINVAL && errno != EBADF)
                      || (fsync (sfd) < 0 && errno != EINVAL)))
                 || (fsync (ofd) < 0 && errno != EINVAL)))
            || close (ofd) < 0)
          write_error ();

        if (!keep)
          {
            sigset_t oldset;
            int unlink_errno;
            int atfd = !USE_ATFUNCS ? -1 : parentfd < 0 ? dfd : parentfd;
            char *ifbase = atfd < 0 ? ifname : last_component (ifname);

            sigprocmask (SIG_BLOCK, &caught_signals, &oldset);
            remove_ofname_fd = -1;
            unlink_errno = unlinkat (atfd, ifbase, 0) < 0 ? errno : 0;
            sigprocmask (SIG_SETMASK, &oldset, NULL);

            if (unlink_errno)
              WARN ((stderr, "%s: %s: %s\n", program_name, quotef (ifname),
                     strerror (unlink_errno)));
          }
      }

    if (method == -1) {
        if (!to_stdout)
          remove_output_file (false);
        return;
    }

    /* Display statistics */
    if(verbose) {
        if (test) {
            eputstring (" OK");
        } else if (decompress) {
            display_ratio(bytes_out-(bytes_in-header_bytes), bytes_out,stderr);
        } else {
            display_ratio(bytes_in-(bytes_out-header_bytes), bytes_in, stderr);
        }
        if (!test)
          fprintf(stderr, " -- %s %s", keep ? "created" : "replaced with",
                  quotef (ofname));
        eputstring ("\n");
    }
}

static void
volatile_strcpy (char volatile *dst, char const volatile *src)
{
  while ((*dst++ = *src++))
    continue;
}

/* ========================================================================
 * Create the output file. Return OK or ERROR.
 * Try several times if necessary to avoid truncating the z_suffix. For
 * example, do not create a compressed file of name "1234567890123."
 * Sets save_orig_name to true if the file name has been truncated.
 * IN assertions: the input file has already been open (ifd is set) and
 *   ofname has already been updated if there was an original name.
 * OUT assertions: ifd and ofd are closed in case of error.
 */
static int
create_outfile (int parentfd)
{
  static bool signal_handlers_installed;
  int name_shortened = 0;
  int flags = (O_WRONLY | O_CREAT | O_EXCL
               | (ascii && decompress ? 0 : O_BINARY));
  char const *base = ofname;

  char const *ofbase = last_component (ofname);
  int atfd = atdir_set (parentfd, ofname, ofbase - ofname);
  if (0 <= atfd)
    base = ofbase;
  else if (atfd == ATDIR_SET_ERROR)
    {
      fprintf(stderr, "%s: %.*s: %s\n", program_name,
              (int) {ofbase - ofname}, ofname, strerror (errno));
      return ERROR;
    }

  if (!signal_handlers_installed)
    {
      signal_handlers_installed = true;
      install_signal_handlers ();
    }

  for (;;)
    {
      int open_errno;
      sigset_t oldset;

      remove_ofname_dfd = atfd;
      volatile_strcpy (remove_ofname, base);

      sigprocmask (SIG_BLOCK, &caught_signals, &oldset);
      remove_ofname_fd = ofd = openat (atfd, base, flags, S_IRUSR | S_IWUSR);
      open_errno = errno;
      sigprocmask (SIG_SETMASK, &oldset, NULL);

      if (0 <= ofd)
        break;

      switch (open_errno)
        {
#ifdef ENAMETOOLONG
        case ENAMETOOLONG:
          shorten_name (ofname);
          name_shortened = 1;
          break;
#endif

        case EEXIST:
          if (check_ofname (atfd) != OK)
            {
              close (ifd);
              return ERROR;
            }
          break;

        default:
          write_err (open_errno);
        }
    }

  if (name_shortened && decompress)
    {
      /* name might be too long if an original name was saved */
      WARN ((stderr, "%s: %s: warning, name truncated\n",
             program_name, quotef (ofname)));
    }

  return OK;
}

/* ========================================================================
 * Return a pointer to the 'z' suffix of a file name, or NULL. For all
 * systems, ".gz", ".z", ".Z", ".taz", ".tgz", "-gz", "-z" and "_z" are
 * accepted suffixes, in addition to the value of the --suffix option.
 * ".tgz" is a useful convention for tar.z files on systems limited
 * to 3 characters extensions. On such systems, ".?z" and ".??z" are
 * also accepted suffixes. For Unix, we do not want to accept any
 * .??z suffix as indicating a compressed file; some people use .xyz
 * to denote volume data.
 */
static char *
get_suffix (char *name)
{
    int nlen, slen;
    char suffix[MAX_SUFFIX+3]; /* last chars of name, forced to lower case */
    static char const *known_suffixes[] =
       {NULL, ".gz", ".z", ".taz", ".tgz", "-gz", "-z", "_z",
#ifdef MAX_EXT_CHARS
          "z",
#endif
        NULL, NULL};
    char const **suf;
    bool suffix_of_builtin = false;

    /* Normally put Z_SUFFIX at the start of KNOWN_SUFFIXES, but if it
       is a suffix of one of them, put it at the end.  */
    for (suf = known_suffixes + 1; *suf; suf++)
      {
        size_t suflen = strlen (*suf);
        if (z_len < suflen && strequ (z_suffix, *suf + suflen - z_len))
          {
            suffix_of_builtin = true;
            break;
          }
      }

    char *z_lower = xstrdup(z_suffix);
    strlwr(z_lower);
    known_suffixes[suffix_of_builtin ? countof (known_suffixes) - 2 : 0]
      = z_lower;
    suf = known_suffixes + suffix_of_builtin;

    nlen = strlen(name);
    if (nlen <= MAX_SUFFIX+2) {
        strcpy(suffix, name);
    } else {
        strcpy(suffix, name+nlen-MAX_SUFFIX-2);
    }
    strlwr(suffix);
    slen = strlen(suffix);
    char *match = NULL;
    do {
       int s = strlen(*suf);
       if (slen > s && ! ISSLASH (suffix[slen - s - 1])
           && strequ(suffix + slen - s, *suf)) {
           match = name+nlen-s;
           break;
       }
    } while (*++suf != NULL);
    free(z_lower);

    return match;
}


/* Open file NAME with the given flags and store its status
   into *ST.  Return a file descriptor to the newly opened file, or -1
   (setting errno) on failure.  */
static int
open_and_stat (int parentfd, char *name, int flags, struct stat *st)
{
  int fd;
  char const *base = name;

  /* Refuse to follow symbolic links unless -c or -f.  */
  if (!to_stdout && !force)
    {
      if (HAVE_WORKING_O_NOFOLLOW)
        flags |= O_NOFOLLOW;
      else
        {
#ifdef S_ISLNK
          if (lstat (name, st) != 0)
            return -1;
          else if (S_ISLNK (st->st_mode))
            {
              errno = ELOOP;
              return -1;
            }
#endif
        }
    }

  char const *namebase = last_component (name);
  int atfd = atdir_set (parentfd, name, namebase - name);
  if (0 <= atfd)
    base = namebase;
  else if (atfd == ATDIR_SET_ERROR)
    return -1;

  fd = openat (atfd, base, flags, 0);
  if (0 <= fd && fstat (fd, st) != 0)
    {
      int e = errno;
      close (fd);
      errno = e;
      return -1;
    }
  return fd;
}


/* ========================================================================
 * Set ifname to the input file name (with a suffix appended if necessary)
 * and istat to its stats. For decompression, if no file exists with the
 * original name, try adding successively z_suffix, .gz, .z, -z and .Z.
 * For MSDOS, we try only z_suffix and z.
 * Return an open file descriptor or -1.
 */
static int
open_input_file (int parentfd, char *iname, struct stat *sbuf)
{
    int ilen;  /* strlen(ifname) */
    int z_suffix_errno = 0;
    static char const *suffixes[] = {NULL, ".gz", ".z", "-z", ".Z", NULL};
    char const **suf = suffixes;
    char const *s;
#ifdef NO_MULTIPLE_DOTS
    char *dot; /* pointer to ifname extension, or NULL */
#endif
    int fd;
    int open_flags = (O_RDONLY | O_NONBLOCK | O_NOCTTY
                      | (ascii && !decompress ? 0 : O_BINARY));

    *suf = z_suffix;

    if (sizeof ifname - 1 <= strlen (iname))
        goto name_too_long;

    strcpy(ifname, iname);

    /* If input file exists, return OK. */
    fd = open_and_stat (parentfd, ifname, open_flags, sbuf);
    if (0 <= fd)
      return fd;

    if (!decompress || errno != ENOENT) {
        progerror(ifname);
        return -1;
    }
    /* File.ext doesn't exist.  Try adding a suffix.  */
    s = get_suffix(ifname);
    if (s != NULL) {
        progerror(ifname); /* ifname already has z suffix and does not exist */
        return -1;
    }
#ifdef NO_MULTIPLE_DOTS
    dot = strrchr(ifname, '.');
    if (dot == NULL) {
        strcat(ifname, ".");
        dot = strrchr(ifname, '.');
    }
#endif
    ilen = strlen(ifname);
    if (strequ(z_suffix, ".gz")) suf++;

    /* Search for all suffixes */
    do {
        char const *s0 = s = *suf;
        strcpy (ifname, iname);
#ifdef NO_MULTIPLE_DOTS
        if (*s == '.') s++;
        if (*dot == '\0') strcpy (dot, ".");
#endif
#ifdef MAX_EXT_CHARS
        if (MAX_EXT_CHARS < strlen (s) + strlen (dot + 1))
          dot[MAX_EXT_CHARS + 1 - strlen (s)] = '\0';
#endif
        if (sizeof ifname <= ilen + strlen (s))
          goto name_too_long;
        strcat(ifname, s);
        fd = open_and_stat (parentfd, ifname, open_flags, sbuf);
        if (0 <= fd)
          return fd;
        if (errno != ENOENT)
          {
            progerror (ifname);
            return -1;
          }
        if (strequ (s0, z_suffix))
          z_suffix_errno = errno;
    } while (*++suf != NULL);

    /* No suffix found, complain using z_suffix: */
    strcpy(ifname, iname);
#ifdef NO_MULTIPLE_DOTS
    if (*dot == '\0') strcpy(dot, ".");
#endif
#ifdef MAX_EXT_CHARS
    if (MAX_EXT_CHARS < z_len + strlen (dot + 1))
      dot[MAX_EXT_CHARS + 1 - z_len] = '\0';
#endif
    strcat(ifname, z_suffix);
    errno = z_suffix_errno;
    progerror(ifname);
    return -1;

 name_too_long:
    fprintf (stderr, "%s: %s: file name too long\n", program_name,
             quotef (iname));
    exit_code = ERROR;
    return -1;
}

/* ========================================================================
 * Generate ofname given ifname. Return OK, or WARNING if file must be skipped.
 * Sets save_orig_name to true if the file name has been truncated.
 */
static int
make_ofname ()
{
    char *suff;            /* ofname z suffix */

    strcpy(ofname, ifname);
    /* strip a version number if any and get the gzip suffix if present: */
    suff = get_suffix(ofname);

    if (decompress) {
        if (suff == NULL) {
            /* With -t or -l, try all files (even without .gz suffix)
             * except with -r (behave as with just -dr).
             */
            if (!recursive && test)
              return OK;

            /* Avoid annoying messages with -r */
            if (verbose || (!recursive && !quiet)) {
                WARN((stderr,"%s: %s: unknown suffix -- ignored\n",
                      program_name, quotef (ifname)));
            }
            return WARNING;
        }
        /* Make a special case for .tgz and .taz: */
        strlwr(suff);
        if (strequ(suff, ".tgz") || strequ(suff, ".taz")) {
            strcpy(suff, ".tar");
        } else {
            *suff = '\0'; /* strip the z suffix */
        }
        /* ofname might be changed later if infile contains an original name */

    } else if (suff && ! force) {
        /* Avoid annoying messages with -r (see treat_dir()) */
        if (verbose || (!recursive && !quiet)) {
            /* Don't use WARN, as it affects exit status.  */
            fprintf (stderr, "%s: %s already has %s suffix -- unchanged\n",
                     program_name, quotef_n (0, ifname), quotef_n (1, suff));
        }
        return WARNING;
    } else {
        save_orig_name = 0;

#ifdef NO_MULTIPLE_DOTS
        suff = strrchr(ofname, '.');
        if (suff == NULL) {
            if (sizeof ofname <= strlen (ofname) + 1)
                goto name_too_long;
            strcat(ofname, ".");
#  ifdef MAX_EXT_CHARS
            if (strequ(z_suffix, "z")) {
                if (sizeof ofname <= strlen (ofname) + 2)
                    goto name_too_long;
                strcat(ofname, "gz"); /* enough room */
                return OK;
            }
        /* On the Atari and some versions of MSDOS,
         * ENAMETOOLONG does not work correctly.  So we
         * must truncate here.
         */
        } else if (strlen(suff)-1 + z_len > MAX_SUFFIX) {
            suff[MAX_SUFFIX+1-z_len] = '\0';
            save_orig_name = 1;
#  endif
        }
#endif /* NO_MULTIPLE_DOTS */
        if (sizeof ofname <= strlen (ofname) + z_len)
            goto name_too_long;
        strcat(ofname, z_suffix);

    } /* decompress ? */
    return OK;

 name_too_long:
    WARN ((stderr, "%s: %s: file name too long\n", program_name,
           quotef (ifname)));
    return WARNING;
}

/* Discard NBYTES input bytes from the input, or up through the next
   zero byte if NBYTES == (size_t) -1.  If FLAGS say that the header
   CRC should be computed, update the CRC accordingly.  */
static void
discard_input_bytes (size_t nbytes, unsigned int flags)
{
  while (nbytes != 0)
    {
      uch c = get_byte ();
      if (flags & HEADER_CRC)
        updcrc (&c, 1);
      if (nbytes != (size_t) -1)
        nbytes--;
      else if (! c)
        break;
    }
}

/* ========================================================================
 * Check the magic number of the input file and update ofname if an
 * original name was given and to_stdout is not set.
 * Return the compression method, -1 for error, -2 for warning.
 * Set inptr to the offset of the next byte to be processed.
 * Updates time_stamp if there is one and neither -m nor -n is used.
 * This function may be called repeatedly for an input file consisting
 * of several contiguous gzip'ed members.
 * 'in' is the input file descriptor; 'first' is true for first call on 'in'.
 * IN assertions: there is at least one remaining compressed member.
 *   If the member is a zip file, it must be the only one.
 */
static int
get_method (int in, bool first)
{
    uch flags;     /* compression flags */
    uch magic[10]; /* magic header */
    int imagic0;   /* first magic byte or EOF */
    int imagic1;   /* like magic[1], but can represent EOF */
    ulg stamp;     /* timestamp */

    /* If --force and --stdout, zcat == cat, so do not complain about
     * premature end of file: use try_byte instead of get_byte.
     */
    if (force && to_stdout) {
        imagic0 = try_byte();
        magic[0] = imagic0;
        imagic1 = try_byte ();
        magic[1] = imagic1;
        /* If try_byte returned EOF, magic[1] == (char) EOF.
           Although POSIX says this could cause gzip to trap
           if EOF < CHAR_MIN < 0, no known platform is like that;
           check to be safe.  */
        static_assert (! (EOF < CHAR_MIN && CHAR_MIN < 0));
    } else {
        magic[0] = get_byte ();
        imagic0 = 0;
        if (magic[0]) {
            magic[1] = get_byte ();
            imagic1 = 0; /* avoid lint warning */
        } else {
            imagic1 = try_byte ();
            magic[1] = imagic1;
        }
    }
    method = -1;                 /* unknown yet */
    part_nb++;                   /* number of parts in gzip file */
    header_bytes = 0;
    last_member = 0;
    /* assume multiple members in gzip file except for record oriented I/O */

    if (memcmp(magic, GZIP_MAGIC, 2) == 0
        || memcmp(magic, OLD_GZIP_MAGIC, 2) == 0) {

        method = get_byte();
        if (method != DEFLATED) {
            fprintf(stderr,
                    "%s: %s: unknown method %d -- not supported\n",
                    program_name, quotef (ifname), method);
            exit_code = ERROR;
            return -1;
        }
        work = unzip;
        flags  = (uch)get_byte();

        if ((flags & ENCRYPTED) != 0) {
            fprintf(stderr,
                    "%s: %s is encrypted -- not supported\n",
                    program_name, quotef (ifname));
            exit_code = ERROR;
            return -1;
        }
        if ((flags & RESERVED) != 0) {
            fprintf(stderr,
                    "%s: %s has flags 0x%x -- not supported\n",
                    program_name, quotef (ifname), flags);
            exit_code = ERROR;
            if (force <= 1) return -1;
        }
        stamp  = (ulg)get_byte();
        stamp |= ((ulg)get_byte()) << 8;
        stamp |= ((ulg)get_byte()) << 16;
        stamp |= ((ulg)get_byte()) << 24;
        if (stamp != 0 && !no_time)
          {
            if (stamp <= TYPE_MAXIMUM (time_t))
              {
                time_stamp.tv_sec = stamp;
                time_stamp.tv_nsec = 0;
              }
            else
              {
                WARN ((stderr,
                       "%s: %s: MTIME %lu out of range for this platform\n",
                       program_name, quotef (ifname), stamp));
                time_stamp.tv_sec = TYPE_MAXIMUM (time_t);
                time_stamp.tv_nsec = TIMESPEC_RESOLUTION - 1;
              }
          }

        magic[8] = get_byte ();  /* Ignore extra flags.  */
        magic[9] = get_byte ();  /* Ignore OS type.  */

        if (flags & HEADER_CRC)
          {
            magic[2] = DEFLATED;
            magic[3] = flags;
            magic[4] = stamp & 0xff;
            magic[5] = (stamp >> 8) & 0xff;
            magic[6] = (stamp >> 16) & 0xff;
            magic[7] = stamp >> 24;
            updcrc (NULL, 0);
            updcrc (magic, 10);
          }

        if ((flags & EXTRA_FIELD) != 0) {
            uch lenbuf[2];
            unsigned int len = lenbuf[0] = get_byte ();
            len |= (lenbuf[1] = get_byte ()) << 8;
            if (verbose) {
                fprintf(stderr,"%s: %s: extra field of %u bytes ignored\n",
                        program_name, quotef (ifname), len);
            }
            if (flags & HEADER_CRC)
              updcrc (lenbuf, 2);
            discard_input_bytes (len, flags);
        }

        /* FIXME: It is not clear whether this code is doing the right thing.
           Should it get the original file name if it was truncated?
           Should it check save_orig_name?  */
        if ((flags & ORIG_NAME) != 0) {
            if (no_name || (to_stdout && !list) || part_nb > 1) {
                /* Discard the old name */
                discard_input_bytes (-1, flags);
            } else {
                /* Copy the base name. Keep a directory prefix intact. */
                char *p = gzip_base_name (ofname);
                char *base = p;
                for (;;) {
                    *p = (char) get_byte ();
                    if (*p++ == '\0') break;
                    if (p >= ofname+sizeof(ofname)) {
                        gzip_error ("corrupted input -- file name too large");
                    }
                }
                if (flags & HEADER_CRC)
                  updcrc ((uch *) base, p - base);
                p = gzip_base_name (base);
                memmove (base, p, strlen (p) + 1);
                /* If necessary, adapt the name to local OS conventions: */
                if (!list) {
                   MAKE_LEGAL_NAME(base);
                   if (base) list=0; /* avoid warning about unused variable */
                }
            } /* no_name || to_stdout */
        } /* ORIG_NAME */

        /* Discard file comment if any */
        if ((flags & COMMENT) != 0) {
            discard_input_bytes (-1, flags);
        }

        if (flags & HEADER_CRC)
          {
            unsigned int crc16 = updcrc (magic, 0) & 0xffff;
            unsigned int header16 = get_byte ();
            header16 |= ((unsigned int) get_byte ()) << 8;
            if (header16 != crc16)
              {
                fprintf (stderr,
                         "%s: %s: header checksum 0x%04x != computed checksum 0x%04x\n",
                         program_name, quotef (ifname), header16, crc16);
                exit_code = ERROR;
                if (force <= 1)
                  return -1;
              }
          }

        if (part_nb == 1) {
            header_bytes = inptr + 2*4; /* include crc and size */
        }

    } else if (first && memcmp (magic, PKZIP_MAGIC, 2) == 0) {
        /* To simplify the code, we support a zip file when alone only.
         * We are thus guaranteed that the entire local header fits in inbuf.
         */
        inptr = 0;
        work = unzip;
        if (check_zipfile(in) != OK) return -1;
        /* check_zipfile may get ofname from the local header */
        last_member = 1;

    } else if (memcmp(magic, PACK_MAGIC, 2) == 0) {
        work = unpack;
        method = PACKED;

    } else if (memcmp(magic, LZW_MAGIC, 2) == 0) {
        work = unlzw;
        method = COMPRESSED;
        last_member = 1;

    } else if (memcmp(magic, LZH_MAGIC, 2) == 0) {
        work = unlzh;
        method = LZHED;
        last_member = 1;

    } else if (force && to_stdout && !list) { /* pass input unchanged */
        method = STORED;
        work = copy;
        if (imagic1 != EOF)
            inptr--;
        last_member = 1;
        if (imagic0 != EOF) {
            write_buf (STDOUT_FILENO, magic, 1);
        }
    }
    if (method >= 0) return method;

    if (part_nb == 1) {
        fprintf (stderr, "\n%s: %s: not in gzip format\n",
                 program_name, quotef (ifname));
        exit_code = ERROR;
        return -1;
    } else {
        if (magic[0] == 0)
          {
            int inbyte;
            for (inbyte = imagic1;  inbyte == 0;  inbyte = try_byte ())
              continue;
            if (inbyte == EOF)
              {
                if (verbose)
                  WARN ((stderr, "\n%s: %s: decompression OK, trailing zero bytes ignored\n",
                         program_name, quotef (ifname)));
                return -3;
              }
          }

        WARN((stderr, "\n%s: %s: decompression OK, trailing garbage ignored\n",
              program_name, quotef (ifname)));
        return -2;
    }
}

/* ========================================================================
 * Display the characteristics of the compressed file.
 * If the given method is < 0, display the accumulated totals.
 * IN assertions: time_stamp, header_bytes and ifile_size are initialized.
 */
static void
do_list (int method)
{
    ulg crc;  /* original crc */
    static int first_time = 1;
    static char const *const methods[MAX_METHODS] = {
        "store",  /* 0 */
        "compr",  /* 1 */
        "pack ",  /* 2 */
        "lzh  ",  /* 3 */
        "", "", "", "", /* 4 to 7 reserved */
        "defla"}; /* 8 */
    int positive_off_t_width = INT_STRLEN_BOUND (off_t) - 1;

    if (first_time && method >= 0) {
        first_time = 0;
        if (verbose)  {
            putstring ("method  crc     date  time  ");
        }
        if (!quiet) {
            printf("%*.*s %*.*s  ratio uncompressed_name\n",
                   positive_off_t_width, positive_off_t_width, "compressed",
                   positive_off_t_width, positive_off_t_width, "uncompressed");
        }
    } else if (method < 0) {
        if (total_in <= 0 || total_out <= 0) return;
        if (verbose) {
            putstring ("                            ");
        }
        if (verbose || !quiet)
          printf ("%*jd %*jd ", positive_off_t_width, (intmax_t) {total_in},
                  positive_off_t_width, (intmax_t) {total_out});
        display_ratio(total_out-(total_in-header_bytes), total_out, stdout);
        /* header_bytes is not meaningful but used to ensure the same
         * ratio if there is a single file.
         */
        putstring (" (totals)\n");
        return;
    }
    crc = (ulg)~0; /* unknown */

    if (method == DEFLATED && !last_member) {
      crc = unzip_crc;
    }

    if (verbose)
      {
        static char const month_abbr[][4]
          = { "Jan", "Feb", "Mar", "Apr", "May", "Jun",
              "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
        struct tm *tm = localtime (&time_stamp.tv_sec);
        printf ("%5s %08lx ", methods[method], crc);
        if (tm)
          printf ("%s%3d %02d:%02d ", month_abbr[tm->tm_mon],
                  tm->tm_mday, tm->tm_hour, tm->tm_min);
        else
          printf ("??? ?? ??:?? ");
      }
    printf ("%*jd %*jd ", positive_off_t_width, (intmax_t) {bytes_in},
            positive_off_t_width, (intmax_t) {bytes_out});
    if (bytes_in  == -1L) {
        total_in = -1L;
        bytes_in = bytes_out = header_bytes = 0;
    } else if (total_in >= 0) {
        total_in  += bytes_in;
    }
    if (bytes_out == -1L) {
        total_out = -1L;
        bytes_in = bytes_out = header_bytes = 0;
    } else if (total_out >= 0) {
        total_out += bytes_out;
    }
    display_ratio(bytes_out-(bytes_in-header_bytes), bytes_out, stdout);
    printf (" %s\n", quotef (ofname));
}

/* ========================================================================
 * Shorten the given name by one character, or replace a .tar extension
 * with .tgz. Truncate the last part of the name which is longer than
 * MIN_PART characters: 1234.678.012.gz -> 123.678.012.gz. If the name
 * has only parts shorter than MIN_PART truncate the longest part.
 * For decompression, just remove the last character of the name.
 *
 * IN assertion: for compression, the suffix of the given name is z_suffix.
 */
static void
shorten_name (char *name)
{
    int len;                 /* length of name without z_suffix */
    char *trunc = NULL;      /* character to be truncated */
    int plen;                /* current part length */
    int min_part = MIN_PART; /* current minimum part length */
    char *p;

    len = strlen(name);
    if (decompress) {
        if (len <= 1)
          gzip_error ("name too short");
        name[len-1] = '\0';
        return;
    }
    p = get_suffix(name);
    if (! p)
      gzip_error ("can't recover suffix\n");
    *p = '\0';
    save_orig_name = 1;

    /* compress 1234567890.tar to 1234567890.tgz */
    if (len > 4 && strequ(p-4, ".tar")) {
        strcpy(p-4, ".tgz");
        return;
    }
    /* Try keeping short extensions intact:
     * 1234.678.012.gz -> 123.678.012.gz
     */
    do {
        p = last_component (name);
        while (*p) {
            plen = strcspn(p, PART_SEP);
            p += plen;
            if (plen > min_part) trunc = p-1;
            if (*p) p++;
        }
    } while (trunc == NULL && --min_part != 0);

    if (trunc != NULL) {
        do {
            trunc[0] = trunc[1];
        } while (*trunc++);
        trunc--;
    } else {
        trunc = strrchr(name, PART_SEP[0]);
        if (!trunc)
          gzip_error ("internal error in shorten_name");
        if (trunc[1] == '\0') trunc--; /* force truncation */
    }
    strcpy(trunc, z_suffix);
}

/* ========================================================================
 * The compressed file already exists, so ask for confirmation.
 * Return ERROR if the file must be skipped.
 */
static int
check_ofname (int atfd)
{
    /* Ask permission to overwrite the existing file */
    if (!force) {
        int ok = 0;
        fprintf (stderr, "%s: %s already exists;",
                 program_name, quotef (ofname));
        if (foreground && (presume_input_tty || isatty (STDIN_FILENO))) {
            eputstring (" do you wish to overwrite (y or n)? ");
            fflush(stderr);
            ok = yesno();
        }
        if (!ok) {
            eputstring ("\tnot overwritten\n");
            if (exit_code == OK) exit_code = WARNING;
            return ERROR;
        }
    }
    if (unlinkat (atfd, atfd < 0 ? ofname : last_component (ofname), 0) < 0) {
        progerror(ofname);
        return ERROR;
    }
    return OK;
}

/* Change the owner and group of a file.  FD is a file descriptor for
   the file and NAME its name.  Change it to user UID and to group GID.
   If UID or GID is -1, though, do not change the corresponding user
   or group.  */
#if ! (HAVE_FCHOWN || HAVE_CHOWN)
/* The types uid_t and gid_t do not exist on mingw, so don't assume them.  */
# define do_chown(fd, name, uid, gid) ((void) 0)
#else
static void
do_chown (int fd, char const *name, uid_t uid, gid_t gid)
{
# if HAVE_FCHOWN
  ignore_value (fchown (fd, uid, gid));
# else
  ignore_value (chown (name, uid, gid));
# endif
}
#endif

/* ========================================================================
 * Copy modes, times, ownership from input file to output file.
 * IN assertion: to_stdout is false.
 */
static void
copy_stat (struct stat *ifstat)
{
    mode_t mode = ifstat->st_mode & S_IRWXUGO;
    int r;

#ifndef NO_UTIME
    bool restoring;
    struct timespec timespec[2];
    timespec[0] = get_stat_atime (ifstat);
    timespec[1] = get_stat_mtime (ifstat);
    restoring = (decompress && 0 <= time_stamp.tv_nsec
                 && ! (timespec[1].tv_sec == time_stamp.tv_sec
                       && timespec[1].tv_nsec == time_stamp.tv_nsec));
    if (restoring)
      timespec[1] = time_stamp;

    if (fdutimens (ofd, ofname, timespec) == 0)
      {
        if (restoring && 1 < verbose) {
          fprintf (stderr, "%s: timestamp restored\n", quotef (ofname));
        }
      }
    else
      WARN ((stderr, "%s: %s: %s\n", program_name, quotef (ofname),
             strerror (errno)));
#endif

    /* Change the group first, then the permissions, then the owner.
       That way, the permissions will be correct on systems that allow
       users to give away files, without introducing a security hole.
       Security depends on permissions not containing the setuid or
       setgid bits.  */

    do_chown (ofd, ofname, -1, ifstat->st_gid);

#if HAVE_FCHMOD
    r = fchmod (ofd, mode);
#else
    r = chmod (ofname, mode);
#endif
    if (r != 0)
      WARN ((stderr, "%s: %s: %s\n", program_name, quotef (ofname),
             strerror (errno)));

    do_chown (ofd, ofname, ifstat->st_uid, -1);
}

#if ! NO_DIR

/* ========================================================================
 * Recurse through the given directory.
 */
static void
treat_dir (int fd, char *dir)
{
    DIR      *dirp;
    char     nbuf[MAX_PATH_LEN];
    char *entries;
    char const *entry;
    size_t entrylen;

# if HAVE_FDOPENDIR
    dirp = fdopendir (fd);
# else
    dirp = opendir (dir);
# endif

    if (dirp == NULL) {
        progerror(dir);
        close (fd);
        return ;
    }

    entries = streamsavedir (dirp, SAVEDIR_SORT_NONE);

    if (!entries)
      progerror (dir);
    else
     {
      for (entry = entries; *entry; entry += entrylen + 1) {
        size_t len = strlen (dir);
        entrylen = strlen (entry);
        if (strequ (entry, ".") || strequ (entry, ".."))
          continue;
        if (len + entrylen < MAX_PATH_LEN - 2) {
            strcpy(nbuf,dir);
            if (*last_component (nbuf) && !ISSLASH (nbuf[len - 1]))
              nbuf[len++] = '/';
            strcpy (nbuf + len, entry);
            treat_file (fd, nbuf);
        } else {
            fprintf(stderr,"%s: %s/%s: pathname too long\n",
                    program_name, quotef_n (0, dir), quotef_n (1, entry));
            exit_code = ERROR;
        }
      }
      free (entries);
     }
    if (closedir (dirp) < 0)
      progerror (dir);
# if !HAVE_FDOPENDIR
    if (close (fd) < 0)
      progerror (dir);
# endif
}
#endif /* ! NO_DIR */

/* Make sure signals get handled properly.  */

static void
install_signal_handlers ()
{
  int nsigs = countof (handled_sig);
  struct sigaction act;

  sigemptyset (&caught_signals);
  for (int i = 0; i < nsigs; i++)
    {
      sigaction (handled_sig[i], NULL, &act);
      if (act.sa_handler != SIG_IGN)
        sigaddset (&caught_signals, handled_sig[i]);
    }

  act.sa_handler = abort_gzip_signal;
  act.sa_mask = caught_signals;
  act.sa_flags = 0;

  for (int i = 0; i < nsigs; i++)
    if (sigismember (&caught_signals, handled_sig[i]))
      {
        if (i == 0)
          foreground = 1;
        sigaction (handled_sig[i], &act, NULL);
      }
}

/* ========================================================================
 * Free all dynamically allocated variables and exit with the given code.
 */
static void
do_exit (int exitcode)
{
    static int in_exit = 0;

    if (in_exit) exit(exitcode);
    in_exit = 1;
    free(env);
    env  = NULL;
    FREE(inbuf);
    FREE(outbuf);
    FREE(d_buf);
    FREE(window);
#ifndef MAXSEG_64K
    FREE(tab_prefix);
#else
    FREE(tab_prefix0);
    FREE(tab_prefix1);
#endif
    exit(exitcode);
}

static void
finish_out ()
{
  if (fflush (stdout) < 0)
    write_error ();
  if (ferror (stdout))
    write_err (EIO);
  if (fclose (stdout) != 0)
    write_error ();
  do_exit (OK);
}

/* ========================================================================
 * Close and unlink the output file.
 */
static void
remove_output_file (bool signals_already_blocked)
{
  int fd;

  fd = remove_ofname_fd;
  if (0 <= fd)
    {
      char fname[MAX_PATH_LEN];
      volatile_strcpy (fname, remove_ofname);
      sigset_t oldset;
      if (!signals_already_blocked)
        sigprocmask (SIG_BLOCK, &caught_signals, &oldset);
      remove_ofname_fd = -1;
      close (fd);
      unlinkat (remove_ofname_dfd, fname, 0);
      if (!signals_already_blocked)
        sigprocmask (SIG_SETMASK, &oldset, NULL);
    }
}

/* ========================================================================
 * Error handler.
 */
void
finish_up_gzip (int exitcode)
{
  if (0 <= remove_ofname_fd)
    remove_output_file (false);
  do_exit (exitcode);
}
void
abort_gzip ()
{
  finish_up_gzip (ERROR);
}
/* ========================================================================
 * Signal handler.
 */
static void
abort_gzip_signal (int sig)
{
   remove_output_file (true);
   signal (sig, SIG_DFL);
   raise (sig);
}
