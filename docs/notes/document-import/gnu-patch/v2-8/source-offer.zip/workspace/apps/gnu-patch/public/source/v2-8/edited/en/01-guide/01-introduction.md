---
title: "Introduction and usage"
documentId: "gnu-patch:2.8:01-introduction"
licenseSource: gnu-patch-manual
toc: {"maxLevel": 3}
documentContext: [{"kind": "source", "html": "<section><h3>Libx GNU patch 2.8 Manual / Libx GNU patch 2.8 マニュアル</h3><p>Original authors: Larry Wall, Paul Eggert, Wayne Davison, David MacKenzie, Andreas Gruenbacher. Original publisher: Free Software Foundation. Modification and independent Japanese translation: Libx, 2026.</p><section class=\"Sh\">\n<h2 class=\"Sh\" id=\"patch-context-COPYING\">COPYING</h2>\n<p class=\"Pp\">Copyright © 1989–2025 Free Software Foundation, Inc.\n  <br/>\n  Copyright © 1984–1986, 1988 Larry Wall.</p>\n<p class=\"Pp\">Permission is granted to make and distribute verbatim copies of\n    this manual provided the copyright notice and this permission notice are\n    preserved on all copies.</p>\n<p class=\"Pp\">Permission is granted to copy and distribute modified versions of\n    this manual under the conditions for verbatim copying, provided that the\n    entire resulting derived work is distributed under the terms of a permission\n    notice identical to this one.</p>\n<p class=\"Pp\">Permission is granted to copy and distribute translations of this\n    manual into another language, under the above conditions for modified\n    versions, except that this permission notice may be included in translations\n    approved by the copyright holders instead of in the original English.</p>\n</section><p>The entire resulting derived manual is distributed under the identical original permission notice above. Copyright © 2026 Libx for static editing and independent unofficial Japanese translation.</p><p>Libx provides the complete fixed GNU patch 2.8 patch.man, organized into nine guide pages. Original examples remain static text. Other implementation files and historical NEWS entries are outside the translated scope.</p><p>LibxはGNU patch 2.8に同梱されたpatch.man全文を9ページに整理し、原文と独立した非公式日本語訳を提供します。例は原文の静的な文字列です。実装ファイルや過去のNEWSは翻訳対象外です。</p><p>Libx編集注記: --follow-symlinksの固定man本文と同梱NEWSの2.8変更説明には記述の違いがあります。本文を黙って修正せず、<a href=\"/docs/gnu-patch/source/v2-8/manual.html#follow\">固定manの説明</a>と<a href=\"/docs/gnu-patch/source/v2-8/NEWS\">原著NEWS</a>を参照できるようにしています。</p><p>Libx編集注記: 環境変数VERSION_CONTROL/PATCH_VERSION_CONTROLの説明では、原文が-vを参照しています。一方、オプションの説明では-vは--version、-Vは--version-controlです。原文と訳文の本文はそのまま保持しています。Libx editorial note: The original environment section refers to -v; the options section lists -v as --version and -V as --version-control. Both original and translated body text are preserved. <a href=\"/docs/gnu-patch/source/v2-8/manual.html#VERSION_CONTROL\">Original environment reference</a> · <a href=\"/docs/gnu-patch/source/v2-8/manual.html#V\">Original -V option</a></p><p><a href=\"/docs/gnu-patch/source/v2-8/manual.html\">Fixed complete original / 固定原文全文</a> · <a href=\"/docs/gnu-patch/source/v2-8/patch.man\">Editable original roff / 編集可能な原文</a> · <a href=\"/docs/gnu-patch/source/v2-8/patch-2.8.tar.gz\">Original distribution / 原著配布物</a> · <a href=\"/docs/gnu-patch/source/v2-8/AUTHORS\">Original AUTHORS</a></p></section>"}]
---

<div class="gnu-patch-original-content"><section class="gnu-patch-unit"><section class="Sh">
<h2 class="Sh" id="NAME">NAME</h2>
<p class="Pp">patch - apply a diff file to an original</p>
</section><section class="Sh">
<h2 class="Sh" id="SYNOPSIS">SYNOPSIS</h2>
<p class="Pp"><b>patch</b> [<i>options</i>] [<i>originalfile</i>
    [<i>patchfile</i>]]</p>
<p class="Pp">but usually just</p>
<p class="Pp"><b>patch -p</b><i>num</i> <b>&lt;</b><i>patchfile</i></p>
</section><section class="Sh">
<h2 class="Sh" id="DESCRIPTION">DESCRIPTION</h2>
<p class="Pp"><b>patch</b> takes a patch file <i>patchfile</i> containing a
    difference listing produced by the <b>diff</b> program and applies those
    differences to one or more original files, producing patched versions.
    Normally the patched versions are put in place of the originals. Backups can
    be made; see the <b>-b</b> or <b>--backup</b> option. The names of the files
    to be patched are usually taken from the patch file, but if there's just one
    file to be patched it can be specified on the command line as
    <i>originalfile</i>.</p>
<p class="Pp">Upon startup, patch attempts to determine the type of the diff
    listing, unless overruled by a <b>-c</b> (<b>--context</b>), <b>-e</b>
    (<b>--ed</b>), <b>-n</b> (<b>--normal</b>), or <b>-u</b> (<b>--unified</b>)
    option. Context diffs (old-style, new-style, and unified) and normal diffs
    are applied by the <b>patch</b> program itself, while <b>ed</b> diffs are
    simply fed to the <b>ed</b>(1) editor via a pipe.</p>
<p class="Pp"><b>patch</b> tries to skip any leading garbage, apply the diff,
    and then skip any trailing garbage. Thus you could feed an email message
    containing a diff listing to <b>patch</b>, and it should work. If the entire
    diff is indented by a consistent amount, if lines end in CRLF, or if a diff
    is encapsulated one or more times by prepending "<b>- </b>" to
    lines starting with "<b>-</b>" as specified by Internet RFC 934,
    this is taken into account. After removing indenting or encapsulation, lines
    beginning with <b>#</b> are ignored, as they are considered to be
  comments.</p>
<p class="Pp">With context diffs, and to a lesser extent with normal diffs,
    <b>patch</b> can detect when the line numbers mentioned in the patch are
    incorrect, and attempts to find the correct place to apply each hunk of the
    patch. As a first guess, it takes the line number mentioned for the hunk,
    plus or minus any offset used in applying the previous hunk. If that is not
    the correct place, <b>patch</b> scans both forwards and backwards for a set
    of lines matching the context given in the hunk. First <b>patch</b> looks
    for a place where all lines of the context match. If no such place is found,
    and it's a context diff, and the maximum fuzz factor is set to 1 or more,
    then another scan takes place ignoring the first and last line of context.
    If that fails, and the maximum fuzz factor is set to 2 or more, the first
    two and last two lines of context are ignored, and another scan is made.
    (The default maximum fuzz factor is 2.)</p>
<p class="Pp">Hunks with less prefix context than suffix context (after applying
    fuzz) must apply at the start of the file if their first line number
    is 1. Hunks with more prefix context than suffix context (after
    applying fuzz) must apply at the end of the file.</p>
<p class="Pp">If <b>patch</b> cannot find a place to install that hunk of the
    patch, it puts the hunk out to a reject file, which normally is the name of
    the output file plus a <b>.rej</b> suffix, or <b>#</b> if <b>.rej</b> would
    generate a file name that is too long (if even appending the single
    character <b>#</b> makes the file name too long, then <b>#</b> replaces the
    file name's last character).</p>
<p class="Pp">The rejected hunk comes out in unified or context diff format. If
    the input was a normal diff, many of the contexts are simply null. The line
    numbers on the hunks in the reject file may be different than in the patch
    file: they reflect the approximate location patch thinks the failed hunks
    belong in the new file rather than the old one.</p>
<p class="Pp">As each hunk is completed, you are told if the hunk failed, and if
    so which line (in the new file) <b>patch</b> thought the hunk should go on.
    If the hunk is installed at a different line from the line number specified
    in the diff, you are told the offset. A single large offset <i>may</i>
    indicate that a hunk was installed in the wrong place. You are also told if
    a fuzz factor was used to make the match, in which case you should also be
    slightly suspicious. If the <b>--verbose</b> option is given, you are also
    told about hunks that match exactly.</p>
<p class="Pp">If no original file <i>origfile</i> is specified on the command
    line, <b>patch</b> tries to figure out from the leading garbage what the
    name of the file to edit is, using the following rules.</p>
<p class="Pp">First, <b>patch</b> takes an ordered list of candidate file names
    as follows:</p>
<div class="Bd-indent">
<ul class="Bl-bullet">
<li>If the header is that of a context diff, <b>patch</b> takes the old and
      new file names in the header. A name is ignored if it does not have enough
      slashes to satisfy the <b>-p</b><i>num</i> or <b>--strip=</b><i>num</i>
      option. The name <b>/dev/null</b> is also ignored.</li>
<li>If there is an <b>Index:</b> line in the leading garbage and if either the
      old and new names are both absent or if <b>patch</b> is conforming to
      POSIX, <b>patch</b> takes the name in the <b>Index:</b> line.</li>
<li>For the purpose of the following rules, the candidate file names are
      considered to be in the order (old, new, index), regardless of the order
      that they appear in the header.</li>
</ul>
</div>
<p class="Pp">Then <b>patch</b> selects a file name from the candidate list as
    follows:</p>
<div class="Bd-indent">
<ul class="Bl-bullet">
<li>If some of the named files exist, <b>patch</b> selects the first name if
      conforming to POSIX, and the best name otherwise.</li>
<li>If <b>patch</b> is not ignoring RCS, ClearCase, Perforce, and SCCS (see
      the <b>-g </b><i>num</i> or <b>--get=</b><i>num</i> option), and no
      named files exist but an RCS, ClearCase, Perforce, or SCCS master is
      found, <b>patch</b> selects the first named file with an RCS, ClearCase,
      Perforce, or SCCS master.</li>
<li>If no named files exist, no RCS, ClearCase, Perforce, or SCCS master was
      found, some names are given, <b>patch</b> is not conforming to POSIX, and
      the patch appears to create a file, <b>patch</b> selects the best name
      requiring the creation of the fewest directories.</li>
<li>If no file name results from the above heuristics, you are asked for the
      name of the file to patch, and <b>patch</b> selects that name.</li>
</ul>
</div>
<p class="Pp">To determine the <i>best</i> of a nonempty list of file names,
    <b>patch</b> first takes all the names with the fewest path name components;
    of those, it then takes all the names with the shortest basename; of those,
    it then takes all the shortest names; finally, it takes the first remaining
    name.</p>
<p class="Pp">Additionally, if the leading garbage contains a <b>Prereq:</b>
    line, <b>patch</b> takes the first word from the prerequisites line
    (normally a version number) and checks the original file to see if that word
    can be found. If not, <b>patch</b> asks for confirmation before
  proceeding.</p>
<p class="Pp">The upshot of all this is that you should be able to run something
    like the following shell command:</p>

<div class="Bd-indent"><b>patch -d /usr/src/local/blurfl</b></div>
<p class="Pp">and patch a file in the <b>blurfl</b> directory directly from a
    patch that is read from standard input.</p>
<p class="Pp">If the patch file contains more than one patch, <b>patch</b> tries
    to apply each of them as if they came from separate patch files. This means,
    among other things, that it is assumed that the name of the file to patch
    must be determined for each diff listing, and that the garbage before each
    diff listing contains interesting things such as file names and revision
    level, as mentioned previously.</p>
</section></section></div>
