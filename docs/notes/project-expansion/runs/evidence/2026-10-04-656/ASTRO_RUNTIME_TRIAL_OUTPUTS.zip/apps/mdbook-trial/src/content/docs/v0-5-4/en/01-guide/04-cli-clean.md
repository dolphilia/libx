---
title: "The clean command"
documentId: "mdbook:guide/src/cli/clean.md"
order: 11
licenseSource: "mdbook-guide"
documentContext: [{"kind": "source", "html": "<p>Fixed source: <a href=\"https://github.com/rust-lang/mdBook/blob/2ea30c00f00647d2b3f4c0f79b3e0e1eabc0b66d/guide/src/cli/clean.md\">guide/src/cli/clean.md</a>; mdBook 0.5.4. Documentation: MPL-2.0. Unofficial Libx presentation; internal links and code newline encoding adapted.</p>"}, {"kind": "editorial", "html": "<p>Code demonstration runtime: fixed bundled mdBook 0.5.4 code (MPL-2.0), Ace (BSD-3-Clause), Highlight.js 10.1.1 (BSD-3-Clause) and Clipboard.js 2.0.4 (MIT). Original notices are preserved. Modern clipboard transport and icon-descendant button labels are Libx integration adaptations; original code/editor text selection is retained. <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/ACE_LICENSE.txt\">Ace notice</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/HIGHLIGHT_LICENSE.txt\">Highlight.js notice</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/CLIPBOARD_LINKED_LICENSE.html\">Clipboard.js linked MIT notice</a>. Math equations use the original external MathJax 2.7.1 runtime (Apache-2.0; <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/MATHJAX_LICENSE.txt\">notice</a>). This external runtime is versioned but not part of the fixed local source snapshot.</p>"}]
prev: {"text": "test", "link": "/v0-5-4/en/01-guide/08-cli-test"}
next: {"text": "completions", "link": "/v0-5-4/en/01-guide/05-cli-completions"}
---

<div class="mdbook-guide">
<h1 id="the-clean-command"><a class="header" href="#the-clean-command">The clean command</a></h1>
<p>The clean command is used to delete the generated book and any other build
artifacts.</p>
<pre><code class="language-bash">mdbook clean&#10;</code></pre>
<h4 id="specify-a-directory"><a class="header" href="#specify-a-directory">Specify a directory</a></h4>
<p>The <code>clean</code> command can take a directory as an argument to use as the book’s
root instead of the current working directory.</p>
<pre><code class="language-bash">mdbook clean path/to/book&#10;</code></pre>
<h4 id="--dest-dir"><a class="header" href="#--dest-dir"><code>--dest-dir</code></a></h4>
<p>The <code>--dest-dir</code> (<code>-d</code>) option allows you to override the book’s output
directory, which will be deleted by this command. Relative paths are interpreted
relative to the current directory. If not specified it will default to the
value of the <code>build.build-dir</code> key in <code>book.toml</code>, or to <code>./book</code>.</p>
<pre><code class="language-bash">mdbook clean --dest-dir=path/to/book&#10;</code></pre>
<p><code>path/to/book</code> could be absolute or relative.</p>
</div>
