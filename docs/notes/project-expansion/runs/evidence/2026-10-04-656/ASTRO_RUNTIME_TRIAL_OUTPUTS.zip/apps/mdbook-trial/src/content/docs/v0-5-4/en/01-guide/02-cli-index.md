---
title: "Command-line tool"
documentId: "mdbook:guide/src/cli/README.md"
order: 5
licenseSource: "mdbook-guide"
documentContext: [{"kind": "source", "html": "<p>Fixed source: <a href=\"https://github.com/rust-lang/mdBook/blob/2ea30c00f00647d2b3f4c0f79b3e0e1eabc0b66d/guide/src/cli/README.md\">guide/src/cli/README.md</a>; mdBook 0.5.4. Documentation: MPL-2.0. Unofficial Libx presentation; internal links and code newline encoding adapted.</p>"}, {"kind": "editorial", "html": "<p>Code demonstration runtime: fixed bundled mdBook 0.5.4 code (MPL-2.0), Ace (BSD-3-Clause), Highlight.js 10.1.1 (BSD-3-Clause) and Clipboard.js 2.0.4 (MIT). Original notices are preserved. Modern clipboard transport and icon-descendant button labels are Libx integration adaptations; original code/editor text selection is retained. <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/ACE_LICENSE.txt\">Ace notice</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/HIGHLIGHT_LICENSE.txt\">Highlight.js notice</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/CLIPBOARD_LINKED_LICENSE.html\">Clipboard.js linked MIT notice</a>. Math equations use the original external MathJax 2.7.1 runtime (Apache-2.0; <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/MATHJAX_LICENSE.txt\">notice</a>). This external runtime is versioned but not part of the fixed local source snapshot.</p>"}]
prev: {"text": "Creating a book", "link": "/v0-5-4/en/01-guide/28-guide-creating"}
next: {"text": "init", "link": "/v0-5-4/en/01-guide/06-cli-init"}
---

<div class="mdbook-guide">
<h1 id="command-line-tool"><a class="header" href="#command-line-tool">Command-line tool</a></h1>
<p>The <code>mdbook</code> command-line tool is used to create and build books.
After you have <a href="/docs/mdbook-trial/v0-5-4/en/01-guide/29-guide-installation/">installed</a> <code>mdbook</code>, you can run the <code>mdbook help</code> command in your terminal to view the available commands.</p>
<p>This following sections provide in-depth information on the different commands available.</p>
<ul>
<li><a href="/docs/mdbook-trial/v0-5-4/en/01-guide/06-cli-init/"><code>mdbook init &#x3C;directory></code></a> — Creates a new book with minimal boilerplate to start with.</li>
<li><a href="/docs/mdbook-trial/v0-5-4/en/01-guide/03-cli-build/"><code>mdbook build</code></a> — Renders the book.</li>
<li><a href="/docs/mdbook-trial/v0-5-4/en/01-guide/09-cli-watch/"><code>mdbook watch</code></a> — Rebuilds the book any time a source file changes.</li>
<li><a href="/docs/mdbook-trial/v0-5-4/en/01-guide/07-cli-serve/"><code>mdbook serve</code></a> — Runs a web server to view the book, and rebuilds on changes.</li>
<li><a href="/docs/mdbook-trial/v0-5-4/en/01-guide/08-cli-test/"><code>mdbook test</code></a> — Tests Rust code samples.</li>
<li><a href="/docs/mdbook-trial/v0-5-4/en/01-guide/04-cli-clean/"><code>mdbook clean</code></a> — Deletes the rendered output.</li>
<li><a href="/docs/mdbook-trial/v0-5-4/en/01-guide/05-cli-completions/"><code>mdbook completions</code></a> — Support for shell auto-completion.</li>
</ul>
</div>
