---
title: "Contributors"
documentId: "mdbook:guide/src/misc/contributors.md"
order: 31
licenseSource: "mdbook-guide"
documentContext: [{"kind": "source", "html": "<p>Fixed source: <a href=\"https://github.com/rust-lang/mdBook/blob/2ea30c00f00647d2b3f4c0f79b3e0e1eabc0b66d/guide/src/misc/contributors.md\">guide/src/misc/contributors.md</a>; mdBook 0.5.4. Documentation: MPL-2.0. Unofficial Libx presentation; internal links and code newline encoding adapted.</p>"}, {"kind": "editorial", "html": "<p>Code demonstration runtime: fixed bundled mdBook 0.5.4 code (MPL-2.0), Ace (BSD-3-Clause), Highlight.js 10.1.1 (BSD-3-Clause) and Clipboard.js 2.0.4 (MIT). Original notices are preserved. Modern clipboard transport and icon-descendant button labels are Libx integration adaptations; original code/editor text selection is retained. <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/ACE_LICENSE.txt\">Ace notice</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/HIGHLIGHT_LICENSE.txt\">Highlight.js notice</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/CLIPBOARD_LINKED_LICENSE.html\">Clipboard.js linked MIT notice</a>. Math equations use the original external MathJax 2.7.1 runtime (Apache-2.0; <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/MATHJAX_LICENSE.txt\">notice</a>). This external runtime is versioned but not part of the fixed local source snapshot.</p>"}]
prev: {"text": "Alternative backends", "link": "/v0-5-4/en/01-guide/12-for_developers-backends"}
---

<div class="mdbook-guide">
<h1 id="contributors"><a class="header" href="#contributors">Contributors</a></h1>
<p>Here is a list of the contributors who have helped improving mdBook. Big
shout-out to them!</p>
<ul>
<li><a href="https://github.com/mdinger">mdinger</a></li>
<li>Kevin (<a href="https://github.com/kbknapp">kbknapp</a>)</li>
<li>Steve Klabnik (<a href="https://github.com/steveklabnik">steveklabnik</a>)</li>
<li>Adam Solove (<a href="https://github.com/asolove">asolove</a>)</li>
<li>Wayne Nilsen (<a href="https://github.com/waynenilsen">waynenilsen</a>)</li>
<li><a href="https://github.com/funkill">funnkill</a></li>
<li>Fu Gangqiang (<a href="https://github.com/FuGangqiang">FuGangqiang</a>)</li>
<li><a href="https://github.com/Michael-F-Bryan">Michael-F-Bryan</a></li>
<li>Chris Spiegel (<a href="https://github.com/cspiegel">cspiegel</a>)</li>
<li><a href="https://github.com/projektir">projektir</a></li>
<li><a href="https://github.com/Phaiax">Phaiax</a></li>
<li>Matt Ickstadt (<a href="https://github.com/mattico">mattico</a>)</li>
<li>Weihang Lo (<a href="https://github.com/weihanglo">weihanglo</a>)</li>
<li>Avision Ho (<a href="https://github.com/avisionh">avisionh</a>)</li>
<li>Vivek Akupatni (<a href="https://github.com/apatniv">apatniv</a>)</li>
<li>Eric Huss (<a href="https://github.com/ehuss">ehuss</a>)</li>
<li>Josh Rotenberg (<a href="https://github.com/joshrotenberg">joshrotenberg</a>)</li>
</ul>
<p>If you feel you’re missing from this list, feel free to add yourself in a PR.</p>
</div>
