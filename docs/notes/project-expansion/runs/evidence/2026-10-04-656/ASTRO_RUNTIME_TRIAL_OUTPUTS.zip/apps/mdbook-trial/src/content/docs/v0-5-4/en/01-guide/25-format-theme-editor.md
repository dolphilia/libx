---
title: "Editor"
documentId: "mdbook:guide/src/format/theme/editor.md"
order: 23
licenseSource: "mdbook-guide"
documentContext: [{"kind": "source", "html": "<p>Fixed source: <a href=\"https://github.com/rust-lang/mdBook/blob/2ea30c00f00647d2b3f4c0f79b3e0e1eabc0b66d/guide/src/format/theme/editor.md\">guide/src/format/theme/editor.md</a>; mdBook 0.5.4. Documentation: MPL-2.0. Unofficial Libx presentation; internal links and code newline encoding adapted.</p>"}, {"kind": "editorial", "html": "<p>Code demonstration runtime: fixed bundled mdBook 0.5.4 code (MPL-2.0), Ace (BSD-3-Clause), Highlight.js 10.1.1 (BSD-3-Clause) and Clipboard.js 2.0.4 (MIT). Original notices are preserved. Modern clipboard transport and icon-descendant button labels are Libx integration adaptations; original code/editor text selection is retained. <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/ACE_LICENSE.txt\">Ace notice</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/HIGHLIGHT_LICENSE.txt\">Highlight.js notice</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/CLIPBOARD_LINKED_LICENSE.html\">Clipboard.js linked MIT notice</a>. Math equations use the original external MathJax 2.7.1 runtime (Apache-2.0; <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/MATHJAX_LICENSE.txt\">notice</a>). This external runtime is versioned but not part of the fixed local source snapshot.</p>"}]
prev: {"text": "Syntax highlighting", "link": "/v0-5-4/en/01-guide/27-format-theme-syntax-highlighting"}
next: {"text": "MathJax support", "link": "/v0-5-4/en/01-guide/21-format-mathjax"}
---

<div class="mdbook-guide">
<h1 id="editor"><a class="header" href="#editor">Editor</a></h1>
<p>In addition to providing runnable code playgrounds, mdBook optionally allows them
to be editable. In order to enable editable code blocks, the following needs to
be added to the <em><strong>book.toml</strong></em>:</p>
<pre><code class="language-toml">[output.html.playground]&#10;editable = true&#10;</code></pre>
<p>After enabling editable code blocks, the <code>editable</code> attribute must be added to a
code block to make it editable:</p>
<pre><code class="language-markdown">```rust,editable&#10;fn main() {&#10;    let number = 5;&#10;    print!("{}", number);&#10;}&#10;```&#10;</code></pre>
<p>The above will result in this editable playground:</p>
<pre class="playground"><code class="language-rust editable edition2018">fn main() {&#10;    let number = 5;&#10;    print!("{}", number);&#10;}</code></pre>
<p>Note the new <code>Undo Changes</code> button in the editable playgrounds.</p>
<h2 id="customizing-the-editor"><a class="header" href="#customizing-the-editor">Customizing the editor</a></h2>
<p>By default, the editor is the <a href="https://ace.c9.io/">Ace</a> editor, but, if desired,
the functionality may be overridden by providing a different folder:</p>
<pre><code class="language-toml">[output.html.playground]&#10;editable = true&#10;editor = "/path/to/editor"&#10;</code></pre>
<p>Note that for the editor changes to function correctly, the <code>book.js</code> inside of
the <code>theme</code> folder will need to be overridden as it has some couplings with the
default Ace editor.</p>
</div>
