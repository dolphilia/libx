---
title: "Format"
documentId: "mdbook:guide/src/format/README.md"
order: 14
licenseSource: "mdbook-guide"
documentContext: [{"kind": "source", "html": "<p>Fixed source: <a href=\"https://github.com/rust-lang/mdBook/blob/2ea30c00f00647d2b3f4c0f79b3e0e1eabc0b66d/guide/src/format/README.md\">guide/src/format/README.md</a>; mdBook 0.5.4. Documentation: MPL-2.0. Unofficial Libx presentation; internal links and code newline encoding adapted.</p>"}]
---

<div class="mdbook-guide">
<h1 id="format"><a class="header" href="#format">Format</a></h1>
<p>In this section you will learn how to:</p>
<ul>
<li>Structure your book correctly</li>
<li>Format your <code>SUMMARY.md</code> file</li>
<li>Configure your book using <code>book.toml</code></li>
<li>Customize your theme</li>
</ul>
</div>
