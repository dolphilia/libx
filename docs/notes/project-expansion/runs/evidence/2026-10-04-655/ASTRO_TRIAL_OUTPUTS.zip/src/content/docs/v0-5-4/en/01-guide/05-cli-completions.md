---
title: "The completions command"
documentId: "mdbook:guide/src/cli/completions.md"
order: 5
licenseSource: "mdbook-guide"
documentContext: [{"kind": "source", "html": "<p>Fixed source: <a href=\"https://github.com/rust-lang/mdBook/blob/2ea30c00f00647d2b3f4c0f79b3e0e1eabc0b66d/guide/src/cli/completions.md\">guide/src/cli/completions.md</a>; mdBook 0.5.4. Documentation: MPL-2.0. Unofficial Libx presentation; internal links and code newline encoding adapted.</p>"}]
---

<div class="mdbook-guide">
<h1 id="the-completions-command"><a class="header" href="#the-completions-command">The completions command</a></h1>
<p>The completions command is used to generate auto-completions for some common shells.
This means when you type <code>mdbook</code> in your shell, you can then press your shell’s auto-complete key (usually the Tab key) and it may display what the valid options are, or finish partial input.</p>
<p>The completions first need to be installed for your shell:</p>
<pre><code class="language-bash"># bash&#10;mdbook completions bash > ~/.local/share/bash-completion/completions/mdbook&#10;# oh-my-zsh&#10;mdbook completions zsh > ~/.oh-my-zsh/completions/_mdbook&#10;autoload -U compinit &#x26;&#x26; compinit&#10;</code></pre>
<p>The command prints a completion script for the given shell.
Run <code>mdbook completions --help</code> for a list of supported shells.</p>
<p>Where to place the completions depend on which shell you are using and your operating system.
Consult your shell’s documentation for more information one where to place the script.</p>
</div>
