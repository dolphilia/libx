---
title: "Introduction"
documentId: "mdbook:guide/src/README.md"
order: 1
licenseSource: "mdbook-guide"
documentContext: [{"kind": "source", "html": "<p>Fixed source: <a href=\"https://github.com/rust-lang/mdBook/blob/2ea30c00f00647d2b3f4c0f79b3e0e1eabc0b66d/guide/src/README.md\">guide/src/README.md</a>; mdBook 0.5.4. Documentation: MPL-2.0. Unofficial Libx presentation; internal links and code newline encoding adapted.</p>"}]
---

<div class="mdbook-guide">
<h1 id="introduction"><a class="header" href="#introduction">Introduction</a></h1>
<style>
    .mdbook-version {
        position: absolute;
        right: 20px;
        top: 60px;
        background-color: var(--theme-popup-bg);
        border-radius: 8px;
        padding: 2px 5px 2px 5px;
        border: 1px solid var(--theme-popup-border);
        font-size: 0.9em;
    }
</style>
<div class="mdbook-version">
Version: 0.5.4
</div>
<p><strong>mdBook</strong> is a command line tool to create books with Markdown.
It is ideal for creating product or API documentation, tutorials, course materials or anything that requires a clean,
easily navigable and customizable presentation.</p>
<ul>
<li>Lightweight <a href="/docs/mdbook-trial/v0-5-4/en/01-guide/20-format-markdown/">Markdown</a> syntax helps you focus more on your content</li>
<li>Integrated <a href="/docs/mdbook-trial/v0-5-4/en/01-guide/30-guide-reading/#search">search</a> support</li>
<li>Color <a href="/docs/mdbook-trial/v0-5-4/en/01-guide/27-format-theme-syntax-highlighting/">syntax highlighting</a> for code blocks for many different languages</li>
<li><a href="/docs/mdbook-trial/v0-5-4/en/01-guide/24-format-theme-index/">Theme</a> files allow customizing the formatting of the output</li>
<li><a href="/docs/mdbook-trial/v0-5-4/en/01-guide/18-format-configuration-preprocessors/">Preprocessors</a> can provide extensions for custom syntax and modifying content</li>
<li><a href="/docs/mdbook-trial/v0-5-4/en/01-guide/19-format-configuration-renderers/">Backends</a> can render the output to multiple formats</li>
<li>Written in <a href="https://www.rust-lang.org/">Rust</a> for speed, safety, and simplicity</li>
<li>Automated testing of <a href="/docs/mdbook-trial/v0-5-4/en/01-guide/08-cli-test/">Rust code samples</a></li>
</ul>
<p>This guide is an example of what mdBook produces.
mdBook is used by the Rust programming language project, and <a href="https://doc.rust-lang.org/book/">The Rust Programming Language</a> book is another fine example of mdBook in action.</p>
<h2 id="contributing"><a class="header" href="#contributing">Contributing</a></h2>
<p>mdBook is free and open source. You can find the source code on
<a href="https://github.com/rust-lang/mdBook">GitHub</a> and issues and feature requests can be posted on
the <a href="https://github.com/rust-lang/mdBook/issues">GitHub issue tracker</a>. mdBook relies on the community to fix bugs and
add features: if you’d like to contribute, please read
the <a href="https://github.com/rust-lang/mdBook/blob/master/CONTRIBUTING.md">CONTRIBUTING</a> guide and consider opening
a <a href="https://github.com/rust-lang/mdBook/pulls">pull request</a>.</p>
<h2 id="license"><a class="header" href="#license">License</a></h2>
<p>The mdBook source and documentation are released under
the <a href="https://www.mozilla.org/MPL/2.0/">Mozilla Public License v2.0</a>.</p>
</div>
