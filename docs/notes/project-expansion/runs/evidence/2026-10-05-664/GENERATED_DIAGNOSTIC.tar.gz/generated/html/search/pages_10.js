var searchData=
[
  ['new_20in_20v1_201_200_0',['New in v1 1 0',['../md_doc_2tutorial.html#autotoc_md42',1,'Range-based For Loop (New in v1.1.0)'],['../md_doc_2tutorial.html#autotoc_md43',1,'Range-based For Loop (New in v1.1.0)']]],
  ['next_1',['What&apos;s next',['../md_doc_2tutorial.html#WhatsNext',1,'']]],
  ['number_2',['Querying Number',['../md_doc_2tutorial.html#QueryNumber',1,'']]]
];
