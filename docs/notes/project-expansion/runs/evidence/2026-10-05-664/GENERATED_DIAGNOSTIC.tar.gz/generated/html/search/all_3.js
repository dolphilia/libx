var searchData=
[
  ['8_0',['1.0-beta - 2015-04-8',['../md__c_h_a_n_g_e_l_o_g.html#autotoc_md24',1,'']]],
  ['8_2025_1',['Highlights in v1.1 (2016-8-25)',['../index.html#autotoc_md3',1,'']]]
];
