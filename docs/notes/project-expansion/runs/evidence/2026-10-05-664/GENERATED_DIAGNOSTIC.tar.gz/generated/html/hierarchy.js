var hierarchy =
[
    [ "Allocator", "classrapidjson_1_1_allocator.html", null ],
    [ "rapidjson::ASCII&lt; CharType &gt;", "structrapidjson_1_1_a_s_c_i_i.html", null ],
    [ "rapidjson::AutoUTF&lt; CharType &gt;", "structrapidjson_1_1_auto_u_t_f.html", null ],
    [ "rapidjson::AutoUTFInputStream&lt; CharType, InputByteStream &gt;", "classrapidjson_1_1_auto_u_t_f_input_stream.html", null ],
    [ "rapidjson::AutoUTFOutputStream&lt; CharType, OutputByteStream &gt;", "classrapidjson_1_1_auto_u_t_f_output_stream.html", null ],
    [ "rapidjson::BaseReaderHandler&lt; Encoding, Derived &gt;", "structrapidjson_1_1_base_reader_handler.html", null ],
    [ "rapidjson::BasicIStreamWrapper&lt; StreamType &gt;", "classrapidjson_1_1_basic_i_stream_wrapper.html", null ],
    [ "rapidjson::BasicOStreamWrapper&lt; StreamType &gt;", "classrapidjson_1_1_basic_o_stream_wrapper.html", null ],
    [ "rapidjson::CrtAllocator", "classrapidjson_1_1_crt_allocator.html", null ],
    [ "rapidjson::EncodedInputStream&lt; Encoding, InputByteStream &gt;", "classrapidjson_1_1_encoded_input_stream.html", null ],
    [ "rapidjson::EncodedInputStream&lt; UTF8&lt;&gt;, MemoryStream &gt;", "classrapidjson_1_1_encoded_input_stream_3_01_u_t_f8_3_4_00_01_memory_stream_01_4.html", null ],
    [ "rapidjson::EncodedOutputStream&lt; Encoding, OutputByteStream &gt;", "classrapidjson_1_1_encoded_output_stream.html", null ],
    [ "Encoding", "classrapidjson_1_1_encoding.html", null ],
    [ "rapidjson::FileReadStream", "classrapidjson_1_1_file_read_stream.html", null ],
    [ "rapidjson::FileWriteStream", "classrapidjson_1_1_file_write_stream.html", null ],
    [ "rapidjson::GenericArray&lt; Const, ValueT &gt;", "classrapidjson_1_1_generic_array.html", null ],
    [ "rapidjson::GenericInsituStringStream&lt; Encoding &gt;", "structrapidjson_1_1_generic_insitu_string_stream.html", null ],
    [ "rapidjson::GenericMember&lt; Encoding, Allocator &gt;", "structrapidjson_1_1_generic_member.html", null ],
    [ "rapidjson::GenericMemoryBuffer&lt; Allocator &gt;", "structrapidjson_1_1_generic_memory_buffer.html", null ],
    [ "rapidjson::GenericObject&lt; Const, ValueT &gt;", "classrapidjson_1_1_generic_object.html", null ],
    [ "rapidjson::GenericPointer&lt; ValueType, Allocator &gt;", "classrapidjson_1_1_generic_pointer.html", null ],
    [ "rapidjson::GenericReader&lt; SourceEncoding, TargetEncoding, StackAllocator &gt;", "classrapidjson_1_1_generic_reader.html", null ],
    [ "rapidjson::GenericSchemaDocument&lt; ValueT, Allocator &gt;", "classrapidjson_1_1_generic_schema_document.html", null ],
    [ "rapidjson::GenericStringBuffer&lt; Encoding, Allocator &gt;", "classrapidjson_1_1_generic_string_buffer.html", null ],
    [ "rapidjson::GenericStringRef&lt; CharType &gt;", "structrapidjson_1_1_generic_string_ref.html", null ],
    [ "rapidjson::GenericStringStream&lt; Encoding &gt;", "structrapidjson_1_1_generic_string_stream.html", null ],
    [ "rapidjson::GenericValue&lt; Encoding, Allocator &gt;", "classrapidjson_1_1_generic_value.html", [
      [ "rapidjson::GenericDocument< UTF8<> >", "classrapidjson_1_1_generic_document.html", null ]
    ] ],
    [ "rapidjson::GenericValue&lt; Encoding, MemoryPoolAllocator&lt;&gt; &gt;", "classrapidjson_1_1_generic_value.html", [
      [ "rapidjson::GenericDocument< Encoding, Allocator, StackAllocator >", "classrapidjson_1_1_generic_document.html", null ]
    ] ],
    [ "Handler", "classrapidjson_1_1_handler.html", null ],
    [ "rapidjson::GenericValue&lt; Encoding, Allocator &gt;::Number::I", "structrapidjson_1_1_generic_value_1_1_number_1_1_i.html", null ],
    [ "rapidjson::IGenericRemoteSchemaDocumentProvider&lt; SchemaDocumentType &gt;", "classrapidjson_1_1_i_generic_remote_schema_document_provider.html", null ],
    [ "rapidjson::internal::ISchemaStateFactory&lt; SchemaType &gt;", null, [
      [ "rapidjson::GenericSchemaValidator< SchemaDocument, BaseReaderHandler< UTF8< char >, void >, CrtAllocator >", "classrapidjson_1_1_generic_schema_validator.html", null ]
    ] ],
    [ "rapidjson::internal::ISchemaStateFactory&lt; SchemaDocumentType::SchemaType &gt;", null, [
      [ "rapidjson::GenericSchemaValidator< SchemaDocumentType, OutputHandler, StateAllocator >", "classrapidjson_1_1_generic_schema_validator.html", null ]
    ] ],
    [ "rapidjson::internal::ISchemaValidator", null, [
      [ "rapidjson::GenericSchemaValidator< SchemaDocument, BaseReaderHandler< UTF8< char >, void >, CrtAllocator >", "classrapidjson_1_1_generic_schema_validator.html", null ],
      [ "rapidjson::GenericSchemaValidator< SchemaDocumentType, OutputHandler, StateAllocator >", "classrapidjson_1_1_generic_schema_validator.html", null ]
    ] ],
    [ "std::iterator", null, [
      [ "rapidjson::GenericMemberIterator< true, Encoding, Allocator >", "classrapidjson_1_1_generic_member_iterator.html", null ],
      [ "rapidjson::GenericMemberIterator< false, Encoding, Allocator >", "classrapidjson_1_1_generic_member_iterator.html", null ],
      [ "rapidjson::Iterator< false, Encoding, Allocator >", "classrapidjson_1_1_generic_member_iterator.html", null ],
      [ "rapidjson::Iterator< true, Encoding, Allocator >", "classrapidjson_1_1_generic_member_iterator.html", null ],
      [ "rapidjson::GenericMemberIterator< Const, typename ValueT::EncodingType, typename ValueT::AllocatorType >", "classrapidjson_1_1_generic_member_iterator.html", null ],
      [ "rapidjson::GenericMemberIterator< true, typename ValueT::EncodingType, typename ValueT::AllocatorType >", "classrapidjson_1_1_generic_member_iterator.html", null ],
      [ "rapidjson::GenericMemberIterator< Const, Encoding, Allocator >", "classrapidjson_1_1_generic_member_iterator.html", null ]
    ] ],
    [ "rapidjson::Writer&lt; OutputStream, SourceEncoding, TargetEncoding, StackAllocator, writeFlags &gt;::Level", "structrapidjson_1_1_writer_1_1_level.html", null ],
    [ "rapidjson::MemoryPoolAllocator&lt; BaseAllocator &gt;", "classrapidjson_1_1_memory_pool_allocator.html", null ],
    [ "rapidjson::MemoryStream", "structrapidjson_1_1_memory_stream.html", null ],
    [ "rapidjson::ParseResult", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#structrapidjson_1_1_parse_result", null ],
    [ "rapidjson::SchemaValidatingReader&lt; parseFlags, InputStream, SourceEncoding, SchemaDocumentType, StackAllocator &gt;", "classrapidjson_1_1_schema_validating_reader.html", null ],
    [ "Stream", "classrapidjson_1_1_stream.html", null ],
    [ "rapidjson::StreamTraits&lt; Stream &gt;", "structrapidjson_1_1_stream_traits.html", null ],
    [ "rapidjson::StreamTraits&lt; GenericInsituStringStream&lt; Encoding &gt; &gt;", "structrapidjson_1_1_stream_traits_3_01_generic_insitu_string_stream_3_01_encoding_01_4_01_4.html", null ],
    [ "rapidjson::StreamTraits&lt; GenericStringStream&lt; Encoding &gt; &gt;", "structrapidjson_1_1_stream_traits_3_01_generic_string_stream_3_01_encoding_01_4_01_4.html", null ],
    [ "rapidjson::GenericPointer&lt; ValueType, Allocator &gt;::Token", "structrapidjson_1_1_generic_pointer_1_1_token.html", null ],
    [ "rapidjson::Transcoder&lt; SourceEncoding, TargetEncoding &gt;", "structrapidjson_1_1_transcoder.html", null ],
    [ "rapidjson::Transcoder&lt; Encoding, Encoding &gt;", "structrapidjson_1_1_transcoder_3_01_encoding_00_01_encoding_01_4.html", null ],
    [ "rapidjson::GenericValue&lt; Encoding, Allocator &gt;::Number::U", "structrapidjson_1_1_generic_value_1_1_number_1_1_u.html", null ],
    [ "rapidjson::UTF16&lt; CharType &gt;", "structrapidjson_1_1_u_t_f16.html", null ],
    [ "rapidjson::UTF16&lt; wchar_t &gt;", "structrapidjson_1_1_u_t_f16.html", [
      [ "rapidjson::UTF16BE< CharType >", "structrapidjson_1_1_u_t_f16_b_e.html", null ],
      [ "rapidjson::UTF16LE< CharType >", "structrapidjson_1_1_u_t_f16_l_e.html", null ]
    ] ],
    [ "rapidjson::UTF32&lt; CharType &gt;", "structrapidjson_1_1_u_t_f32.html", null ],
    [ "rapidjson::UTF32&lt; unsigned &gt;", "structrapidjson_1_1_u_t_f32.html", [
      [ "rapidjson::UTF32BE< CharType >", "structrapidjson_1_1_u_t_f32_b_e.html", null ],
      [ "rapidjson::UTF32LE< CharType >", "structrapidjson_1_1_u_t_f32_l_e.html", null ]
    ] ],
    [ "rapidjson::UTF8&lt; CharType &gt;", "structrapidjson_1_1_u_t_f8.html", null ],
    [ "rapidjson::Writer&lt; OutputStream, SourceEncoding, TargetEncoding, StackAllocator, writeFlags &gt;", "classrapidjson_1_1_writer.html", null ],
    [ "rapidjson::Writer&lt; OutputStream, UTF8&lt;&gt;, UTF8&lt;&gt;, CrtAllocator, kWriteDefaultFlags &gt;", "classrapidjson_1_1_writer.html", [
      [ "rapidjson::PrettyWriter< OutputStream, SourceEncoding, TargetEncoding, StackAllocator, writeFlags >", "classrapidjson_1_1_pretty_writer.html", null ]
    ] ]
];