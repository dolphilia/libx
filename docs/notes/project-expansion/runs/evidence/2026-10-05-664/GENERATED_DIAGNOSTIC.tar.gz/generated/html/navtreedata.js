/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "RapidJSON", "index.html", [
    [ "Change Log", "md__c_h_a_n_g_e_l_o_g.html", [
      [ "A fast JSON parser/generator for C++ with both SAX/DOM style API", "index.html#autotoc_md0", null ],
      [ "Build status", "index.html#autotoc_md1", null ],
      [ "Introduction", "index.html#autotoc_md2", null ],
      [ "Highlights in v1.1 (2016-8-25)", "index.html#autotoc_md3", null ],
      [ "Compatibility", "index.html#autotoc_md4", null ],
      [ "Installation", "index.html#autotoc_md5", null ],
      [ "Usage at a glance", "index.html#autotoc_md6", null ],
      [ "<a href=\"https://github.com/miloyip/rapidjson/compare/v1.1.0...HEAD\">Unreleased</a>", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md8", null ],
      [ "1.1.0 - 2016-08-25", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md9", [
        [ "Added", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md10", null ],
        [ "Fixed", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md11", null ],
        [ "Changed", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md12", null ]
      ] ],
      [ "<a href=\"https://github.com/miloyip/rapidjson/compare/v1.0.1...v1.0.2\">1.0.2</a> - 2015-05-14", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md13", [
        [ "Added", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md14", null ],
        [ "Fixed", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md15", null ],
        [ "Changed", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md16", null ]
      ] ],
      [ "<a href=\"https://github.com/miloyip/rapidjson/compare/v1.0.0...v1.0.1\">1.0.1</a> - 2015-04-25", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md17", [
        [ "Added", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md18", null ],
        [ "Fixed", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md19", null ]
      ] ],
      [ "<a href=\"https://github.com/miloyip/rapidjson/compare/v1.0-beta...v1.0.0\">1.0.0</a> - 2015-04-22", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md20", [
        [ "Added", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md21", null ],
        [ "Fixed", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md22", null ],
        [ "Removed", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md23", null ]
      ] ],
      [ "1.0-beta - 2015-04-8", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md24", [
        [ "Added", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md25", null ],
        [ "Changed", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md26", null ],
        [ "Removed", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md27", null ]
      ] ],
      [ "0.11 - 2012-11-16", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md28", null ],
      [ "0.1 - 2011-11-18", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md29", null ]
    ] ],
    [ "Features", "md_doc_2features.html", [
      [ "General", "md_doc_2features.html#autotoc_md31", null ],
      [ "Standard compliance", "md_doc_2features.html#autotoc_md32", null ],
      [ "Unicode", "md_doc_2features.html#autotoc_md33", null ],
      [ "API styles", "md_doc_2features.html#autotoc_md34", null ],
      [ "Parsing", "md_doc_2features.html#autotoc_md35", null ],
      [ "DOM (Document)", "md_doc_2features.html#autotoc_md36", null ],
      [ "Generation", "md_doc_2features.html#autotoc_md37", null ],
      [ "Stream", "md_doc_2features.html#autotoc_md38", null ],
      [ "Memory", "md_doc_2features.html#autotoc_md39", null ],
      [ "Miscellaneous", "md_doc_2features.html#autotoc_md40", null ]
    ] ],
    [ "Tutorial", "md_doc_2tutorial.html", [
      [ "Value &amp; Document", "md_doc_2tutorial.html#ValueDocument", null ],
      [ "Query Value", "md_doc_2tutorial.html#QueryValue", [
        [ "Query Array", "md_doc_2tutorial.html#QueryArray", [
          [ "Range-based For Loop (New in v1.1.0)", "md_doc_2tutorial.html#autotoc_md42", null ]
        ] ],
        [ "Query Object", "md_doc_2tutorial.html#QueryObject", [
          [ "Range-based For Loop (New in v1.1.0)", "md_doc_2tutorial.html#autotoc_md43", null ]
        ] ],
        [ "Querying Number", "md_doc_2tutorial.html#QueryNumber", null ],
        [ "Query String", "md_doc_2tutorial.html#QueryString", null ],
        [ "Comparing values", "md_doc_2tutorial.html#autotoc_md44", null ]
      ] ],
      [ "Create/Modify Values", "md_doc_2tutorial.html#CreateModifyValues", [
        [ "Change Value Type", "md_doc_2tutorial.html#ChangeValueType", [
          [ "Overloaded Constructors", "md_doc_2tutorial.html#autotoc_md45", null ]
        ] ],
        [ "Move Semantics", "md_doc_2tutorial.html#MoveSemantics", [
          [ "Move semantics and temporary values", "md_doc_2tutorial.html#TemporaryValues", null ]
        ] ],
        [ "Create String", "md_doc_2tutorial.html#CreateString", null ],
        [ "Modify Array", "md_doc_2tutorial.html#ModifyArray", null ],
        [ "Modify Object", "md_doc_2tutorial.html#ModifyObject", null ],
        [ "Deep Copy Value", "md_doc_2tutorial.html#DeepCopyValue", null ],
        [ "Swap Values", "md_doc_2tutorial.html#SwapValues", null ]
      ] ],
      [ "What's next", "md_doc_2tutorial.html#WhatsNext", null ]
    ] ],
    [ "Pointer", "md_doc_2pointer.html", [
      [ "JSON Pointer", "md_doc_2pointer.html#JsonPointer", null ],
      [ "Basic Usage", "md_doc_2pointer.html#BasicUsage", null ],
      [ "Helper Functions", "md_doc_2pointer.html#HelperFunctions", null ],
      [ "Resolving Pointer", "md_doc_2pointer.html#ResolvingPointer", [
        [ "Resolving Minus Sign Token", "md_doc_2pointer.html#autotoc_md47", null ],
        [ "Resolving Document and Value", "md_doc_2pointer.html#autotoc_md48", null ]
      ] ],
      [ "Error Handling", "md_doc_2pointer.html#ErrorHandling", null ],
      [ "URI Fragment Representation", "md_doc_2pointer.html#URIFragment", null ],
      [ "Stringify", "md_doc_2pointer.html#autotoc_md49", null ],
      [ "User-Supplied Tokens", "md_doc_2pointer.html#UserSuppliedTokens", null ]
    ] ],
    [ "Stream", "md_doc_2stream.html", [
      [ "Memory Streams", "md_doc_2stream.html#MemoryStreams", [
        [ "StringStream (Input)", "md_doc_2stream.html#StringStream", null ],
        [ "StringBuffer (Output)", "md_doc_2stream.html#StringBuffer", null ]
      ] ],
      [ "File Streams", "md_doc_2stream.html#FileStreams", [
        [ "FileReadStream (Input)", "md_doc_2stream.html#FileReadStream", null ],
        [ "FileWriteStream (Output)", "md_doc_2stream.html#FileWriteStream", null ]
      ] ],
      [ "iostream Wrapper", "md_doc_2stream.html#iostreamWrapper", [
        [ "IStreamWrapper", "md_doc_2stream.html#IStreamWrapper", null ],
        [ "OStreamWrapper", "md_doc_2stream.html#OStreamWrapper", null ]
      ] ],
      [ "Encoded Streams", "md_doc_2stream.html#EncodedStreams", [
        [ "EncodedInputStream", "md_doc_2stream.html#EncodedInputStream", null ],
        [ "EncodedOutputStream", "md_doc_2stream.html#EncodedOutputStream", null ],
        [ "AutoUTFInputStream", "md_doc_2stream.html#AutoUTFInputStream", null ],
        [ "AutoUTFOutputStream", "md_doc_2stream.html#AutoUTFOutputStream", null ]
      ] ],
      [ "Custom Stream", "md_doc_2stream.html#CustomStream", [
        [ "Example: istream wrapper", "md_doc_2stream.html#ExampleIStreamWrapper", null ],
        [ "Example: ostream wrapper", "md_doc_2stream.html#ExampleOStreamWrapper", null ]
      ] ],
      [ "Summary", "md_doc_2stream.html#Summary", null ]
    ] ],
    [ "Encoding", "md_doc_2encoding.html", [
      [ "Unicode", "md_doc_2encoding.html#Unicode", [
        [ "Unicode Transformation Format", "md_doc_2encoding.html#UTF", null ],
        [ "Character Type", "md_doc_2encoding.html#CharacterType", null ],
        [ "AutoUTF", "md_doc_2encoding.html#AutoUTF", null ],
        [ "ASCII", "md_doc_2encoding.html#ASCII", null ]
      ] ],
      [ "Validation &amp; Transcoding", "md_doc_2encoding.html#ValidationTranscoding", [
        [ "Transcoder", "md_doc_2encoding.html#Transcoder", null ]
      ] ]
    ] ],
    [ "DOM", "md_doc_2dom.html", [
      [ "Template", "md_doc_2dom.html#Template", [
        [ "Encoding", "md_doc_2dom.html#Encoding", null ],
        [ "Allocator", "md_doc_2dom.html#Allocator", null ]
      ] ],
      [ "Parsing", "md_doc_2dom.html#Parsing", [
        [ "Parse Error", "md_doc_2dom.html#ParseError", null ],
        [ "In Situ Parsing", "md_doc_2dom.html#InSituParsing", null ],
        [ "Transcoding and Validation", "md_doc_2dom.html#TranscodingAndValidation", null ]
      ] ],
      [ "Techniques", "md_doc_2dom.html#Techniques", [
        [ "DOM as SAX Event Publisher", "md_doc_2dom.html#autotoc_md53", null ],
        [ "User Buffer", "md_doc_2dom.html#UserBuffer", null ]
      ] ]
    ] ],
    [ "SAX", "md_doc_2sax.html", [
      [ "Reader", "md_doc_2sax.html#Reader", [
        [ "Handler", "md_doc_2sax.html#Handler", null ],
        [ "GenericReader", "md_doc_2sax.html#GenericReader", null ],
        [ "Parsing", "md_doc_2sax.html#SaxParsing", null ]
      ] ],
      [ "Writer", "md_doc_2sax.html#Writer", [
        [ "Template", "md_doc_2sax.html#WriterTemplate", null ],
        [ "PrettyWriter", "md_doc_2sax.html#PrettyWriter", null ],
        [ "Completeness and Reset", "md_doc_2sax.html#CompletenessReset", null ]
      ] ],
      [ "Techniques", "md_doc_2sax.html#SaxTechniques", [
        [ "Parsing JSON to Custom Data Structure", "md_doc_2sax.html#CustomDataStructure", null ],
        [ "Filtering of JSON", "md_doc_2sax.html#Filtering", null ]
      ] ]
    ] ],
    [ "Schema", "md_doc_2schema.html", [
      [ "Basic Usage", "md_doc_2schema.html#autotoc_md56", null ],
      [ "Validation during parsing/serialization", "md_doc_2schema.html#autotoc_md57", [
        [ "DOM parsing", "md_doc_2schema.html#autotoc_md58", null ],
        [ "SAX parsing", "md_doc_2schema.html#autotoc_md59", null ],
        [ "Serialization", "md_doc_2schema.html#autotoc_md60", null ]
      ] ],
      [ "Remote Schema", "md_doc_2schema.html#autotoc_md61", null ],
      [ "Conformance", "md_doc_2schema.html#autotoc_md62", [
        [ "Regular Expression", "md_doc_2schema.html#autotoc_md63", null ]
      ] ],
      [ "Performance", "md_doc_2schema.html#autotoc_md64", null ]
    ] ],
    [ "Performance", "md_doc_2performance.html", [
      [ "Third-party benchmarks", "md_doc_2performance.html#autotoc_md66", null ]
    ] ],
    [ "Internals", "md_doc_2internals.html", [
      [ "Architecture", "md_doc_2internals.html#Architecture", [
        [ "SAX and DOM", "md_doc_2internals.html#autotoc_md68", null ],
        [ "Utility Classes", "md_doc_2internals.html#autotoc_md69", null ]
      ] ],
      [ "Value", "md_doc_2internals.html#Value", [
        [ "Data Layout", "md_doc_2internals.html#DataLayout", null ],
        [ "Flags", "md_doc_2internals.html#Flags", null ],
        [ "Short-String Optimization", "md_doc_2internals.html#ShortString", null ]
      ] ],
      [ "Allocator", "md_doc_2internals.html#InternalAllocator", [
        [ "MemoryPoolAllocator", "md_doc_2internals.html#MemoryPoolAllocator", null ]
      ] ],
      [ "Parsing Optimization", "md_doc_2internals.html#ParsingOptimization", [
        [ "Skip Whitespaces with SIMD", "md_doc_2internals.html#SkipwhitespaceWithSIMD", [
          [ "Page boundary issue", "md_doc_2internals.html#autotoc_md70", null ]
        ] ],
        [ "Local Stream Copy", "md_doc_2internals.html#LocalStreamCopy", null ],
        [ "Parsing to Double", "md_doc_2internals.html#ParsingDouble", null ]
      ] ],
      [ "Generation Optimization", "md_doc_2internals.html#GenerationOptimization", [
        [ "Integer-to-String conversion", "md_doc_2internals.html#itoa", null ],
        [ "Double-to-String conversion", "md_doc_2internals.html#dtoa", null ]
      ] ],
      [ "Parser", "md_doc_2internals.html#Parser", [
        [ "Iterative Parser", "md_doc_2internals.html#IterativeParser", [
          [ "Grammar", "md_doc_2internals.html#IterativeParserGrammar", null ],
          [ "Parsing Table", "md_doc_2internals.html#IterativeParserParsingTable", null ],
          [ "Implementation", "md_doc_2internals.html#IterativeParserImplementation", null ]
        ] ]
      ] ]
    ] ],
    [ "FAQ", "md_doc_2faq.html", [
      [ "General", "md_doc_2faq.html#autotoc_md72", null ],
      [ "JSON", "md_doc_2faq.html#autotoc_md73", null ],
      [ "DOM and SAX", "md_doc_2faq.html#autotoc_md74", null ],
      [ "Document/Value (DOM)", "md_doc_2faq.html#autotoc_md75", null ],
      [ "Reader/Writer (SAX)", "md_doc_2faq.html#autotoc_md76", null ],
      [ "Unicode", "md_doc_2faq.html#autotoc_md77", null ],
      [ "Stream", "md_doc_2faq.html#autotoc_md78", null ],
      [ "Performance", "md_doc_2faq.html#autotoc_md79", null ],
      [ "Gossip", "md_doc_2faq.html#autotoc_md80", null ]
    ] ],
    [ "Topics", "topics.html", "topics" ],
    [ "Namespace Members", "namespacemembers.html", [
      [ "All", "namespacemembers.html", null ],
      [ "Functions", "namespacemembers_func.html", null ],
      [ "Typedefs", "namespacemembers_type.html", null ],
      [ "Enumerations", "namespacemembers_enum.html", null ],
      [ "Enumerator", "namespacemembers_eval.html", null ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ],
        [ "Typedefs", "functions_type.html", null ],
        [ "Related Symbols", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"allocators_8h_source.html",
"diyfp_8h_source.html",
"md_doc_2schema.html#autotoc_md64"
];

const SYNCONMSG = 'click to disable panel synchronization';
const SYNCOFFMSG = 'click to enable panel synchronization';
const LISTOFALLMEMBERS = 'List of all members';