var group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s =
[
    [ "rapidjson::ParseResult", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#structrapidjson_1_1_parse_result", [
      [ "ParseResult", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#a0f03679d5fa2736d9e351541e767fac1", null ],
      [ "ParseResult", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ad15710045513f13ba526753c4a2cb59b", null ],
      [ "Clear", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#a17c9f7f81675283393222658d613000f", null ],
      [ "Code", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#a3c6a1f7b7dc21363a255eb10a3c0e00e", null ],
      [ "IsError", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ab6d87c6ce9c849f35e902fbe23f485c4", null ],
      [ "Offset", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#a85036788b0cfd1c676900de6f8260bd6", null ],
      [ "operator bool", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#a1a875ffec30790e99225d5828975fd32", null ],
      [ "Set", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#a40c0bd4d6c535c57acbb5c2e656bea38", null ]
    ] ],
    [ "RAPIDJSON_ERROR_CHARTYPE", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ga7e4636fd48d0148f102b8a13f0539d8c", null ],
    [ "RAPIDJSON_ERROR_STRING", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gabe2e1bd1349e5a7d6c1af78c05a98f0d", null ],
    [ "RAPIDJSON_PARSE_ERROR", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gae3689840fa6e89a241313f33b602f865", null ],
    [ "RAPIDJSON_PARSE_ERROR_NORETURN", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ga7f8c4265b2edda78568ae3338aaf1461", null ],
    [ "rapidjson::GetParseErrorFunc", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ga71e87993751dbd0e3259d90194a265b3", null ],
    [ "rapidjson::ParseErrorCode", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ga7d3acf640886b1f2552dc8c4cd6dea60", [
      [ "rapidjson::kParseErrorNone", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a86a60b723dca32df5debab2c3db4235f", null ],
      [ "rapidjson::kParseErrorDocumentEmpty", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a06183076357ebd9eca228666f614c286", null ],
      [ "rapidjson::kParseErrorDocumentRootNotSingular", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a2022599bcd4f64d58885a026f95751d5", null ],
      [ "rapidjson::kParseErrorValueInvalid", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60ab7fa69bce0c393cf3a2b6065111f2f57", null ],
      [ "rapidjson::kParseErrorObjectMissName", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60ab707b848425668e765def25554735242", null ],
      [ "rapidjson::kParseErrorObjectMissColon", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a58e952084a0dfdbc5630f624252aef5c", null ],
      [ "rapidjson::kParseErrorObjectMissCommaOrCurlyBracket", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a2a81a684f39fc882ec99f07e86343f73", null ],
      [ "rapidjson::kParseErrorArrayMissCommaOrSquareBracket", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a1a4ac97731f997e9591b40f98ecd9f93", null ],
      [ "rapidjson::kParseErrorStringUnicodeEscapeInvalidHex", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a23c38bf88b8448555c0eb41e1735bd92", null ],
      [ "rapidjson::kParseErrorStringUnicodeSurrogateInvalid", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a636209a2e516fbdb4db5ad0a83a6b386", null ],
      [ "rapidjson::kParseErrorStringEscapeInvalid", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a8dd0af5e6103a6503c61c38cb2b0bab9", null ],
      [ "rapidjson::kParseErrorStringMissQuotationMark", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60af7daa91caa53abb881ea231a874a4f40", null ],
      [ "rapidjson::kParseErrorStringInvalidEncoding", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a62ce0f5c74e4ab34ac325d2adda8fa8f", null ],
      [ "rapidjson::kParseErrorNumberTooBig", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a240cebadea89f7282ab263b5a22c9805", null ],
      [ "rapidjson::kParseErrorNumberMissFraction", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60ac840ece3ba6874fe6f16c01ebb71031f", null ],
      [ "rapidjson::kParseErrorNumberMissExponent", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a28a1c720ae63560780ccd992dc999ab7", null ],
      [ "rapidjson::kParseErrorTermination", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60ab250f87c3d8454c579364b5a0f697a50", null ],
      [ "rapidjson::kParseErrorUnspecificSyntaxError", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gga7d3acf640886b1f2552dc8c4cd6dea60a7abf1a337294d984a3f4d18b5843fb24", null ]
    ] ],
    [ "rapidjson::PointerParseErrorCode", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gade540ee4cc2a416c23b8ee2c12393c7b", [
      [ "rapidjson::kPointerParseErrorNone", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ggade540ee4cc2a416c23b8ee2c12393c7ba9094f236b2ec70c42f1ea91dffc1e39b", null ],
      [ "rapidjson::kPointerParseErrorTokenMustBeginWithSolidus", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ggade540ee4cc2a416c23b8ee2c12393c7ba2f2f8b238e201b7d540e8914bbfd2bed", null ],
      [ "rapidjson::kPointerParseErrorInvalidEscape", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ggade540ee4cc2a416c23b8ee2c12393c7ba907c9fe4e541b257513e3a18635379f7", null ],
      [ "rapidjson::kPointerParseErrorInvalidPercentEncoding", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ggade540ee4cc2a416c23b8ee2c12393c7ba29831a02b8ee23a05d552b47f4d64d28", null ],
      [ "rapidjson::kPointerParseErrorCharacterMustPercentEncode", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#ggade540ee4cc2a416c23b8ee2c12393c7bae244a98f53279fda5a750f847b81c54f", null ]
    ] ],
    [ "rapidjson::GetParseError_En", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html#gae50ed9b35d538b82461145f07038fd0b", null ]
];