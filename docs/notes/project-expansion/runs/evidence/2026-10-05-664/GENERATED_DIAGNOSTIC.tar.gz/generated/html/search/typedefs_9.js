var searchData=
[
  ['reader_0',['Reader',['../namespacerapidjson.html#ad5310edd1226f5b3ea82dc0d4d3740c6',1,'rapidjson']]],
  ['reference_1',['Reference',['../classrapidjson_1_1_generic_member_iterator.html#a915a1b6f0a0bbe6a1df69571a789e348',1,'rapidjson::GenericMemberIterator']]]
];
