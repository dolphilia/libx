---
title: "Advanced features"
order: 7
categoryOrder: 1
documentContext: [{"kind":"source","html":"<h2 id=\"source-and-notices\">Source and notices</h2>\n<p>Source: jq 1.8 Manual by Stephen Dolan / jq project contributors. Original copyright notice: jq is copyright (C) 2012 Stephen Dolan. Fixed source: jq 1.8.2, commit 34f7186b86743a083a589741b6cea95293524108. Documentation is licensed under CC BY 3.0 Unported. This English edition is split and reformatted from the original; the Japanese edition is an unofficial translation from English. No upstream endorsement is implied.</p>\n<p><a href=\"https://jqlang.org/manual/v1.8/\">Original manual</a> · <a href=\"https://github.com/jqlang/jq/blob/34f7186b86743a083a589741b6cea95293524108/docs/content/manual/v1.8/manual.yml\">Fixed source</a> · <a href=\"https://creativecommons.org/licenses/by/3.0/\">License</a> · <a href=\"/docs/jq/v1-8-2/en/02-license/01-original-notices/\">Original notices</a> · <a href=\"/docs/jq/v1-8-2/en/02-license/02-cc-by-3-0/\">Full legal code</a></p>"}]
---

<div class="jq-upstream-field" data-source-key="sections/6/title">

<h2 id="advanced-features">Advanced features</h2>

</div>

<div class="jq-upstream-field" data-source-key="sections/6/body">

<p>Variables are an absolute necessity in most programming languages, but
they're relegated to an "advanced feature" in jq.</p>




<p>In most languages, variables are the only means of passing around
data. If you calculate a value, and you want to use it more than once,
you'll need to store it in a variable. To pass a value to another part
of the program, you'll need that part of the program to define a
variable (as a function parameter, object member, or whatever) in
which to place the data.</p>




<p>It is also possible to define functions in jq, although this is
is a feature whose biggest use is defining jq's standard library
(many jq functions such as <code>map</code> and <code>select</code> are in fact written
in jq).</p>




<p>jq has reduction operators, which are very powerful but a bit
tricky.  Again, these are mostly used internally, to define some
useful bits of jq's standard library.</p>




<p>It may not be obvious at first, but jq is all about generators
(yes, as often found in other languages).  Some utilities are
provided to help deal with generators.</p>




<p>Some minimal I/O support (besides reading JSON from standard
input, and writing JSON to standard output) is available.</p>




<p>Finally, there is a module/library system.</p>

</div>

<div class="jq-upstream-field" data-source-key="sections/6/entries/0/title">

<h3 id="variable-symbolic-binding-operator">Variable / Symbolic Binding Operator: <code>... as $identifier | ...</code></h3>

</div>

<div class="jq-upstream-field" data-source-key="sections/6/entries/0/body">

<p>In jq, all filters have an input and an output, so manual
plumbing is not necessary to pass a value from one part of a program
to the next. Many expressions, for instance <code>a + b</code>, pass their input
to two distinct subexpressions (here <code>a</code> and <code>b</code> are both passed the
same input), so variables aren't usually necessary in order to use a
value twice.</p>




<p>For instance, calculating the average value of an array of numbers
requires a few variables in most languages - at least one to hold the
array, perhaps one for each element or for a loop counter. In jq, it's
simply <code>add / length</code> - the <code>add</code> expression is given the array and
produces its sum, and the <code>length</code> expression is given the array and
produces its length.</p>




<p>So, there's generally a cleaner way to solve most problems in jq than
defining variables. Still, sometimes they do make things easier, so jq
lets you define variables using <code>expression as $variable</code>. All
variable names start with <code>$</code>. Here's a slightly uglier version of the
array-averaging example:</p>




<pre><code>length as $array_length | add / $array_length
</code></pre>




<p>We'll need a more complicated problem to find a situation where using
variables actually makes our lives easier.</p>




<p>Suppose we have an array of blog posts, with "author" and "title"
fields, and another object which is used to map author usernames to
real names. Our input looks like:</p>




<pre><code>{"posts": [{"title": "First post", "author": "anon"},
           {"title": "A well-written article", "author": "person1"}],
 "realnames": {"anon": "Anonymous Coward",
               "person1": "Person McPherson"}}
</code></pre>




<p>We want to produce the posts with the author field containing a real
name, as in:</p>




<pre><code>{"title": "First post", "author": "Anonymous Coward"}
{"title": "A well-written article", "author": "Person McPherson"}
</code></pre>




<p>We use a variable, <code>$names</code>, to store the realnames object, so that we
can refer to it later when looking up author usernames:</p>




<pre><code>.realnames as $names | .posts[] | {title, author: $names[.author]}
</code></pre>




<p>The expression <code>exp as $x | ...</code> means: for each value of expression
<code>exp</code>, run the rest of the pipeline with the entire original input, and
with <code>$x</code> set to that value.  Thus <code>as</code> functions as something of a
foreach loop.</p>




<p>Just as <code>{foo}</code> is a handy way of writing <code>{foo: .foo}</code>, so
<code>{$foo}</code> is a handy way of writing <code>{foo: $foo}</code>.</p>




<p>Multiple variables may be declared using a single <code>as</code> expression by
providing a pattern that matches the structure of the input
(this is known as "destructuring"):</p>




<pre><code>. as {realnames: $names, posts: [$first, $second]} | ...
</code></pre>




<p>The variable declarations in array patterns (e.g., <code>. as
[$first, $second]</code>) bind to the elements of the array in from
the element at index zero on up, in order.  When there is no
value at the index for an array pattern element, <code>null</code> is
bound to that variable.</p>




<p>Variables are scoped over the rest of the expression that defines
them, so</p>




<pre><code>.realnames as $names | (.posts[] | {title, author: $names[.author]})
</code></pre>




<p>will work, but</p>




<pre><code>(.realnames as $names | .posts[]) | {title, author: $names[.author]}
</code></pre>




<p>won't.</p>




<p>For programming language theorists, it's more accurate to
say that jq variables are lexically-scoped bindings.  In
particular there's no way to change the value of a binding;
one can only setup a new binding with the same name, but which
will not be visible where the old one was.</p>

</div>

<!-- jq-example:sections/6/entries/0/examples/0:start -->

#### Example 1

Command

```sh
jq '.bar as $x | .foo | . + $x'
```

Input

```text
{"foo":10, "bar":200}
```

Output 1

```text
210
```

<!-- jq-example:sections/6/entries/0/examples/0:end -->

<!-- jq-example:sections/6/entries/0/examples/1:start -->

#### Example 2

Command

```sh
jq '. as $i|[(.*2|. as $i| $i), $i]'
```

Input

```text
5
```

Output 1

```text
[10,5]
```

<!-- jq-example:sections/6/entries/0/examples/1:end -->

<!-- jq-example:sections/6/entries/0/examples/2:start -->

#### Example 3

Command

```sh
jq '. as [$a, $b, {c: $c}] | $a + $b + $c'
```

Input

```text
[2, 3, {"c": 4, "d": 5}]
```

Output 1

```text
9
```

<!-- jq-example:sections/6/entries/0/examples/2:end -->

<!-- jq-example:sections/6/entries/0/examples/3:start -->

#### Example 4

Command

```sh
jq '.[] as [$a, $b] | {a: $a, b: $b}'
```

Input

```text
[[0], [0, 1], [2, 1, 0]]
```

Output 1

```text
{"a":0,"b":null}
```

Output 2

```text
{"a":0,"b":1}
```

Output 3

```text
{"a":2,"b":1}
```

<!-- jq-example:sections/6/entries/0/examples/3:end -->

<div class="jq-upstream-field" data-source-key="sections/6/entries/1/title">

<h3 id="destructuring-alternative-operator">Destructuring Alternative Operator: <code>?//</code></h3>

</div>

<div class="jq-upstream-field" data-source-key="sections/6/entries/1/body">

<p>The destructuring alternative operator provides a concise mechanism
for destructuring an input that can take one of several forms.</p>




<p>Suppose we have an API that returns a list of resources and events
associated with them, and we want to get the user_id and timestamp of
the first event for each resource. The API (having been clumsily
converted from XML) will only wrap the events in an array if the resource
has multiple events:</p>




<pre><code>{"resources": [{"id": 1, "kind": "widget", "events": {"action": "create", "user_id": 1, "ts": 13}},
               {"id": 2, "kind": "widget", "events": [{"action": "create", "user_id": 1, "ts": 14}, {"action": "destroy", "user_id": 1, "ts": 15}]}]}
</code></pre>




<p>We can use the destructuring alternative operator to handle this structural change simply:</p>




<pre><code>.resources[] as {$id, $kind, events: {$user_id, $ts}} ?// {$id, $kind, events: [{$user_id, $ts}]} | {$user_id, $kind, $id, $ts}
</code></pre>




<p>Or, if we aren't sure if the input is an array of values or an object:</p>




<pre><code>.[] as [$id, $kind, $user_id, $ts] ?// {$id, $kind, $user_id, $ts} | ...
</code></pre>




<p>Each alternative need not define all of the same variables, but all named
variables will be available to the subsequent expression. Variables not
matched in the alternative that succeeded will be <code>null</code>:</p>




<pre><code>.resources[] as {$id, $kind, events: {$user_id, $ts}} ?// {$id, $kind, events: [{$first_user_id, $first_ts}]} | {$user_id, $first_user_id, $kind, $id, $ts, $first_ts}
</code></pre>




<p>Additionally, if the subsequent expression returns an error, the
alternative operator will attempt to try the next binding. Errors
that occur during the final alternative are passed through.</p>




<pre><code>[[3]] | .[] as [$a] ?// [$b] | if $a != null then error("err: \($a)") else {$a,$b} end
</code></pre>

</div>

<!-- jq-example:sections/6/entries/1/examples/0:start -->

#### Example 1

Command

```sh
jq '.[] as {$a, $b, c: {$d, $e}} ?// {$a, $b, c: [{$d, $e}]} | {$a, $b, $d, $e}'
```

Input

```text
[{"a": 1, "b": 2, "c": {"d": 3, "e": 4}}, {"a": 1, "b": 2, "c": [{"d": 3, "e": 4}]}]
```

Output 1

```text
{"a":1,"b":2,"d":3,"e":4}
```

Output 2

```text
{"a":1,"b":2,"d":3,"e":4}
```

<!-- jq-example:sections/6/entries/1/examples/0:end -->

<!-- jq-example:sections/6/entries/1/examples/1:start -->

#### Example 2

Command

```sh
jq '.[] as {$a, $b, c: {$d}} ?// {$a, $b, c: [{$e}]} | {$a, $b, $d, $e}'
```

Input

```text
[{"a": 1, "b": 2, "c": {"d": 3, "e": 4}}, {"a": 1, "b": 2, "c": [{"d": 3, "e": 4}]}]
```

Output 1

```text
{"a":1,"b":2,"d":3,"e":null}
```

Output 2

```text
{"a":1,"b":2,"d":null,"e":4}
```

<!-- jq-example:sections/6/entries/1/examples/1:end -->

<!-- jq-example:sections/6/entries/1/examples/2:start -->

#### Example 3

Command

```sh
jq '.[] as [$a] ?// [$b] | if $a != null then error("err: \($a)") else {$a,$b} end'
```

Input

```text
[[3]]
```

Output 1

```text
{"a":null,"b":3}
```

<!-- jq-example:sections/6/entries/1/examples/2:end -->

<div class="jq-upstream-field" data-source-key="sections/6/entries/2/title">

<h3 id="defining-functions">Defining Functions</h3>

</div>

<div class="jq-upstream-field" data-source-key="sections/6/entries/2/body">

<p>You can give a filter a name using "def" syntax:</p>




<pre><code>def increment: . + 1;
</code></pre>




<p>From then on, <code>increment</code> is usable as a filter just like a
builtin function (in fact, this is how many of the builtins
are defined). A function may take arguments:</p>




<pre><code>def map(f): [.[] | f];
</code></pre>




<p>Arguments are passed as <em>filters</em> (functions with no
arguments), <em>not</em> as values. The same argument may be
referenced multiple times with different inputs (here <code>f</code> is
run for each element of the input array).  Arguments to a
function work more like callbacks than like value arguments.
This is important to understand.  Consider:</p>




<pre><code>def foo(f): f|f;
5|foo(.*2)
</code></pre>




<p>The result will be 20 because <code>f</code> is <code>.*2</code>, and during the
first invocation of <code>f</code> <code>.</code> will be 5, and the second time it
will be 10 (5 * 2), so the result will be 20.  Function
arguments are filters, and filters expect an input when
invoked.</p>




<p>If you want the value-argument behaviour for defining simple
functions, you can just use a variable:</p>




<pre><code>def addvalue(f): f as $f | map(. + $f);
</code></pre>




<p>Or use the short-hand:</p>




<pre><code>def addvalue($f): ...;
</code></pre>




<p>With either definition, <code>addvalue(.foo)</code> will add the current
input's <code>.foo</code> field to each element of the array.  Do note
that calling <code>addvalue(.[])</code> will cause the <code>map(. + $f)</code> part
to be evaluated once per value in the value of <code>.</code> at the call
site.</p>




<p>Multiple definitions using the same function name are allowed.
Each re-definition replaces the previous one for the same
number of function arguments, but only for references from
functions (or main program) subsequent to the re-definition.
See also the section below on scoping.</p>

</div>

<!-- jq-example:sections/6/entries/2/examples/0:start -->

#### Example 1

Command

```sh
jq 'def addvalue(f): . + [f]; map(addvalue(.[0]))'
```

Input

```text
[[1,2],[10,20]]
```

Output 1

```text
[[1,2,1], [10,20,10]]
```

<!-- jq-example:sections/6/entries/2/examples/0:end -->

<!-- jq-example:sections/6/entries/2/examples/1:start -->

#### Example 2

Command

```sh
jq 'def addvalue(f): f as $x | map(. + $x); addvalue(.[0])'
```

Input

```text
[[1,2],[10,20]]
```

Output 1

```text
[[1,2,1,2], [10,20,1,2]]
```

<!-- jq-example:sections/6/entries/2/examples/1:end -->

<div class="jq-upstream-field" data-source-key="sections/6/entries/3/title">

<h3 id="scoping">Scoping</h3>

</div>

<div class="jq-upstream-field" data-source-key="sections/6/entries/3/body">

<p>There are two types of symbols in jq: value bindings (a.k.a.,
"variables"), and functions.  Both are scoped lexically,
with expressions being able to refer only to symbols that
have been defined "to the left" of them.  The only exception
to this rule is that functions can refer to themselves so as
to be able to create recursive functions.</p>




<p>For example, in the following expression there is a binding
which is visible "to the right" of it, <code>... | .*3 as
$times_three | [. + $times_three] | ...</code>, but not "to the
left".  Consider this expression now, <code>... | (.*3 as
$times_three | [. + $times_three]) | ...</code>: here the binding
<code>$times_three</code> is <em>not</em> visible past the closing parenthesis.</p>

</div>

<div class="jq-upstream-field" data-source-key="sections/6/entries/4/title">

<h3 id="isempty"><code>isempty(exp)</code></h3>

</div>

<div class="jq-upstream-field" data-source-key="sections/6/entries/4/body">

<p>Returns true if <code>exp</code> produces no outputs, false otherwise.</p>

</div>

<!-- jq-example:sections/6/entries/4/examples/0:start -->

#### Example 1

Command

```sh
jq 'isempty(empty)'
```

Input

```text
null
```

Output 1

```text
true
```

<!-- jq-example:sections/6/entries/4/examples/0:end -->

<!-- jq-example:sections/6/entries/4/examples/1:start -->

#### Example 2

Command

```sh
jq 'isempty(.[])'
```

Input

```text
[]
```

Output 1

```text
true
```

<!-- jq-example:sections/6/entries/4/examples/1:end -->

<!-- jq-example:sections/6/entries/4/examples/2:start -->

#### Example 3

Command

```sh
jq 'isempty(.[])'
```

Input

```text
[1,2,3]
```

Output 1

```text
false
```

<!-- jq-example:sections/6/entries/4/examples/2:end -->

<div class="jq-upstream-field" data-source-key="sections/6/entries/5/title">

<h3 id="limit"><code>limit(n; expr)</code></h3>

</div>

<div class="jq-upstream-field" data-source-key="sections/6/entries/5/body">

<p>The <code>limit</code> function extracts up to <code>n</code> outputs from <code>expr</code>.</p>

</div>

<!-- jq-example:sections/6/entries/5/examples/0:start -->

#### Example 1

Command

```sh
jq '[limit(3; .[])]'
```

Input

```text
[0,1,2,3,4,5,6,7,8,9]
```

Output 1

```text
[0,1,2]
```

<!-- jq-example:sections/6/entries/5/examples/0:end -->

<div class="jq-upstream-field" data-source-key="sections/6/entries/6/title">

<h3 id="skip"><code>skip(n; expr)</code></h3>

</div>

<div class="jq-upstream-field" data-source-key="sections/6/entries/6/body">

<p>The <code>skip</code> function skips the first <code>n</code> outputs from <code>expr</code>.</p>

</div>

<!-- jq-example:sections/6/entries/6/examples/0:start -->

#### Example 1

Command

```sh
jq '[skip(3; .[])]'
```

Input

```text
[0,1,2,3,4,5,6,7,8,9]
```

Output 1

```text
[3,4,5,6,7,8,9]
```

<!-- jq-example:sections/6/entries/6/examples/0:end -->

<div class="jq-upstream-field" data-source-key="sections/6/entries/7/title">

<h3 id="first-last-nth-2"><code>first(expr)</code>, <code>last(expr)</code>, <code>nth(n; expr)</code></h3>

</div>

<div class="jq-upstream-field" data-source-key="sections/6/entries/7/body">

<p>The <code>first(expr)</code> and <code>last(expr)</code> functions extract the first
and last values from <code>expr</code>, respectively.</p>




<p>The <code>nth(n; expr)</code> function extracts the nth value output by <code>expr</code>.
Note that <code>nth(n; expr)</code> doesn't support negative values of <code>n</code>.</p>

</div>

<!-- jq-example:sections/6/entries/7/examples/0:start -->

#### Example 1

Command

```sh
jq '[first(range(.)), last(range(.)), nth(5; range(.))]'
```

Input

```text
10
```

Output 1

```text
[0,9,5]
```

<!-- jq-example:sections/6/entries/7/examples/0:end -->

<!-- jq-example:sections/6/entries/7/examples/1:start -->

#### Example 2

Command

```sh
jq '[first(empty), last(empty), nth(5; empty)]'
```

Input

```text
null
```

Output 1

```text
[]
```

<!-- jq-example:sections/6/entries/7/examples/1:end -->

<div class="jq-upstream-field" data-source-key="sections/6/entries/8/title">

<h3 id="first-last-nth-1"><code>first</code>, <code>last</code>, <code>nth(n)</code></h3>

</div>

<div class="jq-upstream-field" data-source-key="sections/6/entries/8/body">

<p>The <code>first</code> and <code>last</code> functions extract the first
and last values from any array at <code>.</code>.</p>




<p>The <code>nth(n)</code> function extracts the nth value of any array at <code>.</code>.</p>

</div>

<!-- jq-example:sections/6/entries/8/examples/0:start -->

#### Example 1

Command

```sh
jq '[range(.)]|[first, last, nth(5)]'
```

Input

```text
10
```

Output 1

```text
[0,9,5]
```

<!-- jq-example:sections/6/entries/8/examples/0:end -->

<div class="jq-upstream-field" data-source-key="sections/6/entries/9/title">

<h3 id="reduce"><code>reduce</code></h3>

</div>

<div class="jq-upstream-field" data-source-key="sections/6/entries/9/body">

<p>The <code>reduce</code> syntax allows you to combine all of the results of
an expression by accumulating them into a single answer.
The form is <code>reduce EXP as $var (INIT; UPDATE)</code>.
As an example, we'll pass <code>[1,2,3]</code> to this expression:</p>




<pre><code>reduce .[] as $item (0; . + $item)
</code></pre>




<p>For each result that <code>.[]</code> produces, <code>. + $item</code> is run to
accumulate a running total, starting from 0 as the input value.
In this example, <code>.[]</code> produces the results <code>1</code>, <code>2</code>, and <code>3</code>,
so the effect is similar to running something like this:</p>




<pre><code>0 | 1 as $item | . + $item |
    2 as $item | . + $item |
    3 as $item | . + $item
</code></pre>

</div>

<!-- jq-example:sections/6/entries/9/examples/0:start -->

#### Example 1

Command

```sh
jq 'reduce .[] as $item (0; . + $item)'
```

Input

```text
[1,2,3,4,5]
```

Output 1

```text
15
```

<!-- jq-example:sections/6/entries/9/examples/0:end -->

<!-- jq-example:sections/6/entries/9/examples/1:start -->

#### Example 2

Command

```sh
jq 'reduce .[] as [$i,$j] (0; . + $i * $j)'
```

Input

```text
[[1,2],[3,4],[5,6]]
```

Output 1

```text
44
```

<!-- jq-example:sections/6/entries/9/examples/1:end -->

<!-- jq-example:sections/6/entries/9/examples/2:start -->

#### Example 3

Command

```sh
jq 'reduce .[] as {$x,$y} (null; .x += $x | .y += [$y])'
```

Input

```text
[{"x":"a","y":1},{"x":"b","y":2},{"x":"c","y":3}]
```

Output 1

```text
{"x":"abc","y":[1,2,3]}
```

<!-- jq-example:sections/6/entries/9/examples/2:end -->

<div class="jq-upstream-field" data-source-key="sections/6/entries/10/title">

<h3 id="foreach"><code>foreach</code></h3>

</div>

<div class="jq-upstream-field" data-source-key="sections/6/entries/10/body">

<p>The <code>foreach</code> syntax is similar to <code>reduce</code>, but intended to
allow the construction of <code>limit</code> and reducers that produce
intermediate results.</p>




<p>The form is <code>foreach EXP as $var (INIT; UPDATE; EXTRACT)</code>.
As an example, we'll pass <code>[1,2,3]</code> to this expression:</p>




<pre><code>foreach .[] as $item (0; . + $item; [$item, . * 2])
</code></pre>




<p>Like the <code>reduce</code> syntax, <code>. + $item</code> is run for each result
that <code>.[]</code> produces, but <code>[$item, . * 2]</code> is run for each
intermediate values. In this example, since the intermediate
values are <code>1</code>, <code>3</code>, and <code>6</code>, the <code>foreach</code> expression produces
<code>[1,2]</code>, <code>[2,6]</code>, and <code>[3,12]</code>. So the effect is similar
to running something like this:</p>




<pre><code>0 | 1 as $item | . + $item | [$item, . * 2],
    2 as $item | . + $item | [$item, . * 2],
    3 as $item | . + $item | [$item, . * 2]
</code></pre>




<p>When <code>EXTRACT</code> is omitted, the identity filter is used.
That is, it outputs the intermediate values as they are.</p>

</div>

<!-- jq-example:sections/6/entries/10/examples/0:start -->

#### Example 1

Command

```sh
jq 'foreach .[] as $item (0; . + $item)'
```

Input

```text
[1,2,3,4,5]
```

Output 1

```text
1
```

Output 2

```text
3
```

Output 3

```text
6
```

Output 4

```text
10
```

Output 5

```text
15
```

<!-- jq-example:sections/6/entries/10/examples/0:end -->

<!-- jq-example:sections/6/entries/10/examples/1:start -->

#### Example 2

Command

```sh
jq 'foreach .[] as $item (0; . + $item; [$item, . * 2])'
```

Input

```text
[1,2,3,4,5]
```

Output 1

```text
[1,2]
```

Output 2

```text
[2,6]
```

Output 3

```text
[3,12]
```

Output 4

```text
[4,20]
```

Output 5

```text
[5,30]
```

<!-- jq-example:sections/6/entries/10/examples/1:end -->

<!-- jq-example:sections/6/entries/10/examples/2:start -->

#### Example 3

Command

```sh
jq 'foreach .[] as $item (0; . + 1; {index: ., $item})'
```

Input

```text
["foo", "bar", "baz"]
```

Output 1

```text
{"index":1,"item":"foo"}
```

Output 2

```text
{"index":2,"item":"bar"}
```

Output 3

```text
{"index":3,"item":"baz"}
```

<!-- jq-example:sections/6/entries/10/examples/2:end -->

<div class="jq-upstream-field" data-source-key="sections/6/entries/11/title">

<h3 id="recursion">Recursion</h3>

</div>

<div class="jq-upstream-field" data-source-key="sections/6/entries/11/body">

<p>As described above, <code>recurse</code> uses recursion, and any jq
function can be recursive.  The <code>while</code> builtin is also
implemented in terms of recursion.</p>




<p>Tail calls are optimized whenever the expression to the left of
the recursive call outputs its last value.  In practice this
means that the expression to the left of the recursive call
should not produce more than one output for each input.</p>




<p>For example:</p>




<pre><code>def recurse(f): def r: ., (f | select(. != null) | r); r;

def while(cond; update):
  def _while:
    if cond then ., (update | _while) else empty end;
  _while;

def repeat(exp):
  def _repeat:
    exp, _repeat;
  _repeat;
</code></pre>

</div>

<div class="jq-upstream-field" data-source-key="sections/6/entries/12/title">

<h3 id="generators-and-iterators">Generators and iterators</h3>

</div>

<div class="jq-upstream-field" data-source-key="sections/6/entries/12/body">

<p>Some jq operators and functions are actually generators in
that they can produce zero, one, or more values for each
input, just as one might expect in other programming
languages that have generators.  For example, <code>.[]</code>
generates all the values in its input (which must be an
array or an object), <code>range(0; 10)</code> generates the integers
between 0 and 10, and so on.</p>




<p>Even the comma operator is a generator, generating first
the values generated by the expression to the left of the
comma, then the values generated by the expression on the
right of the comma.</p>




<p>The <code>empty</code> builtin is the generator that produces zero
outputs.  The <code>empty</code> builtin backtracks to the preceding
generator expression.</p>




<p>All jq functions can be generators just by using builtin
generators.  It is also possible to construct new generators
using only recursion and the comma operator.  If
recursive calls are "in tail position" then the
generator will be efficient.  In the example below the
recursive call by <code>_range</code> to itself is in tail position.
The example shows off three advanced topics: tail recursion,
generator construction, and sub-functions.</p>

</div>

<!-- jq-example:sections/6/entries/12/examples/0:start -->

#### Example 1

Command

```sh
jq 'def range(init; upto; by): def _range: if (by > 0 and . < upto) or (by < 0 and . > upto) then ., ((.+by)|_range) else empty end; if init == upto then empty elif by == 0 then init else init|_range end; range(0; 10; 3)'
```

Input

```text
null
```

Output 1

```text
0
```

Output 2

```text
3
```

Output 3

```text
6
```

Output 4

```text
9
```

<!-- jq-example:sections/6/entries/12/examples/0:end -->

<!-- jq-example:sections/6/entries/12/examples/1:start -->

#### Example 2

Command

```sh
jq 'def while(cond; update): def _while: if cond then ., (update | _while) else empty end; _while; [while(.<100; .*2)]'
```

Input

```text
1
```

Output 1

```text
[1,2,4,8,16,32,64]
```

<!-- jq-example:sections/6/entries/12/examples/1:end -->


