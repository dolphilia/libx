# mdBook0.5.4 — unpublished Libx trial editable source

This archive contains the31editable Libx document inputs, their app components/runtime/assets, and the fixed shared-template build context. Documentation/adapted document inputs remain MPL2.0. The full original mdBook source archive is in upstream/; original notices and material terms remain separate. Do not interpret MPL2.0 as relicensing all unrelated Libx site code. See notices/RIGHTS_DECISION.json and SOURCE_COMPONENTS.json.

The MathJax2.7.1 complete original source is a separate fixed download with the SHA256 stated in SOURCE_COMPONENTS.json. Local runtime resources and complete six font-family subtrees are already in workspace/apps/mdbook-trial/public/mdbook-runtime/mathjax/. The original archive also contains omitted legacy PNG resources. Their exclusion from HTTP runtime is still under evaluation; this trial is not an accepted production project.

Edit the Markdown sources in workspace/apps/mdbook-trial/src/content/docs/, including raw HTML text and newline entities in pre blocks. This is the preferred editable form of the present Libx document adaptation; no dist output is substituted for it. The upstream tar.gz preserves the original unexpanded Markdown/helper inputs for an upstream regeneration with mdBook0.5.4. Future translations must include their editable inputs in a refreshed offer.

Build the current editable trial with the pinned workspace package manifest and pnpm lock:

    cd workspace
    pnpm install --frozen-lockfile
    cd apps/mdbook-trial
    pnpm exec astro build

A source-reconstruction check uses those same pinned dependency bytes, kept separate from this archive. Dependency packages are resolved from the lock, not claimed to be included. The command builds the editable app; archived historical generation scripts are not claimed to be a portable one-command upstream importer.

To reproduce the full-original MathJax download link, place the separately supplied file, after checking its SHA256, at workspace/apps/mdbook-trial/public/downloads/mathjax-2.7.1-d71cc406.tar.gz. Diagnostic original-mdbook mirrors are excluded; no rendered chapter links depend on that diagnostic mirror. The self-referential source ZIP download is packaged separately from the editable source tree and is not included recursively. To reproduce that link, copy the provided source.zip itself to workspace/apps/mdbook-trial/public/downloads/v0-5-4/source.zip after building or before packaging a delivery; never include the source ZIP recursively in a refreshed preferred-source bundle.

Libx adaptations: internal route/asset mapping, pre newline encoding, footer source/editorial notes, original SUMMARY navigation, scoped content/code styles, original code/editor functions with modern clipboard transport and stable button labels, shared-theme palette mapping, local fixed MathJax component packaging. Original notice texts/source assets are retained. Upstream Rust logos and Font Awesome demonstrations are documentation materials, not Libx branding or an endorsement.

All31chapters remain included; no translation/full semantic review/publication is claimed. This source offer is a trial implementation, not a completion certificate for the project.
