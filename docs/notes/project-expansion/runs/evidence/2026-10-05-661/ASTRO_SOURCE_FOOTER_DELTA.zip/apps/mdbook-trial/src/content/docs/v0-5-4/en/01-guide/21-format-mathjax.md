---
title: "MathJax support"
documentId: "mdbook:guide/src/format/mathjax.md"
order: 24
licenseSource: "mdbook-guide"
documentContext: [{"kind": "source", "html": "<p>Fixed source: <a href=\"https://github.com/rust-lang/mdBook/blob/2ea30c00f00647d2b3f4c0f79b3e0e1eabc0b66d/guide/src/format/mathjax.md\">guide/src/format/mathjax.md</a>; mdBook 0.5.4. Documentation: MPL-2.0. Unofficial Libx presentation; internal links and code newline encoding adapted.</p><p>Free editable source (MPL-2.0 for the documentation and its Libx adaptation): <a href=\"/docs/mdbook-trial/downloads/v0-5-4/source.zip\">Download the complete Libx document source bundle</a>. It includes the original mdBook 0.5.4 source archive, editable document inputs, build context and material notices. The complete fixed MathJax source is a <a href=\"/docs/mdbook-trial/downloads/mathjax-2.7.1-d71cc406.tar.gz\">separate component</a>; separate material terms remain in force. This is an unpublished trial; translations and full semantic review are not complete.</p>"}, {"kind": "editorial", "html": "<p>Code demonstration runtime: fixed bundled mdBook 0.5.4 code (MPL-2.0), Ace (BSD-3-Clause), Highlight.js 10.1.1 (BSD-3-Clause) and Clipboard.js 2.0.4 (MIT). Original notices are preserved. Modern clipboard transport, icon-descendant button labels and shared-theme palette mapping are Libx integration adaptations; original code/editor text selection is retained. <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/ACE_LICENSE.txt\">Ace notice</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/HIGHLIGHT_LICENSE.txt\">Highlight.js notice</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/CLIPBOARD_LINKED_LICENSE.html\">Clipboard.js linked MIT notice</a>. Math equations use locally served MathJax 2.7.1, fixed at commit d71cc40666d213dceeb9353822a3b530656d9a4b. Code: <a href=\"/docs/mdbook-trial/mdbook-runtime/mathjax/LICENSE\">Apache-2.0</a>; bundled font families retain their separate OFL/GUST/LPPL notices. <a href=\"/docs/mdbook-trial/mdbook-runtime/mathjax/LIBX-NOTICES.txt\">Component notices and packaging changes</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/mathjax/LPPL-1.3c.txt\">LPPL 1.3c</a> · <a href=\"/docs/mdbook-trial/downloads/mathjax-2.7.1-d71cc406.tar.gz\">Full original MathJax source archive</a>. Runtime selection excludes legacy PNG fallback assets; compatibility verification remains pending in this unpublished trial.</p>"}]
prev: {"text": "Editor", "link": "/v0-5-4/en/01-guide/25-format-theme-editor"}
next: {"text": "mdBook-specific features", "link": "/v0-5-4/en/01-guide/22-format-mdbook"}
---

<div class="mdbook-guide">
<h1 id="mathjax-support"><a class="header" href="#mathjax-support">MathJax support</a></h1>
<p>mdBook has optional support for math equations through
<a href="https://www.mathjax.org/">MathJax</a>.</p>
<p>To enable MathJax, you need to add the <code>mathjax-support</code> key to your <code>book.toml</code>
under the <code>output.html</code> section.</p>
<pre><code class="language-toml">[output.html]&#10;mathjax-support = true&#10;</code></pre>
<blockquote>
<p><strong>Note:</strong> The usual delimiters MathJax uses are not yet supported. You can’t
currently use <code>$$ ... $$</code> as delimiters and the <code>\[ ... \]</code> delimiters need an
extra backslash to work. Hopefully this limitation will be lifted soon.</p>
</blockquote>
<blockquote>
<p><strong>Note:</strong> When you use double backslashes in MathJax blocks (for example in
commands such as <code>\begin{cases} \frac 1 2 \\ \frac 3 4 \end{cases}</code>) you need
to add <em>two extra</em> backslashes (e.g., <code>\begin{cases} \frac 1 2 \\\\ \frac 3 4 \end{cases}</code>).</p>
</blockquote>
<h3 id="inline-equations"><a class="header" href="#inline-equations">Inline equations</a></h3>
<p>Inline equations are delimited by <code>\\(</code> and <code>\\)</code>. So for example, to render the
following inline equation \( \int x dx = \frac{x^2}{2} + C \) you would write
the following:</p>
<pre><code>\\( \int x dx = \frac{x^2}{2} + C \\)&#10;</code></pre>
<h3 id="block-equations"><a class="header" href="#block-equations">Block equations</a></h3>
<p>Block equations are delimited by <code>\\[</code> and <code>\\]</code>. To render the following
equation</p>
<p>\[ \mu = \frac{1}{N} \sum_{i=0} x_i \]</p>
<p>you would write:</p>
<pre><code class="language-bash">\\[ \mu = \frac{1}{N} \sum_{i=0} x_i \\]&#10;</code></pre>
</div>
