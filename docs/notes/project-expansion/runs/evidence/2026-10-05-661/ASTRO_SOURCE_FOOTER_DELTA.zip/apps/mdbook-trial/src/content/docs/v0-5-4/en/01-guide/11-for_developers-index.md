---
title: "For developers"
documentId: "mdbook:guide/src/for_developers/README.md"
order: 28
licenseSource: "mdbook-guide"
documentContext: [{"kind": "source", "html": "<p>Fixed source: <a href=\"https://github.com/rust-lang/mdBook/blob/2ea30c00f00647d2b3f4c0f79b3e0e1eabc0b66d/guide/src/for_developers/README.md\">guide/src/for_developers/README.md</a>; mdBook 0.5.4. Documentation: MPL-2.0. Unofficial Libx presentation; internal links and code newline encoding adapted.</p><p>Free editable source (MPL-2.0 for the documentation and its Libx adaptation): <a href=\"/docs/mdbook-trial/downloads/v0-5-4/source.zip\">Download the complete Libx document source bundle</a>. It includes the original mdBook 0.5.4 source archive, editable document inputs, build context and material notices. The complete fixed MathJax source is a <a href=\"/docs/mdbook-trial/downloads/mathjax-2.7.1-d71cc406.tar.gz\">separate component</a>; separate material terms remain in force. This is an unpublished trial; translations and full semantic review are not complete.</p>"}, {"kind": "editorial", "html": "<p>Code demonstration runtime: fixed bundled mdBook 0.5.4 code (MPL-2.0), Ace (BSD-3-Clause), Highlight.js 10.1.1 (BSD-3-Clause) and Clipboard.js 2.0.4 (MIT). Original notices are preserved. Modern clipboard transport, icon-descendant button labels and shared-theme palette mapping are Libx integration adaptations; original code/editor text selection is retained. <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/ACE_LICENSE.txt\">Ace notice</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/HIGHLIGHT_LICENSE.txt\">Highlight.js notice</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/CLIPBOARD_LINKED_LICENSE.html\">Clipboard.js linked MIT notice</a>. Math equations use locally served MathJax 2.7.1, fixed at commit d71cc40666d213dceeb9353822a3b530656d9a4b. Code: <a href=\"/docs/mdbook-trial/mdbook-runtime/mathjax/LICENSE\">Apache-2.0</a>; bundled font families retain their separate OFL/GUST/LPPL notices. <a href=\"/docs/mdbook-trial/mdbook-runtime/mathjax/LIBX-NOTICES.txt\">Component notices and packaging changes</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/mathjax/LPPL-1.3c.txt\">LPPL 1.3c</a> · <a href=\"/docs/mdbook-trial/downloads/mathjax-2.7.1-d71cc406.tar.gz\">Full original MathJax source archive</a>. Runtime selection excludes legacy PNG fallback assets; compatibility verification remains pending in this unpublished trial.</p>"}]
prev: {"text": "Continuous integration", "link": "/v0-5-4/en/01-guide/10-continuous-integration"}
next: {"text": "Preprocessors", "link": "/v0-5-4/en/01-guide/13-for_developers-preprocessors"}
---

<div class="mdbook-guide">
<h1 id="for-developers"><a class="header" href="#for-developers">For developers</a></h1>
<p>While <code>mdbook</code> is mainly used as a command line tool, you can also import the
underlying libraries directly and use those to manage a book. It also has a fairly
flexible plugin mechanism, allowing you to create your own custom tooling and
consumers (often referred to as <em>backends</em>) if you need to do some analysis of
the book or render it in a different format.</p>
<p>The <em>For Developers</em> chapters are here to show you the more advanced usage of
<code>mdbook</code>.</p>
<p>The two main ways a developer can hook into the book’s build process is via,</p>
<ul>
<li><a href="/docs/mdbook-trial/v0-5-4/en/01-guide/13-for_developers-preprocessors/">Preprocessors</a></li>
<li><a href="/docs/mdbook-trial/v0-5-4/en/01-guide/12-for_developers-backends/">Alternative Backends</a></li>
</ul>
<h2 id="the-build-process"><a class="header" href="#the-build-process">The build process</a></h2>
<p>The process of rendering a book project goes through several steps.</p>
<ol>
<li>Load the book
<ul>
<li>Parse the <code>book.toml</code>, falling back to the default <code>Config</code> if it doesn’t
exist</li>
<li>Load the book chapters into memory</li>
<li>Discover which preprocessors/backends should be used</li>
</ul>
</li>
<li>For each backend:
<ol>
<li>Run all the preprocessors.</li>
<li>Call the backend to render the processed result.</li>
</ol>
</li>
</ol>
<h2 id="using-mdbook-as-a-library"><a class="header" href="#using-mdbook-as-a-library">Using <code>mdbook</code> as a library</a></h2>
<p>The <code>mdbook</code> binary is just a wrapper around the underlying mdBook crates,
exposing their functionality as a command-line program. If you want to
programmatically drive mdBook, you can use the [<code>mdbook-driver</code>] crate.
This can be used to add your own functionality or tweak the build process.</p>
<p>The easiest way to find out how to use the <code>mdbook-driver</code> crate is by looking at the
<a href="https://docs.rs/mdbook-driver/latest/mdbook_driver/">API Docs</a>. The top level documentation explains how one would use the
<a href="https://docs.rs/mdbook-driver/latest/mdbook_driver/struct.MDBook.html"><code>MDBook</code></a> type to load and build a book, while the <a href="https://docs.rs/mdbook-driver/latest/mdbook_driver/config/index.html">config</a> module gives a good
explanation on the configuration system.</p>
</div>
