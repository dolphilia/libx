---
title: "Configuring Renderers"
documentId: "mdbook:guide/src/format/configuration/renderers.md"
order: 18
licenseSource: "mdbook-guide"
documentContext: [{"kind": "source", "html": "<p>Fixed source: <a href=\"https://github.com/rust-lang/mdBook/blob/2ea30c00f00647d2b3f4c0f79b3e0e1eabc0b66d/guide/src/format/configuration/renderers.md\">guide/src/format/configuration/renderers.md</a>; mdBook 0.5.4. Documentation: MPL-2.0. Unofficial Libx presentation; internal links and code newline encoding adapted.</p><p>Free editable source (MPL-2.0 for the documentation and its Libx adaptation): <a href=\"/docs/mdbook-trial/downloads/v0-5-4/source.zip\">Download the complete Libx document source bundle</a>. It includes the original mdBook 0.5.4 source archive, editable document inputs, build context and material notices. The complete fixed MathJax source is a <a href=\"/docs/mdbook-trial/downloads/mathjax-2.7.1-d71cc406.tar.gz\">separate component</a>; separate material terms remain in force. This is an unpublished trial; translations and full semantic review are not complete.</p>"}, {"kind": "editorial", "html": "<p>Original example assets retained. Rust logo: CC BY 4.0, unchanged, no affiliation or endorsement. Font Awesome SVG: CC BY 4.0; non-icon code: MIT. The original MIT wording and literal SVG example remain unchanged. This trial has not completed source-offer or behavior validation.</p>"}, {"kind": "editorial", "html": "<p>Code demonstration runtime: fixed bundled mdBook 0.5.4 code (MPL-2.0), Ace (BSD-3-Clause), Highlight.js 10.1.1 (BSD-3-Clause) and Clipboard.js 2.0.4 (MIT). Original notices are preserved. Modern clipboard transport, icon-descendant button labels and shared-theme palette mapping are Libx integration adaptations; original code/editor text selection is retained. <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/ACE_LICENSE.txt\">Ace notice</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/HIGHLIGHT_LICENSE.txt\">Highlight.js notice</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/CLIPBOARD_LINKED_LICENSE.html\">Clipboard.js linked MIT notice</a>. Math equations use locally served MathJax 2.7.1, fixed at commit d71cc40666d213dceeb9353822a3b530656d9a4b. Code: <a href=\"/docs/mdbook-trial/mdbook-runtime/mathjax/LICENSE\">Apache-2.0</a>; bundled font families retain their separate OFL/GUST/LPPL notices. <a href=\"/docs/mdbook-trial/mdbook-runtime/mathjax/LIBX-NOTICES.txt\">Component notices and packaging changes</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/mathjax/LPPL-1.3c.txt\">LPPL 1.3c</a> · <a href=\"/docs/mdbook-trial/downloads/mathjax-2.7.1-d71cc406.tar.gz\">Full original MathJax source archive</a>. Runtime selection excludes legacy PNG fallback assets; compatibility verification remains pending in this unpublished trial.</p>"}]
prev: {"text": "Preprocessors", "link": "/v0-5-4/en/01-guide/18-format-configuration-preprocessors"}
next: {"text": "Environment variables", "link": "/v0-5-4/en/01-guide/16-format-configuration-environment-variables"}
---

<div class="mdbook-guide">
<h1 id="configuring-renderers"><a class="header" href="#configuring-renderers">Configuring Renderers</a></h1>
<p>Renderers (also called “backends”) are responsible for creating the output of the book.</p>
<p>The following backends are built-in:</p>
<ul>
<li><a href="#html-renderer-options"><code>html</code></a> — This renders the book to HTML.
This is enabled by default if no other <code>[output]</code> tables are defined in <code>book.toml</code>.</li>
<li><a href="#markdown-renderer"><code>markdown</code></a> — This outputs the book as markdown after running the preprocessors.
This is useful for debugging preprocessors.</li>
</ul>
<p>The community has developed several backends.
See the <a href="https://github.com/rust-lang/mdBook/wiki/Third-party-plugins">Third Party Plugins</a> wiki page for a list of available backends.</p>
<p>For information on how to create a new backend, see the <a href="/docs/mdbook-trial/v0-5-4/en/01-guide/12-for_developers-backends/">Backends for Developers</a> chapter.</p>
<h2 id="output-tables"><a class="header" href="#output-tables">Output tables</a></h2>
<p>Backends can be added by including a <code>output</code> table in <code>book.toml</code> with the name of the backend.
For example, if you have a backend called <code>mdbook-wordcount</code>, then you can include it with:</p>
<pre><code class="language-toml">[output.wordcount]&#10;</code></pre>
<p>With this table, mdBook will execute the <code>mdbook-wordcount</code> backend.</p>
<p>This table can include additional key-value pairs that are specific to the backend.
For example, if our example backend needed some extra configuration options:</p>
<pre><code class="language-toml">[output.wordcount]&#10;ignores = ["Example Chapter"]&#10;</code></pre>
<p>If you define any <code>[output]</code> tables, then the <code>html</code> backend is not enabled by default.
If you want to keep the <code>html</code> backend running, then just include it in the <code>book.toml</code> file.
For example:</p>
<pre><code class="language-toml">[book]&#10;title = "My Awesome Book"&#10;&#10;[output.wordcount]&#10;&#10;[output.html]&#10;</code></pre>
<p>If more than one <code>output</code> table is included, this changes the behavior for the layout of the output directory.
If there is only one backend, then it places its output directly in the <code>book</code> directory (see <a href="/docs/mdbook-trial/v0-5-4/en/01-guide/17-format-configuration-general/#build-options"><code>build.build-dir</code></a> to override this location).
If there is more than one backend, then each backend is placed in a separate directory underneath <code>book</code>.
For example, the above would have directories <code>book/html</code> and <code>book/wordcount</code>.</p>
<h3 id="custom-backend-commands"><a class="header" href="#custom-backend-commands">Custom backend commands</a></h3>
<p>By default when you add an <code>[output.foo]</code> table to your <code>book.toml</code> file,
<code>mdbook</code> will try to invoke the <code>mdbook-foo</code> executable.
If you want to use a different program name or pass in command-line arguments,
this behaviour can be overridden by adding a <code>command</code> field.</p>
<pre><code class="language-toml">[output.random]&#10;command = "python random.py"&#10;</code></pre>
<h3 id="optional-backends"><a class="header" href="#optional-backends">Optional backends</a></h3>
<p>If you enable a backend that isn’t installed, the default behavior is to throw an error.
This behavior can be changed by marking the backend as optional:</p>
<pre><code class="language-toml">[output.wordcount]&#10;optional = true&#10;</code></pre>
<p>This demotes the error to a warning.</p>
<h2 id="html-renderer-options"><a class="header" href="#html-renderer-options">HTML renderer options</a></h2>
<p>The HTML renderer has a variety of options detailed below.
They should be specified in the <code>[output.html]</code> table of the <code>book.toml</code> file.</p>
<pre><code class="language-toml"># Example book.toml file with all output options.&#10;[book]&#10;title = "Example book"&#10;authors = ["John Doe", "Jane Doe"]&#10;description = "The example book covers examples."&#10;&#10;[output.html]&#10;theme = "my-theme"&#10;default-theme = "light"&#10;preferred-dark-theme = "navy"&#10;smart-punctuation = true&#10;definition-lists = true&#10;admonitions = true&#10;mathjax-support = false&#10;additional-css = ["custom.css", "custom2.css"]&#10;additional-js = ["custom.js"]&#10;no-section-label = false&#10;git-repository-url = "https://github.com/rust-lang/mdBook"&#10;git-repository-icon = "fab-github"&#10;edit-url-template = "https://github.com/rust-lang/mdBook/edit/master/guide/{path}"&#10;site-url = "/example-book/"&#10;cname = "myproject.rs"&#10;input-404 = "not-found.md"&#10;sidebar-header-nav = true&#10;</code></pre>
<p>The following configuration options are available:</p>
<ul>
<li><strong>theme:</strong> mdBook comes with a default theme and all the resource files needed
for it. But if this option is set, mdBook will selectively overwrite the theme
files with the ones found in the specified folder.</li>
<li><strong>default-theme:</strong> The theme color scheme to select by default in the
‘Change Theme’ dropdown. Defaults to <code>light</code>.</li>
<li><strong>preferred-dark-theme:</strong> The default dark theme. This theme will be used if
the browser requests the dark version of the site via the
<a href="https://developer.mozilla.org/en-US/docs/Web/CSS/@media/prefers-color-scheme"><code>prefers-color-scheme</code></a>
CSS media query. Defaults to <code>navy</code>.</li>
<li><strong>smart-punctuation:</strong> Converts quotes to curly quotes, <code>...</code> to <code>…</code>, <code>--</code> to en-dash, and <code>---</code> to em-dash.
See <a href="/docs/mdbook-trial/v0-5-4/en/01-guide/20-format-markdown/#smart-punctuation">Smart Punctuation</a>.
Defaults to <code>true</code>.</li>
<li><strong>definition-lists:</strong> Enables <a href="/docs/mdbook-trial/v0-5-4/en/01-guide/20-format-markdown/#definition-lists">definition lists</a>. Defaults to <code>true</code>.</li>
<li><strong>admonitions:</strong> Enables <a href="/docs/mdbook-trial/v0-5-4/en/01-guide/20-format-markdown/#admonitions">admonitions</a>. Defaults to <code>true</code>.</li>
<li><strong>mathjax-support:</strong> Adds support for <a href="/docs/mdbook-trial/v0-5-4/en/01-guide/21-format-mathjax/">MathJax</a>. Defaults to
<code>false</code>.</li>
<li><strong>additional-css:</strong> If you need to slightly change the appearance of your book
without overwriting the whole style, you can specify a set of stylesheets that
will be loaded after the default ones where you can surgically change the
style.</li>
<li><strong>additional-js:</strong> If you need to add some behaviour to your book without
removing the current behaviour, you can specify a set of JavaScript files that
will be loaded alongside the default one.</li>
<li><strong>no-section-label:</strong> mdBook by defaults adds numeric section labels in the table of
contents column. For example, “1.”, “2.1”. Set this option to true to disable
those labels. Defaults to <code>false</code>.</li>
<li><strong>git-repository-url:</strong>  A url to the git repository for the book. If provided
an icon link will be output in the menu bar of the book.</li>
<li><strong>git-repository-icon:</strong> The Font Awesome icon class to use for the git repository link. Defaults to <code>fab-github</code> which looks like <span class="fa-svg"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 496 512"><!--! Font Awesome Free 6.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2022 Fonticons, Inc. --><path d="M165.9 397.4c0 2-2.3 3.6-5.2 3.6-3.3.3-5.6-1.3-5.6-3.6 0-2 2.3-3.6 5.2-3.6 3-.3 5.6 1.3 5.6 3.6zm-31.1-4.5c-.7 2 1.3 4.3 4.3 4.9 2.6 1 5.6 0 6.2-2s-1.3-4.3-4.3-5.2c-2.6-.7-5.5.3-6.2 2.3zm44.2-1.7c-2.9.7-4.9 2.6-4.6 4.9.3 2 2.9 3.3 5.9 2.6 2.9-.7 4.9-2.6 4.6-4.6-.3-1.9-3-3.2-5.9-2.9zM244.8 8C106.1 8 0 113.3 0 252c0 110.9 69.8 205.8 169.5 239.2 12.8 2.3 17.3-5.6 17.3-12.1 0-6.2-.3-40.4-.3-61.4 0 0-70 15-84.7-29.8 0 0-11.4-29.1-27.8-36.6 0 0-22.9-15.7 1.6-15.4 0 0 24.9 2 38.6 25.8 21.9 38.6 58.6 27.5 72.9 20.9 2.3-16 8.8-27.1 16-33.7-55.9-6.2-112.3-14.3-112.3-110.5 0-27.5 7.6-41.3 23.6-58.9-2.6-6.5-11.1-33.3 2.6-67.9 20.9-6.5 69 27 69 27 20-5.6 41.5-8.5 62.8-8.5s42.8 2.9 62.8 8.5c0 0 48.1-33.6 69-27 13.7 34.7 5.2 61.4 2.6 67.9 16 17.7 25.8 31.5 25.8 58.9 0 96.5-58.9 104.2-114.8 110.5 9.2 7.9 17 22.9 17 46.4 0 33.7-.3 75.4-.3 83.6 0 6.5 4.6 14.4 17.3 12.1C428.2 457.8 496 362.9 496 252 496 113.3 383.5 8 244.8 8zM97.2 352.9c-1.3 1-1 3.3.7 5.2 1.6 1.6 3.9 2.3 5.2 1 1.3-1 1-3.3-.7-5.2-1.6-1.6-3.9-2.3-5.2-1zm-10.8-8.1c-.7 1.3.3 2.9 2.3 3.9 1.6 1 3.6.7 4.3-.7.7-1.3-.3-2.9-2.3-3.9-2-.6-3.6-.3-4.3.7zm32.4 35.6c-1.6 1.3-1 4.3 1.3 6.2 2.3 2.3 5.2 2.6 6.5 1 1.3-1.3.7-4.3-1.3-6.2-2.2-2.3-5.2-2.6-6.5-1zm-11.4-14.7c-1.6 1-1.6 3.6 0 5.9 1.6 2.3 4.3 3.3 5.6 2.3 1.6-1.3 1.6-3.9 0-6.2-1.4-2.3-4-3.3-5.6-2z"></path></svg></span>. If you are not using GitHub, another option to consider is <code>fas-code-fork</code> which looks like <span class="fa-svg"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--! Font Awesome Free 6.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2022 Fonticons, Inc. --><path d="M80 104c13.3 0 24-10.7 24-24s-10.7-24-24-24S56 66.7 56 80s10.7 24 24 24zm80-24c0 32.8-19.7 61-48 73.3V192c0 17.7 14.3 32 32 32H304c17.7 0 32-14.3 32-32V153.3C307.7 141 288 112.8 288 80c0-44.2 35.8-80 80-80s80 35.8 80 80c0 32.8-19.7 61-48 73.3V192c0 53-43 96-96 96H256v70.7c28.3 12.3 48 40.5 48 73.3c0 44.2-35.8 80-80 80s-80-35.8-80-80c0-32.8 19.7-61 48-73.3V288H144c-53 0-96-43-96-96V153.3C19.7 141 0 112.8 0 80C0 35.8 35.8 0 80 0s80 35.8 80 80zm208 24c13.3 0 24-10.7 24-24s-10.7-24-24-24s-24 10.7-24 24s10.7 24 24 24zM248 432c0-13.3-10.7-24-24-24s-24 10.7-24 24s10.7 24 24 24s24-10.7 24-24z"></path></svg></span>. The start of the string should be <code>fa-</code> for regular icons, <code>fas-</code> for solid icons, or <code>fab-</code> for brand icons. See the <a href="https://fontawesome.com/v6/search">free icon set</a> for the available icons.</li>
<li><strong>edit-url-template:</strong> Edit url template, when provided shows a
“Suggest an edit” button (which looks like <span class="fa-svg"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Free 6.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2022 Fonticons, Inc. --><path d="M421.7 220.3l-11.3 11.3-22.6 22.6-205 205c-6.6 6.6-14.8 11.5-23.8 14.1L30.8 511c-8.4 2.5-17.5 .2-23.7-6.1S-1.5 489.7 1 481.2L38.7 353.1c2.6-9 7.5-17.2 14.1-23.8l205-205 22.6-22.6 11.3-11.3 33.9 33.9 62.1 62.1 33.9 33.9zM96 353.9l-9.3 9.3c-.9 .9-1.6 2.1-2 3.4l-25.3 86 86-25.3c1.3-.4 2.5-1.1 3.4-2l9.3-9.3H112c-8.8 0-16-7.2-16-16V353.9zM453.3 19.3l39.4 39.4c25 25 25 65.5 0 90.5l-14.5 14.5-22.6 22.6-11.3 11.3-33.9-33.9-62.1-62.1L314.3 67.7l11.3-11.3 22.6-22.6 14.5-14.5c25-25 65.5-25 90.5 0z"></path></svg></span>) for directly jumping to editing the currently
viewed page. For e.g. GitHub projects set this to
<code>https://github.com/&#x3C;owner>/&#x3C;repo>/edit/&#x3C;branch>/{path}</code> or for
Bitbucket projects set it to
<code>https://bitbucket.org/&#x3C;owner>/&#x3C;repo>/src/&#x3C;branch>/{path}?mode=edit</code>
where {path} will be replaced with the full path of the file in the
repository.</li>
<li><strong>input-404:</strong> The name of the markdown file used for missing files.
The corresponding output file will be the same, with the extension replaced with <code>html</code>.
Defaults to <code>404.md</code>.</li>
<li><strong>site-url:</strong> The url where the book will be hosted. This is required to ensure
navigation links and script/css imports in the 404 file work correctly, even when accessing
urls in subdirectories. Defaults to <code>/</code>. If <code>site-url</code> is set,
make sure to use document relative links for your assets, meaning they should not start with <code>/</code>.</li>
<li><strong>cname:</strong> The DNS subdomain or apex domain at which your book will be hosted.
This string will be written to a file named CNAME in the root of your site, as
required by GitHub Pages (see <a href="https://docs.github.com/en/github/working-with-github-pages/managing-a-custom-domain-for-your-github-pages-site"><em>Managing a custom domain for your GitHub Pages
site</em></a>).</li>
<li><strong>hash-files:</strong> Include a cryptographic “fingerprint” of the files’ contents in static asset filenames,
so that if the contents of the file are changed, the name of the file will also change.
For example, <code>css/chrome.css</code> may become <code>css/chrome-9b8f428e.css</code>.
Chapter HTML files are not renamed.
Static CSS and JS files can reference each other using <code>{{ resource "filename" }}</code> directives.
Defaults to <code>true</code>.</li>
<li><strong>sidebar-header-nav:</strong> If <code>true</code>, the sidebar will contain navigation for headers on the current page. Default is <code>true</code>.</li>
</ul>
<h3 id="outputhtmlprint"><a class="header" href="#outputhtmlprint"><code>[output.html.print]</code></a></h3>
<p>The <code>[output.html.print]</code> table provides options for controlling the printable output.
By default, mdBook will include an icon on the top right of the book (which looks like <span class="fa-svg"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Free 6.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2022 Fonticons, Inc. --><path d="M128 0C92.7 0 64 28.7 64 64v96h64V64H354.7L384 93.3V160h64V93.3c0-17-6.7-33.3-18.7-45.3L400 18.7C388 6.7 371.7 0 354.7 0H128zM384 352v32 64H128V384 368 352H384zm64 32h32c17.7 0 32-14.3 32-32V256c0-35.3-28.7-64-64-64H64c-35.3 0-64 28.7-64 64v96c0 17.7 14.3 32 32 32H64v64c0 35.3 28.7 64 64 64H384c35.3 0 64-28.7 64-64V384zm-16-88c-13.3 0-24-10.7-24-24s10.7-24 24-24s24 10.7 24 24s-10.7 24-24 24z"></path></svg></span>) that will print the book as a single page.</p>
<pre><code class="language-toml">[output.html.print]&#10;enable = true    # include support for printable output&#10;page-break = true # insert page-break after each chapter&#10;</code></pre>
<ul>
<li><strong>enable:</strong> Enable print support. When <code>false</code>, all print support will not be
rendered. Defaults to <code>true</code>.</li>
<li><strong>page-break:</strong> Insert page breaks between chapters. Defaults to <code>true</code>.</li>
</ul>
<h3 id="outputhtmlfold"><a class="header" href="#outputhtmlfold"><code>[output.html.fold]</code></a></h3>
<p>The <code>[output.html.fold]</code> table provides options for controlling folding of the chapter listing in the navigation sidebar.</p>
<pre><code class="language-toml">[output.html.fold]&#10;enable = false    # whether or not to enable section folding&#10;level = 0         # the depth to start folding&#10;</code></pre>
<ul>
<li><strong>enable:</strong> Enable section-folding. When off, all folds are open.
Defaults to <code>false</code>.</li>
<li><strong>level:</strong> The higher the more folded regions are open. When level is 0, all
folds are closed. Defaults to <code>0</code>.</li>
</ul>
<h3 id="outputhtmlplayground"><a class="header" href="#outputhtmlplayground"><code>[output.html.playground]</code></a></h3>
<p>The <code>[output.html.playground]</code> table provides options for controlling Rust sample code blocks, and their integration with the <a href="https://play.rust-lang.org/">Rust Playground</a>.</p>
<pre><code class="language-toml">[output.html.playground]&#10;editable = false         # allows editing the source code&#10;copyable = true          # include the copy button for copying code snippets&#10;copy-js = true           # includes the JavaScript for the code editor&#10;line-numbers = false     # displays line numbers for editable code&#10;runnable = true          # displays a run button for rust code&#10;</code></pre>
<ul>
<li><strong>editable:</strong> Allow editing the source code. Defaults to <code>false</code>.</li>
<li><strong>copyable:</strong> Display the copy button on code snippets. Defaults to <code>true</code>.</li>
<li><strong>copy-js:</strong> Copy JavaScript files for the editor to the output directory.
Defaults to <code>true</code>.</li>
<li><strong>line-numbers:</strong> Display line numbers on editable sections of code. Requires both <code>editable</code> and <code>copy-js</code> to be <code>true</code>. Defaults to <code>false</code>.</li>
<li><strong>runnable:</strong> Displays a run button for rust code snippets. Changing this to <code>false</code> will disable the run in playground feature globally. Defaults to <code>true</code>.</li>
</ul>
<h3 id="outputhtmlcode"><a class="header" href="#outputhtmlcode"><code>[output.html.code]</code></a></h3>
<p>The <code>[output.html.code]</code> table provides options for controlling code blocks.</p>
<pre><code class="language-toml">[output.html.code]&#10;# A prefix string per language (one or more chars).&#10;# Any line starting with whitespace+prefix is hidden.&#10;hidelines = { python = "~" }&#10;</code></pre>
<ul>
<li><strong>hidelines:</strong> A table that defines how <a href="/docs/mdbook-trial/v0-5-4/en/01-guide/22-format-mdbook/#hiding-code-lines">hidden code lines</a> work for each language.
The key is the language and the value is a string that will cause code lines starting with that prefix to be hidden.</li>
</ul>
<h3 id="outputhtmlsearch"><a class="header" href="#outputhtmlsearch"><code>[output.html.search]</code></a></h3>
<p>The <code>[output.html.search]</code> table provides options for controlling the built-in text <a href="/docs/mdbook-trial/v0-5-4/en/01-guide/30-guide-reading/#search">search</a>.
mdBook must be compiled with the <code>search</code> feature enabled (on by default).</p>
<pre><code class="language-toml">[output.html.search]&#10;enable = true            # enables the search feature&#10;limit-results = 30       # maximum number of search results&#10;teaser-word-count = 30   # number of words used for a search result teaser&#10;use-boolean-and = true   # multiple search terms must all match&#10;boost-title = 2          # ranking boost factor for matches in headers&#10;boost-hierarchy = 1      # ranking boost factor for matches in page names&#10;boost-paragraph = 1      # ranking boost factor for matches in text&#10;expand = true            # partial words will match longer terms&#10;heading-split-level = 3  # link results to heading levels&#10;copy-js = true           # include Javascript code for search&#10;</code></pre>
<ul>
<li><strong>enable:</strong> Enables the search feature. Defaults to <code>true</code>.</li>
<li><strong>limit-results:</strong> The maximum number of search results. Defaults to <code>30</code>.</li>
<li><strong>teaser-word-count:</strong> The number of words used for a search result teaser.
Defaults to <code>30</code>.</li>
<li><strong>use-boolean-and:</strong> Define the logical link between multiple search words. If
true, all search words must appear in each result. Defaults to <code>false</code>.</li>
<li><strong>boost-title:</strong> Boost factor for the search result score if a search word
appears in the header. Defaults to <code>2</code>.</li>
<li><strong>boost-hierarchy:</strong> Boost factor for the search result score if a search word
appears in the hierarchy. The hierarchy contains all titles of the parent
documents and all parent headings. Defaults to <code>1</code>.</li>
<li><strong>boost-paragraph:</strong> Boost factor for the search result score if a search word
appears in the text. Defaults to <code>1</code>.</li>
<li><strong>expand:</strong> True if search should match longer results e.g. search <code>micro</code>
should match <code>microwave</code>. Defaults to <code>true</code>.</li>
<li><strong>heading-split-level:</strong> Search results will link to a section of the document
which contains the result. Documents are split into sections by headings this
level or less. Defaults to <code>3</code>. (<code>### This is a level 3 heading</code>)</li>
<li><strong>copy-js:</strong> Copy JavaScript files for the search implementation to the output
directory. Defaults to <code>true</code>.</li>
</ul>
<h4 id="outputhtmlsearchchapter"><a class="header" href="#outputhtmlsearchchapter"><code>[output.html.search.chapter]</code></a></h4>
<p>The [<code>output.html.search.chapter</code>] table provides the ability to modify search settings per chapter or directory. Each key is the path to the chapter source file or directory, and the value is a table of settings to apply to that path. This will merge recursively, with more specific paths taking precedence.</p>
<pre><code class="language-toml">[output.html.search.chapter]&#10;# Disables search indexing for all chapters in the `appendix` directory.&#10;"appendix" = { enable = false }&#10;# Enables search indexing for just this one appendix chapter.&#10;"appendix/glossary.md" = { enable = true }&#10;</code></pre>
<ul>
<li><strong>enable:</strong> Enables or disables search indexing for the given chapters. Defaults to <code>true</code>. This does not override the overall <code>output.html.search.enable</code> setting; that must be <code>true</code> for any search functionality to be enabled. Be cautious when disabling indexing for chapters because that can potentially lead to user confusion when they search for terms and expect them to be found. This should only be used in exceptional circumstances where keeping the chapter in the index will cause issues with the quality of the search results.</li>
</ul>
<h3 id="outputhtmlredirect"><a class="header" href="#outputhtmlredirect"><code>[output.html.redirect]</code></a></h3>
<p>The <code>[output.html.redirect]</code> table provides a way to add redirects.
This is useful when you move, rename, or remove a page to ensure that links to the old URL will go to the new location.</p>
<pre><code class="language-toml">[output.html.redirect]&#10;"/appendices/bibliography.html" = "https://rustc-dev-guide.rust-lang.org/appendix/bibliography.html"&#10;"/other-installation-methods.html" = "../infra/other-installation-methods.html"&#10;&#10;# Fragment redirects also work.&#10;"/some-existing-page.html#old-fragment" = "some-existing-page.html#new-fragment"&#10;&#10;# Fragment redirects also work for deleted pages.&#10;"/old-page.html" = "new-page.html"&#10;"/old-page.html#old-fragment" = "new-page.html#new-fragment"&#10;</code></pre>
<p>The table contains key-value pairs where the key is where the redirect file needs to be created, as an absolute path from the build directory, (e.g. <code>/appendices/bibliography.html</code>).
The value can be any valid URI the browser should navigate to (e.g. <code>https://rust-lang.org/</code>, <code>/overview.html</code>, or <code>../bibliography.html</code>).</p>
<p>This will generate an HTML page which will automatically redirect to the given location.</p>
<p>When fragment redirects are specified, the page must use JavaScript to redirect to the correct location. This is useful if you rename or move a section header. Fragment redirects work with existing pages and deleted pages.</p>
<h2 id="markdown-renderer"><a class="header" href="#markdown-renderer">Markdown renderer</a></h2>
<p>The Markdown renderer will run preprocessors and then output the resulting
Markdown. This is mostly useful for debugging preprocessors, especially in
conjunction with <code>mdbook test</code> to see the Markdown that <code>mdbook</code> is passing
to <code>rustdoc</code>.</p>
<p>The Markdown renderer is included with <code>mdbook</code> but disabled by default.
Enable it by adding an empty table to your <code>book.toml</code> as follows:</p>
<pre><code class="language-toml">[output.markdown]&#10;</code></pre>
<p>There are no configuration options for the Markdown renderer at this time;
only whether it is enabled or disabled.</p>
<p>See <a href="/docs/mdbook-trial/v0-5-4/en/01-guide/18-format-configuration-preprocessors/">the preprocessors documentation</a> for how to
specify which preprocessors should run before the Markdown renderer.</p>
</div>
