---
title: "mdBook-specific features"
documentId: "mdbook:guide/src/format/mdbook.md"
order: 25
licenseSource: "mdbook-guide"
documentContext: [{"kind": "source", "html": "<p>Fixed source: <a href=\"https://github.com/rust-lang/mdBook/blob/2ea30c00f00647d2b3f4c0f79b3e0e1eabc0b66d/guide/src/format/mdbook.md\">guide/src/format/mdbook.md</a>; mdBook 0.5.4. Documentation: MPL-2.0. Unofficial Libx presentation; internal links and code newline encoding adapted.</p><p>Free editable source (MPL-2.0 for the documentation and its Libx adaptation): <a href=\"/docs/mdbook-trial/downloads/v0-5-4/source.zip\">Download the complete Libx document source bundle</a>. It includes the original mdBook 0.5.4 source archive, editable document inputs, build context and material notices. The complete fixed MathJax source is a <a href=\"/docs/mdbook-trial/downloads/mathjax-2.7.1-d71cc406.tar.gz\">separate component</a>; separate material terms remain in force. This is an unpublished trial; translations and full semantic review are not complete.</p>"}, {"kind": "editorial", "html": "<p>Original example assets retained. Rust logo: CC BY 4.0, unchanged, no affiliation or endorsement. Font Awesome SVG: CC BY 4.0; non-icon code: MIT. The original MIT wording and literal SVG example remain unchanged. This trial has not completed source-offer or behavior validation.</p>"}, {"kind": "editorial", "html": "<p>Code demonstration runtime: fixed bundled mdBook 0.5.4 code (MPL-2.0), Ace (BSD-3-Clause), Highlight.js 10.1.1 (BSD-3-Clause) and Clipboard.js 2.0.4 (MIT). Original notices are preserved. Modern clipboard transport, icon-descendant button labels and shared-theme palette mapping are Libx integration adaptations; original code/editor text selection is retained. <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/ACE_LICENSE.txt\">Ace notice</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/HIGHLIGHT_LICENSE.txt\">Highlight.js notice</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/CLIPBOARD_LINKED_LICENSE.html\">Clipboard.js linked MIT notice</a>. Math equations use locally served MathJax 2.7.1, fixed at commit d71cc40666d213dceeb9353822a3b530656d9a4b. Code: <a href=\"/docs/mdbook-trial/mdbook-runtime/mathjax/LICENSE\">Apache-2.0</a>; bundled font families retain their separate OFL/GUST/LPPL notices. <a href=\"/docs/mdbook-trial/mdbook-runtime/mathjax/LIBX-NOTICES.txt\">Component notices and packaging changes</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/mathjax/LPPL-1.3c.txt\">LPPL 1.3c</a> · <a href=\"/docs/mdbook-trial/downloads/mathjax-2.7.1-d71cc406.tar.gz\">Full original MathJax source archive</a>. Runtime selection excludes legacy PNG fallback assets; compatibility verification remains pending in this unpublished trial.</p>"}]
prev: {"text": "MathJax support", "link": "/v0-5-4/en/01-guide/21-format-mathjax"}
next: {"text": "Markdown", "link": "/v0-5-4/en/01-guide/20-format-markdown"}
---

<div class="mdbook-guide">
<h1 id="mdbook-specific-features"><a class="header" href="#mdbook-specific-features">mdBook-specific features</a></h1>
<h2 id="hiding-code-lines"><a class="header" href="#hiding-code-lines">Hiding code lines</a></h2>
<p>There is a feature in mdBook that lets you hide code lines by prepending them with a specific prefix.</p>
<p>For the Rust language, you can prefix lines with <code># </code> (<code>#</code> followed by a space) to hide them <a href="https://doc.rust-lang.org/stable/rustdoc/write-documentation/documentation-tests.html#hiding-portions-of-the-example">like you would with Rustdoc</a>.
This prefix can be escaped with <code>##</code> to prevent the hiding of a line that should begin with the literal string <code># </code> (see <a href="https://doc.rust-lang.org/stable/rustdoc/write-documentation/documentation-tests.html#hiding-portions-of-the-example">Rustdoc’s docs</a> for more details)</p>
<pre><code class="language-bash"># fn main() {&#10;    let x = 5;&#10;    let y = 6;&#10;&#10;    println!("{}", x + y);&#10;# }&#10;</code></pre>
<p>Will render as</p>
<pre class="playground"><code class="language-rust edition2018"><span class="boring">fn main() {&#10;</span>    let x = 5;&#10;    let y = 6;&#10;&#10;    println!("{}", x + y);&#10;<span class="boring">}</span></code></pre>
<p>When you tap or hover the mouse over the code block, there will be an eyeball icon (<span class="fa-svg"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><!--! Font Awesome Free 6.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2022 Fonticons, Inc. --><path d="M160 256C160 185.3 217.3 128 288 128C358.7 128 416 185.3 416 256C416 326.7 358.7 384 288 384C217.3 384 160 326.7 160 256zM288 336C332.2 336 368 300.2 368 256C368 211.8 332.2 176 288 176C287.3 176 286.7 176 285.1 176C287.3 181.1 288 186.5 288 192C288 227.3 259.3 256 224 256C218.5 256 213.1 255.3 208 253.1C208 254.7 208 255.3 208 255.1C208 300.2 243.8 336 288 336L288 336zM95.42 112.6C142.5 68.84 207.2 32 288 32C368.8 32 433.5 68.84 480.6 112.6C527.4 156 558.7 207.1 573.5 243.7C576.8 251.6 576.8 260.4 573.5 268.3C558.7 304 527.4 355.1 480.6 399.4C433.5 443.2 368.8 480 288 480C207.2 480 142.5 443.2 95.42 399.4C48.62 355.1 17.34 304 2.461 268.3C-.8205 260.4-.8205 251.6 2.461 243.7C17.34 207.1 48.62 156 95.42 112.6V112.6zM288 80C222.8 80 169.2 109.6 128.1 147.7C89.6 183.5 63.02 225.1 49.44 256C63.02 286 89.6 328.5 128.1 364.3C169.2 402.4 222.8 432 288 432C353.2 432 406.8 402.4 447.9 364.3C486.4 328.5 512.1 286 526.6 256C512.1 225.1 486.4 183.5 447.9 147.7C406.8 109.6 353.2 80 288 80V80z"></path></svg></span>) which will toggle the visibility of the hidden lines.</p>
<p>By default, this only works for code examples that are annotated with <code>rust</code>.
However, you can define custom prefixes for other languages by adding a new line-hiding prefix in your <code>book.toml</code> with the language name and prefix character(s):</p>
<pre><code class="language-toml">[output.html.code.hidelines]&#10;python = "~"&#10;</code></pre>
<p>The prefix will hide any lines that begin with the given prefix. With the python prefix shown above, this:</p>
<pre><code class="language-bash">~hidden()&#10;nothidden():&#10;~    hidden()&#10;    ~hidden()&#10;    nothidden()&#10;</code></pre>
<p>will render as</p>
<pre><code class="language-python"><span class="boring">hidden()&#10;</span>nothidden():&#10;<span class="boring">    hidden()&#10;</span><span class="boring">    hidden()&#10;</span>    nothidden()&#10;</code></pre>
<p>This behavior can be overridden locally with a different prefix. This has the same effect as above:</p>
<pre><code class="language-markdown">```python,hidelines=!!!&#10;!!!hidden()&#10;nothidden():&#10;!!!    hidden()&#10;    !!!hidden()&#10;    nothidden()&#10;```&#10;</code></pre>
<h2 id="rust-playground"><a class="header" href="#rust-playground">Rust playground</a></h2>
<p>Rust language code blocks will automatically get a play button (<span class="fa-svg"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><!--! Font Awesome Free 6.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2022 Fonticons, Inc. --><path d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80V432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z"></path></svg></span>) which will execute the code and display the output just below the code block.
This works by sending the code to the <a href="https://play.rust-lang.org/">Rust Playground</a>.</p>
<pre class="playground"><code class="language-rust edition2018"><span class="boring">#![allow(unused)]&#10;</span><span class="boring">fn main() {&#10;</span>println!("Hello, World!");&#10;<span class="boring">}</span></code></pre>
<p>If there is no <code>main</code> function, then the code is automatically wrapped inside one.</p>
<p>If you wish to disable the play button for a code block, you can include the <code>noplayground</code> option on the code block like this:</p>
<pre><code class="language-markdown">```rust,noplayground&#10;let mut name = String::new();&#10;std::io::stdin().read_line(&#x26;mut name).expect("failed to read line");&#10;println!("Hello {}!", name);&#10;```&#10;</code></pre>
<p>Or, if you wish to disable the play button for all code blocks in your book, you can write the config to the <code>book.toml</code> like this.</p>
<pre><code class="language-toml">[output.html.playground]&#10;runnable = false&#10;</code></pre>
<h2 id="rust-code-block-attributes"><a class="header" href="#rust-code-block-attributes">Rust code block attributes</a></h2>
<p>Additional attributes can be included in Rust code blocks with comma, space, or tab-separated terms just after the language term. For example:</p>
<pre><code class="language-markdown">```rust,ignore&#10;# This example won't be tested.&#10;panic!("oops!");&#10;```&#10;</code></pre>
<p>These are particularly important when using <a href="/docs/mdbook-trial/v0-5-4/en/01-guide/08-cli-test/"><code>mdbook test</code></a> to test Rust examples.
These use the same attributes as <a href="https://doc.rust-lang.org/rustdoc/documentation-tests.html#attributes">rustdoc attributes</a>, with a few additions:</p>
<ul>
<li><code>editable</code> — Enables the <a href="/docs/mdbook-trial/v0-5-4/en/01-guide/25-format-theme-editor/">editor</a>.</li>
<li><code>noplayground</code> — Removes the play button, but will still be tested.</li>
<li><code>mdbook-runnable</code> — Forces the play button to be displayed.
This is intended to be combined with the <code>ignore</code> attribute for examples that should not be tested, but you want to allow the reader to run.</li>
<li><code>ignore</code> — Will not be tested and no play button is shown, but it is still highlighted as Rust syntax.</li>
<li><code>should_panic</code> — When executed, it should produce a panic.</li>
<li><code>no_run</code> — The code is compiled when tested, but it is not run.
The play button is also not shown.</li>
<li><code>compile_fail</code> — The code should fail to compile.</li>
<li><code>edition2015</code>, <code>edition2018</code>, <code>edition2021</code>, <code>edition2024</code> — Forces the use of a specific Rust edition.
See <a href="/docs/mdbook-trial/v0-5-4/en/01-guide/17-format-configuration-general/#rust-options"><code>rust.edition</code></a> to set this globally.</li>
</ul>
<h2 id="including-files"><a class="header" href="#including-files">Including files</a></h2>
<p>With the following syntax, you can include files into your book:</p>
<pre><code class="language-hbs">{{#include file.rs}}&#10;</code></pre>
<p>The path to the file has to be relative from the current source file.</p>
<p>mdBook will interpret included files as Markdown. Since the include command
is usually used for inserting code snippets and examples, you will often
wrap the command with <code>```</code> to display the file contents without
interpreting them.</p>
<pre><code class="language-hbs">```&#10;{{#include file.rs}}&#10;```&#10;</code></pre>
<h2 id="including-portions-of-a-file"><a class="header" href="#including-portions-of-a-file">Including portions of a file</a></h2>
<p>Often you only need a specific part of the file, e.g. relevant lines for an
example. We support four different modes of partial includes:</p>
<pre><code class="language-hbs">{{#include file.rs:2}}&#10;{{#include file.rs::10}}&#10;{{#include file.rs:2:}}&#10;{{#include file.rs:2:10}}&#10;</code></pre>
<p>The first command only includes the second line from file <code>file.rs</code>. The second
command includes all lines up to line 10, i.e. the lines from 11 till the end of
the file are omitted. The third command includes all lines from line 2, i.e. the
first line is omitted. The last command includes the excerpt of <code>file.rs</code>
consisting of lines 2 to 10.</p>
<p>To avoid breaking your book when modifying included files, you can also
include a specific section using anchors instead of line numbers.
An anchor is a pair of matching lines. The line beginning an anchor must
match the regex <code>ANCHOR:\s*[\w_-]+</code> and similarly the ending line must match
the regex <code>ANCHOR_END:\s*[\w_-]+</code>. This allows you to put anchors in
any kind of commented line.</p>
<p>Consider the following file to include:</p>
<pre><code class="language-rs">/* ANCHOR: all */&#10;&#10;// ANCHOR: component&#10;struct Paddle {&#10;    hello: f32,&#10;}&#10;// ANCHOR_END: component&#10;&#10;////////// ANCHOR: system&#10;impl System for MySystem { ... }&#10;////////// ANCHOR_END: system&#10;&#10;/* ANCHOR_END: all */&#10;</code></pre>
<p>Then in the book, all you have to do is:</p>
<pre><code class="language-hbs">Here is a component:&#10;```rust,no_run,noplayground&#10;{{#include file.rs:component}}&#10;```&#10;&#10;Here is a system:&#10;```rust,no_run,noplayground&#10;{{#include file.rs:system}}&#10;```&#10;&#10;This is the full file.&#10;```rust,no_run,noplayground&#10;{{#include file.rs:all}}&#10;```&#10;</code></pre>
<p>Lines containing anchor patterns inside the included anchor are ignored.</p>
<h2 id="including-a-file-but-initially-hiding-all-except-specified-lines"><a class="header" href="#including-a-file-but-initially-hiding-all-except-specified-lines">Including a file but initially hiding all except specified lines</a></h2>
<p>The <code>rustdoc_include</code> helper is for including code from external Rust files that contain complete
examples, but only initially showing particular lines specified with line numbers or anchors in the
same way as with <code>include</code>.</p>
<p>The lines not in the line number range or between the anchors will still be included, but they will
be prefaced with <code>#</code>. This way, a reader can expand the snippet to see the complete example, and
Rustdoc will use the complete example when you run <code>mdbook test</code>.</p>
<p>For example, consider a file named <code>file.rs</code> that contains this Rust program:</p>
<pre class="playground"><code class="language-rust edition2018">fn main() {&#10;    let x = add_one(2);&#10;    assert_eq!(x, 3);&#10;}&#10;&#10;fn add_one(num: i32) -> i32 {&#10;    num + 1&#10;}</code></pre>
<p>We can include a snippet that initially shows only line 2 by using this syntax:</p>
<pre><code class="language-hbs">To call the `add_one` function, we pass it an `i32` and bind the returned value to `x`:&#10;&#10;```rust&#10;{{#rustdoc_include file.rs:2}}&#10;```&#10;</code></pre>
<p>This would have the same effect as if we had manually inserted the code and hidden all but line 2
using <code>#</code>:</p>
<pre><code class="language-hbs">To call the `add_one` function, we pass it an `i32` and bind the returned value to `x`:&#10;&#10;```rust&#10;# fn main() {&#10;    let x = add_one(2);&#10;#     assert_eq!(x, 3);&#10;# }&#10;#&#10;# fn add_one(num: i32) -> i32 {&#10;#     num + 1&#10;# }&#10;```&#10;</code></pre>
<p>That is, it looks like this (click the “expand” icon to see the rest of the file):</p>
<pre class="playground"><code class="language-rust edition2018"><span class="boring">fn main() {&#10;</span>    let x = add_one(2);&#10;<span class="boring">    assert_eq!(x, 3);&#10;</span><span class="boring">}&#10;</span><span class="boring">&#10;</span><span class="boring">fn add_one(num: i32) -> i32 {&#10;</span><span class="boring">    num + 1&#10;</span><span class="boring">}</span></code></pre>
<h2 id="inserting-runnable-rust-files"><a class="header" href="#inserting-runnable-rust-files">Inserting runnable Rust files</a></h2>
<p>With the following syntax, you can insert runnable Rust files into your book:</p>
<pre><code class="language-hbs">{{#playground file.rs}}&#10;</code></pre>
<p>The path to the Rust file has to be relative from the current source file.</p>
<p>When play is clicked, the code snippet will be sent to the <a href="https://play.rust-lang.org/">Rust Playground</a> to be
compiled and run. The result is sent back and displayed directly underneath the
code.</p>
<p>Here is what a rendered code snippet looks like:</p>
<pre class="playground"><code class="language-rust edition2018">fn main() {&#10;    println!("Hello World!");&#10;<span class="boring">&#10;</span><span class="boring">    // You can even hide lines! :D&#10;</span><span class="boring">    println!("I am hidden! Expand the code snippet to see me");&#10;</span>}</code></pre>
<p>Any additional values passed after the filename will be included as attributes of the code block.
For example <code>{{#playground example.rs editable}}</code> will create the code block like the following:</p>
<pre><code class="language-markdown">```rust,editable&#10;# Contents of example.rs here.&#10;```&#10;</code></pre>
<p>And the <code>editable</code> attribute will enable the <a href="/docs/mdbook-trial/v0-5-4/en/01-guide/25-format-theme-editor/">editor</a> as described at <a href="#rust-code-block-attributes">Rust code block attributes</a>.</p>
<h2 id="controlling-page-title"><a class="header" href="#controlling-page-title">Controlling page &#x3C;title></a></h2>
<p>A chapter can set a &#x3C;title> that is different from its entry in the table of
contents (sidebar) by including a <code>{{#title ...}}</code> near the top of the page.</p>
<pre><code class="language-hbs">{{#title My Title}}&#10;</code></pre>
<h2 id="html-classes-provided-by-mdbook"><a class="header" href="#html-classes-provided-by-mdbook">HTML classes provided by mdBook</a></h2>
<img class="right" src="/docs/mdbook-trial/source-assets/format/images/rust-logo-blk.svg" alt="The Rust logo">
<h3 id="classleft-and-right"><a class="header" href="#classleft-and-right"><code>class="left"</code> and <code>"right"</code></a></h3>
<p>These classes are provided by default, for inline HTML to float images.</p>
<pre><code class="language-html">&#x3C;img class="right" src="images/rust-logo-blk.svg" alt="The Rust logo">&#10;</code></pre>
<h3 id="classhidden"><a class="header" href="#classhidden"><code>class="hidden"</code></a></h3>
<p>HTML tags with class <code>hidden</code> will not be shown.</p>
<pre><code class="language-html">&#x3C;div class="hidden">This will not be seen.&#x3C;/div>&#10;</code></pre>
<div class="hidden">This will not be seen.</div>
<h2 id="font-awesome-icons"><a class="header" href="#font-awesome-icons">Font-Awesome icons</a></h2>
<p>mdBook includes a copy of version 6 of <a href="https://fontawesome.com">Font Awesome Free’s</a>
MIT-licensed SVG files. It emulates the <code>&#x3C;i></code> syntax, but converts the results
to inline SVG. Only the regular, solid, and brands icons are included; paid
features like the light icons are not.</p>
<p>For example, given this HTML syntax:</p>
<pre><code class="language-hbs">The result looks like this: &#x3C;i class="fa-solid fa-print">&#x3C;/i>&#10;</code></pre>
<p>The result looks like this: <span class="fa-svg"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Free 6.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2022 Fonticons, Inc. --><path d="M128 0C92.7 0 64 28.7 64 64v96h64V64H354.7L384 93.3V160h64V93.3c0-17-6.7-33.3-18.7-45.3L400 18.7C388 6.7 371.7 0 354.7 0H128zM384 352v32 64H128V384 368 352H384zm64 32h32c17.7 0 32-14.3 32-32V256c0-35.3-28.7-64-64-64H64c-35.3 0-64 28.7-64 64v96c0 17.7 14.3 32 32 32H64v64c0 35.3 28.7 64 64 64H384c35.3 0 64-28.7 64-64V384zm-16-88c-13.3 0-24-10.7-24-24s10.7-24 24-24s24 10.7 24 24s-10.7 24-24 24z"></path></svg></span></p>
<p>See the <a href="https://fontawesome.com/v6/search">free icon set</a> for the available icons.</p>
</div>
