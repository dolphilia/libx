---
title: "Configuration"
documentId: "mdbook:guide/src/format/configuration/README.md"
order: 15
licenseSource: "mdbook-guide"
documentContext: [{"kind": "source", "html": "<p>Fixed source: <a href=\"https://github.com/rust-lang/mdBook/blob/2ea30c00f00647d2b3f4c0f79b3e0e1eabc0b66d/guide/src/format/configuration/README.md\">guide/src/format/configuration/README.md</a>; mdBook 0.5.4. Documentation: MPL-2.0. Unofficial Libx presentation; internal links and code newline encoding adapted.</p><p>Free editable source (MPL-2.0 for the documentation and its Libx adaptation): <a href=\"/docs/mdbook-trial/downloads/v0-5-4/source.zip\">Download the complete Libx document source bundle</a>. It includes the original mdBook 0.5.4 source archive, editable document inputs, build context and material notices. The complete fixed MathJax source is a <a href=\"/docs/mdbook-trial/downloads/mathjax-2.7.1-d71cc406.tar.gz\">separate component</a>; separate material terms remain in force. This is an unpublished trial; translations and full semantic review are not complete.</p>"}, {"kind": "editorial", "html": "<p>Code demonstration runtime: fixed bundled mdBook 0.5.4 code (MPL-2.0), Ace (BSD-3-Clause), Highlight.js 10.1.1 (BSD-3-Clause) and Clipboard.js 2.0.4 (MIT). Original notices are preserved. Modern clipboard transport, icon-descendant button labels and shared-theme palette mapping are Libx integration adaptations; original code/editor text selection is retained. <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/ACE_LICENSE.txt\">Ace notice</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/HIGHLIGHT_LICENSE.txt\">Highlight.js notice</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/CLIPBOARD_LINKED_LICENSE.html\">Clipboard.js linked MIT notice</a>. Math equations use locally served MathJax 2.7.1, fixed at commit d71cc40666d213dceeb9353822a3b530656d9a4b. Code: <a href=\"/docs/mdbook-trial/mdbook-runtime/mathjax/LICENSE\">Apache-2.0</a>; bundled font families retain their separate OFL/GUST/LPPL notices. <a href=\"/docs/mdbook-trial/mdbook-runtime/mathjax/LIBX-NOTICES.txt\">Component notices and packaging changes</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/mathjax/LPPL-1.3c.txt\">LPPL 1.3c</a> · <a href=\"/docs/mdbook-trial/downloads/mathjax-2.7.1-d71cc406.tar.gz\">Full original MathJax source archive</a>. Runtime selection excludes legacy PNG fallback assets; compatibility verification remains pending in this unpublished trial.</p>"}]
prev: {"text": "SUMMARY.md", "link": "/v0-5-4/en/01-guide/23-format-summary"}
next: {"text": "General", "link": "/v0-5-4/en/01-guide/17-format-configuration-general"}
---

<div class="mdbook-guide">
<h1 id="configuration"><a class="header" href="#configuration">Configuration</a></h1>
<p>This section details the configuration options available in the <em><strong>book.toml</strong></em>:</p>
<ul>
<li><strong><a href="/docs/mdbook-trial/v0-5-4/en/01-guide/17-format-configuration-general/">General</a></strong> configuration including the <code>book</code>, <code>rust</code>, <code>build</code> sections</li>
<li><strong><a href="/docs/mdbook-trial/v0-5-4/en/01-guide/18-format-configuration-preprocessors/">Preprocessor</a></strong> configuration for default and custom book preprocessors</li>
<li><strong><a href="/docs/mdbook-trial/v0-5-4/en/01-guide/19-format-configuration-renderers/">Renderer</a></strong> configuration for the HTML, Markdown and custom renderers</li>
<li><strong><a href="/docs/mdbook-trial/v0-5-4/en/01-guide/16-format-configuration-environment-variables/">Environment Variable</a></strong> configuration for overriding configuration options in your environment</li>
</ul>
</div>
