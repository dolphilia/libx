---
title: "Environment variables"
documentId: "mdbook:guide/src/format/configuration/environment-variables.md"
order: 19
licenseSource: "mdbook-guide"
documentContext: [{"kind": "source", "html": "<p>Fixed source: <a href=\"https://github.com/rust-lang/mdBook/blob/2ea30c00f00647d2b3f4c0f79b3e0e1eabc0b66d/guide/src/format/configuration/environment-variables.md\">guide/src/format/configuration/environment-variables.md</a>; mdBook 0.5.4. Documentation: MPL-2.0. Unofficial Libx presentation; internal links and code newline encoding adapted.</p><p>Free editable source (MPL-2.0 for the documentation and its Libx adaptation): <a href=\"/docs/mdbook-trial/downloads/v0-5-4/source.zip\">Download the complete Libx document source bundle</a>. It includes the original mdBook 0.5.4 source archive, editable document inputs, build context and material notices. The complete fixed MathJax source is a <a href=\"/docs/mdbook-trial/downloads/mathjax-2.7.1-d71cc406.tar.gz\">separate component</a>; separate material terms remain in force. This is an unpublished trial; translations and full semantic review are not complete.</p>"}, {"kind": "editorial", "html": "<p>Code demonstration runtime: fixed bundled mdBook 0.5.4 code (MPL-2.0), Ace (BSD-3-Clause), Highlight.js 10.1.1 (BSD-3-Clause) and Clipboard.js 2.0.4 (MIT). Original notices are preserved. Modern clipboard transport, icon-descendant button labels and shared-theme palette mapping are Libx integration adaptations; original code/editor text selection is retained. <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/ACE_LICENSE.txt\">Ace notice</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/HIGHLIGHT_LICENSE.txt\">Highlight.js notice</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/notices/CLIPBOARD_LINKED_LICENSE.html\">Clipboard.js linked MIT notice</a>. Math equations use locally served MathJax 2.7.1, fixed at commit d71cc40666d213dceeb9353822a3b530656d9a4b. Code: <a href=\"/docs/mdbook-trial/mdbook-runtime/mathjax/LICENSE\">Apache-2.0</a>; bundled font families retain their separate OFL/GUST/LPPL notices. <a href=\"/docs/mdbook-trial/mdbook-runtime/mathjax/LIBX-NOTICES.txt\">Component notices and packaging changes</a> · <a href=\"/docs/mdbook-trial/mdbook-runtime/mathjax/LPPL-1.3c.txt\">LPPL 1.3c</a> · <a href=\"/docs/mdbook-trial/downloads/mathjax-2.7.1-d71cc406.tar.gz\">Full original MathJax source archive</a>. Runtime selection excludes legacy PNG fallback assets; compatibility verification remains pending in this unpublished trial.</p>"}]
prev: {"text": "Renderers", "link": "/v0-5-4/en/01-guide/19-format-configuration-renderers"}
next: {"text": "Theme", "link": "/v0-5-4/en/01-guide/24-format-theme-index"}
---

<div class="mdbook-guide">
<h1 id="environment-variables"><a class="header" href="#environment-variables">Environment variables</a></h1>
<p>All configuration values can be overridden from the command line by setting the
corresponding environment variable. Because many operating systems restrict
environment variables to be alphanumeric characters or <code>_</code>, the configuration
key needs to be formatted slightly differently to the normal <code>foo.bar.baz</code> form.</p>
<p>Variables starting with <code>MDBOOK_</code> are used for configuration. The key is created
by removing the <code>MDBOOK_</code> prefix and turning the resulting string into
<code>kebab-case</code>. Double underscores (<code>__</code>) separate nested keys, while a single
underscore (<code>_</code>) is replaced with a dash (<code>-</code>).</p>
<p>For example:</p>
<ul>
<li><code>MDBOOK_book</code> -> <code>book</code></li>
<li><code>MDBOOK_BOOK</code> -> <code>book</code></li>
<li><code>MDBOOK_BOOK__TITLE</code> -> <code>book.title</code></li>
<li><code>MDBOOK_BOOK__TEXT_DIRECTION</code> -> <code>book.text-direction</code></li>
</ul>
<p>So by setting the <code>MDBOOK_BOOK__TITLE</code> environment variable you can override the
book’s title without needing to touch your <code>book.toml</code>.</p>
<blockquote>
<p><strong>Note:</strong> To facilitate setting more complex config items, the value of an
environment variable is first parsed as JSON, falling back to a string if the
parse fails.</p>
<p>This means, if you so desired, you could override all book metadata when
building the book with something like</p>
<pre><code class="language-shell">$ export MDBOOK_BOOK='{"title": "My Awesome Book", "authors": ["Michael-F-Bryan"]}'&#10;$ mdbook build&#10;</code></pre>
</blockquote>
<p>The latter case may be useful in situations where <code>mdbook</code> is invoked from a
script or CI, where it sometimes isn’t possible to update the <code>book.toml</code> before
building.</p>
</div>
