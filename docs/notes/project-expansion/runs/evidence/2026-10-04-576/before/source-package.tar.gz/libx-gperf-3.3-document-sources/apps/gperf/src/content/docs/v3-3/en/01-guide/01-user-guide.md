---
title: "User guide (edition 3.2 bundled with gperf 3.3)"
licenseSource: "gperf-guide"
---

This is an unofficial Libx presentation of the complete documentation bundled in the fixed GNU gperf 3.3 release archive. The user guide identifies itself as edition 3.2 (28 October 2024); the CLI identifies version 3.3 (April 2025). These original version labels are preserved. The version metadata date is the source acquisition date (2026-10-03), not a claimed upstream release day.

[Original release archive](https://ftp.gnu.org/pub/gnu/gperf/gperf-3.3.tar.gz) — SHA-256 `fd87e0aba7e43ae054837afd6cd4db03a3f2693deb3619085e6ed9d8d9604ad8`. Formatting, internal links, and explicitly marked editorial notes are Libx changes.

Libx modification date (Japan Standard Time): 2026-10-04. This complete derived user guide, including the Libx translation, formatting and editorial changes, is distributed under the original manual permission notice reproduced below.

<div class="gperf-original">

<H1>User's Guide to <CODE>gperf</CODE> 3.2</H1>
<H2>The GNU Perfect Hash Function Generator</H2>
<H2>Edition 3.2, 28 October 2024</H2>
<ADDRESS>Douglas C. Schmidt</ADDRESS>
<ADDRESS>Bruno Haible</ADDRESS>
<P>
<P><HR><P>
<H1>Table of Contents</H1>
<UL>
<LI><A NAME="TOC1" HREF="#SEC1">GNU GENERAL PUBLIC LICENSE</A>
<LI><A NAME="TOC2" HREF="#SEC2">Contributors to GNU <CODE>gperf</CODE> Utility</A>
<LI><A NAME="TOC3" HREF="#SEC3">2  Introduction</A>
<LI><A NAME="TOC4" HREF="#SEC4">3  Static search structures and GNU <CODE>gperf</CODE></A>
<LI><A NAME="TOC5" HREF="#SEC5">4  High-Level Description of GNU <CODE>gperf</CODE></A>
<UL>
<LI><A NAME="TOC6" HREF="#SEC6">4.1  Input Format to <CODE>gperf</CODE></A>
<UL>
<LI><A NAME="TOC7" HREF="#SEC7">4.1.1  Declarations</A>
<UL>
<LI><A NAME="TOC8" HREF="#SEC8">4.1.1.1  User-supplied <CODE>struct</CODE></A>
<LI><A NAME="TOC9" HREF="#SEC9">4.1.1.2  Gperf Declarations</A>
<LI><A NAME="TOC10" HREF="#SEC10">4.1.1.3  C Code Inclusion</A>
</UL>
<LI><A NAME="TOC11" HREF="#SEC11">4.1.2  Format for Keyword Entries</A>
<LI><A NAME="TOC12" HREF="#SEC12">4.1.3  Including Additional C Functions</A>
<LI><A NAME="TOC13" HREF="#SEC13">4.1.4  Where to place directives for GNU <CODE>indent</CODE>.</A>
</UL>
<LI><A NAME="TOC14" HREF="#SEC14">4.2  Output Format for Generated C Code with <CODE>gperf</CODE></A>
<LI><A NAME="TOC15" HREF="#SEC15">4.3  Use of NUL bytes</A>
<LI><A NAME="TOC16" HREF="#SEC16">4.4  Controlling Identifiers</A>
<LI><A NAME="TOC17" HREF="#SEC17">4.5  The Copyright of the Output</A>
</UL>
<LI><A NAME="TOC18" HREF="#SEC18">5  Invoking <CODE>gperf</CODE></A>
<UL>
<LI><A NAME="TOC19" HREF="#SEC19">5.1  Specifying the Location of the Output File</A>
<LI><A NAME="TOC20" HREF="#SEC20">5.2  Options that affect Interpretation of the Input File</A>
<LI><A NAME="TOC21" HREF="#SEC21">5.3  Options to specify the Language for the Output Code</A>
<LI><A NAME="TOC22" HREF="#SEC22">5.4  Options for fine tuning Details in the Output Code</A>
<LI><A NAME="TOC23" HREF="#SEC23">5.5  Options for changing the Algorithms employed by <CODE>gperf</CODE></A>
<LI><A NAME="TOC24" HREF="#SEC24">5.6  Informative Output</A>
</UL>
<LI><A NAME="TOC25" HREF="#SEC25">6  Known Bugs and Limitations with <CODE>gperf</CODE></A>
<LI><A NAME="TOC26" HREF="#SEC26">7  Things Still Left to Do</A>
<LI><A NAME="TOC27" HREF="#SEC27">8  Bibliography</A>
<LI><A NAME="TOC28" HREF="#SEC28">Concept Index</A>
</UL>
<P><HR><P>

<P>
Copyright (C) 1989-2024 Free Software Foundation, Inc.

</P>

<P>
Permission is granted to make and distribute verbatim copies of
this manual provided the copyright notice and this permission notice
are preserved on all copies.

</P>
<P>
Permission is granted to copy and distribute modified versions of this
manual under the conditions for verbatim copying, provided also that the
section entitled “GNU General Public License” is included
exactly as in the original, and provided that the entire resulting
derived work is distributed under the terms of a permission notice
identical to this one.

</P>
<P>
Permission is granted to copy and distribute translations of this manual
into another language, under the above conditions for modified versions,
except that the section entitled “GNU General Public License” may be
included in a translation approved by the author instead of in the
original English.

</P>



<H1><A NAME="SEC1" HREF="gperf.html#TOC1">GNU GENERAL PUBLIC LICENSE</A></H1>
<P>
Version 3, 29 June 2007

</P>


<PRE>
Copyright (C) 2007 Free Software Foundation, Inc. <A HREF="http://fsf.org/">http://fsf.org/</A>

Everyone is permitted to copy and distribute verbatim copies of this
license document, but changing it is not allowed.
</PRE>


<H2>1.0  Preamble</H2>

<P>
The GNU General Public License is a free, copyleft license for
software and other kinds of works.

</P>
<P>
The licenses for most software and other practical works are designed
to take away your freedom to share and change the works.  By contrast,
the GNU General Public License is intended to guarantee your freedom
to share and change all versions of a program--to make sure it remains
free software for all its users.  We, the Free Software Foundation,
use the GNU General Public License for most of our software; it
applies also to any other work released this way by its authors.  You
can apply it to your programs, too.

</P>
<P>
When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
them if you wish), that you receive source code or can get it if you
want it, that you can change the software or use pieces of it in new
free programs, and that you know you can do these things.

</P>
<P>
To protect your rights, we need to prevent others from denying you
these rights or asking you to surrender the rights.  Therefore, you
have certain responsibilities if you distribute copies of the
software, or if you modify it: responsibilities to respect the freedom
of others.

</P>
<P>
For example, if you distribute copies of such a program, whether
gratis or for a fee, you must pass on to the recipients the same
freedoms that you received.  You must make sure that they, too,
receive or can get the source code.  And you must show them these
terms so they know their rights.

</P>
<P>
Developers that use the GNU GPL protect your rights with two steps:
(1) assert copyright on the software, and (2) offer you this License
giving you legal permission to copy, distribute and/or modify it.

</P>
<P>
For the developers' and authors' protection, the GPL clearly explains
that there is no warranty for this free software.  For both users' and
authors' sake, the GPL requires that modified versions be marked as
changed, so that their problems will not be attributed erroneously to
authors of previous versions.

</P>
<P>
Some devices are designed to deny users access to install or run
modified versions of the software inside them, although the
manufacturer can do so.  This is fundamentally incompatible with the
aim of protecting users' freedom to change the software.  The
systematic pattern of such abuse occurs in the area of products for
individuals to use, which is precisely where it is most unacceptable.
Therefore, we have designed this version of the GPL to prohibit the
practice for those products.  If such problems arise substantially in
other domains, we stand ready to extend this provision to those
domains in future versions of the GPL, as needed to protect the
freedom of users.

</P>
<P>
Finally, every program is threatened constantly by software patents.
States should not allow patents to restrict development and use of
software on general-purpose computers, but in those that do, we wish
to avoid the special danger that patents applied to a free program
could make it effectively proprietary.  To prevent this, the GPL
assures that patents cannot be used to render the program non-free.

</P>
<P>
The precise terms and conditions for copying, distribution and
modification follow.

</P>

<H2>1.1  TERMS AND CONDITIONS</H2>


<OL>
<LI>Definitions.

“This License” refers to version 3 of the GNU General Public License.

“Copyright” also means copyright-like laws that apply to other kinds
of works, such as semiconductor masks.

“The Program” refers to any copyrightable work licensed under this
License.  Each licensee is addressed as “you”.  “Licensees” and
“recipients” may be individuals or organizations.

To “modify” a work means to copy from or adapt all or part of the work
in a fashion requiring copyright permission, other than the making of
an exact copy.  The resulting work is called a “modified version” of
the earlier work or a work “based on” the earlier work.

A “covered work” means either the unmodified Program or a work based
on the Program.

To “propagate” a work means to do anything with it that, without
permission, would make you directly or secondarily liable for
infringement under applicable copyright law, except executing it on a
computer or modifying a private copy.  Propagation includes copying,
distribution (with or without modification), making available to the
public, and in some countries other activities as well.

To “convey” a work means any kind of propagation that enables other
parties to make or receive copies.  Mere interaction with a user
through a computer network, with no transfer of a copy, is not
conveying.

An interactive user interface displays “Appropriate Legal Notices” to
the extent that it includes a convenient and prominently visible
feature that (1) displays an appropriate copyright notice, and (2)
tells the user that there is no warranty for the work (except to the
extent that warranties are provided), that licensees may convey the
work under this License, and how to view a copy of this License.  If
the interface presents a list of user commands or options, such as a
menu, a prominent item in the list meets this criterion.

<LI>Source Code.

The “source code” for a work means the preferred form of the work for
making modifications to it.  “Object code” means any non-source form
of a work.

A “Standard Interface” means an interface that either is an official
standard defined by a recognized standards body, or, in the case of
interfaces specified for a particular programming language, one that
is widely used among developers working in that language.

The “System Libraries” of an executable work include anything, other
than the work as a whole, that (a) is included in the normal form of
packaging a Major Component, but which is not part of that Major
Component, and (b) serves only to enable use of the work with that
Major Component, or to implement a Standard Interface for which an
implementation is available to the public in source code form.  A
“Major Component”, in this context, means a major essential component
(kernel, window system, and so on) of the specific operating system
(if any) on which the executable work runs, or a compiler used to
produce the work, or an object code interpreter used to run it.

The “Corresponding Source” for a work in object code form means all
the source code needed to generate, install, and (for an executable
work) run the object code and to modify the work, including scripts to
control those activities.  However, it does not include the work's
System Libraries, or general-purpose tools or generally available free
programs which are used unmodified in performing those activities but
which are not part of the work.  For example, Corresponding Source
includes interface definition files associated with source files for
the work, and the source code for shared libraries and dynamically
linked subprograms that the work is specifically designed to require,
such as by intimate data communication or control flow between those
subprograms and other parts of the work.

The Corresponding Source need not include anything that users can
regenerate automatically from other parts of the Corresponding Source.

The Corresponding Source for a work in source code form is that same
work.

<LI>Basic Permissions.

All rights granted under this License are granted for the term of
copyright on the Program, and are irrevocable provided the stated
conditions are met.  This License explicitly affirms your unlimited
permission to run the unmodified Program.  The output from running a
covered work is covered by this License only if the output, given its
content, constitutes a covered work.  This License acknowledges your
rights of fair use or other equivalent, as provided by copyright law.

You may make, run and propagate covered works that you do not convey,
without conditions so long as your license otherwise remains in force.
You may convey covered works to others for the sole purpose of having
them make modifications exclusively for you, or provide you with
facilities for running those works, provided that you comply with the
terms of this License in conveying all material for which you do not
control copyright.  Those thus making or running the covered works for
you must do so exclusively on your behalf, under your direction and
control, on terms that prohibit them from making any copies of your
copyrighted material outside their relationship with you.

Conveying under any other circumstances is permitted solely under the
conditions stated below.  Sublicensing is not allowed; section 10
makes it unnecessary.

<LI>Protecting Users' Legal Rights From Anti-Circumvention Law.

No covered work shall be deemed part of an effective technological
measure under any applicable law fulfilling obligations under article
11 of the WIPO copyright treaty adopted on 20 December 1996, or
similar laws prohibiting or restricting circumvention of such
measures.

When you convey a covered work, you waive any legal power to forbid
circumvention of technological measures to the extent such
circumvention is effected by exercising rights under this License with
respect to the covered work, and you disclaim any intention to limit
operation or modification of the work as a means of enforcing, against
the work's users, your or third parties' legal rights to forbid
circumvention of technological measures.

<LI>Conveying Verbatim Copies.

You may convey verbatim copies of the Program's source code as you
receive it, in any medium, provided that you conspicuously and
appropriately publish on each copy an appropriate copyright notice;
keep intact all notices stating that this License and any
non-permissive terms added in accord with section 7 apply to the code;
keep intact all notices of the absence of any warranty; and give all
recipients a copy of this License along with the Program.

You may charge any price or no price for each copy that you convey,
and you may offer support or warranty protection for a fee.

<LI>Conveying Modified Source Versions.

You may convey a work based on the Program, or the modifications to
produce it from the Program, in the form of source code under the
terms of section 4, provided that you also meet all of these
conditions:


<OL>
<LI>

The work must carry prominent notices stating that you modified it,
and giving a relevant date.

<LI>

The work must carry prominent notices stating that it is released
under this License and any conditions added under section 7.  This
requirement modifies the requirement in section 4 to “keep intact all
notices”.

<LI>

You must license the entire work, as a whole, under this License to
anyone who comes into possession of a copy.  This License will
therefore apply, along with any applicable section 7 additional terms,
to the whole of the work, and all its parts, regardless of how they
are packaged.  This License gives no permission to license the work in
any other way, but it does not invalidate such permission if you have
separately received it.

<LI>

If the work has interactive user interfaces, each must display
Appropriate Legal Notices; however, if the Program has interactive
interfaces that do not display Appropriate Legal Notices, your work
need not make them do so.
</OL>

A compilation of a covered work with other separate and independent
works, which are not by their nature extensions of the covered work,
and which are not combined with it such as to form a larger program,
in or on a volume of a storage or distribution medium, is called an
“aggregate” if the compilation and its resulting copyright are not
used to limit the access or legal rights of the compilation's users
beyond what the individual works permit.  Inclusion of a covered work
in an aggregate does not cause this License to apply to the other
parts of the aggregate.

<LI>Conveying Non-Source Forms.

You may convey a covered work in object code form under the terms of
sections 4 and 5, provided that you also convey the machine-readable
Corresponding Source under the terms of this License, in one of these
ways:


<OL>
<LI>

Convey the object code in, or embodied in, a physical product
(including a physical distribution medium), accompanied by the
Corresponding Source fixed on a durable physical medium customarily
used for software interchange.

<LI>

Convey the object code in, or embodied in, a physical product
(including a physical distribution medium), accompanied by a written
offer, valid for at least three years and valid for as long as you
offer spare parts or customer support for that product model, to give
anyone who possesses the object code either (1) a copy of the
Corresponding Source for all the software in the product that is
covered by this License, on a durable physical medium customarily used
for software interchange, for a price no more than your reasonable
cost of physically performing this conveying of source, or (2) access
to copy the Corresponding Source from a network server at no charge.

<LI>

Convey individual copies of the object code with a copy of the written
offer to provide the Corresponding Source.  This alternative is
allowed only occasionally and noncommercially, and only if you
received the object code with such an offer, in accord with subsection
6b.

<LI>

Convey the object code by offering access from a designated place
(gratis or for a charge), and offer equivalent access to the
Corresponding Source in the same way through the same place at no
further charge.  You need not require recipients to copy the
Corresponding Source along with the object code.  If the place to copy
the object code is a network server, the Corresponding Source may be
on a different server (operated by you or a third party) that supports
equivalent copying facilities, provided you maintain clear directions
next to the object code saying where to find the Corresponding Source.
Regardless of what server hosts the Corresponding Source, you remain
obligated to ensure that it is available for as long as needed to
satisfy these requirements.

<LI>

Convey the object code using peer-to-peer transmission, provided you
inform other peers where the object code and Corresponding Source of
the work are being offered to the general public at no charge under
subsection 6d.

</OL>

A separable portion of the object code, whose source code is excluded
from the Corresponding Source as a System Library, need not be
included in conveying the object code work.

A “User Product” is either (1) a “consumer product”, which means any
tangible personal property which is normally used for personal,
family, or household purposes, or (2) anything designed or sold for
incorporation into a dwelling.  In determining whether a product is a
consumer product, doubtful cases shall be resolved in favor of
coverage.  For a particular product received by a particular user,
“normally used” refers to a typical or common use of that class of
product, regardless of the status of the particular user or of the way
in which the particular user actually uses, or expects or is expected
to use, the product.  A product is a consumer product regardless of
whether the product has substantial commercial, industrial or
non-consumer uses, unless such uses represent the only significant
mode of use of the product.

“Installation Information” for a User Product means any methods,
procedures, authorization keys, or other information required to
install and execute modified versions of a covered work in that User
Product from a modified version of its Corresponding Source.  The
information must suffice to ensure that the continued functioning of
the modified object code is in no case prevented or interfered with
solely because modification has been made.

If you convey an object code work under this section in, or with, or
specifically for use in, a User Product, and the conveying occurs as
part of a transaction in which the right of possession and use of the
User Product is transferred to the recipient in perpetuity or for a
fixed term (regardless of how the transaction is characterized), the
Corresponding Source conveyed under this section must be accompanied
by the Installation Information.  But this requirement does not apply
if neither you nor any third party retains the ability to install
modified object code on the User Product (for example, the work has
been installed in ROM).

The requirement to provide Installation Information does not include a
requirement to continue to provide support service, warranty, or
updates for a work that has been modified or installed by the
recipient, or for the User Product in which it has been modified or
installed.  Access to a network may be denied when the modification
itself materially and adversely affects the operation of the network
or violates the rules and protocols for communication across the
network.

Corresponding Source conveyed, and Installation Information provided,
in accord with this section must be in a format that is publicly
documented (and with an implementation available to the public in
source code form), and must require no special password or key for
unpacking, reading or copying.

<LI>Additional Terms.

“Additional permissions” are terms that supplement the terms of this
License by making exceptions from one or more of its conditions.
Additional permissions that are applicable to the entire Program shall
be treated as though they were included in this License, to the extent
that they are valid under applicable law.  If additional permissions
apply only to part of the Program, that part may be used separately
under those permissions, but the entire Program remains governed by
this License without regard to the additional permissions.

When you convey a copy of a covered work, you may at your option
remove any additional permissions from that copy, or from any part of
it.  (Additional permissions may be written to require their own
removal in certain cases when you modify the work.)  You may place
additional permissions on material, added by you to a covered work,
for which you have or can give appropriate copyright permission.

Notwithstanding any other provision of this License, for material you
add to a covered work, you may (if authorized by the copyright holders
of that material) supplement the terms of this License with terms:


<OL>
<LI>

Disclaiming warranty or limiting liability differently from the terms
of sections 15 and 16 of this License; or

<LI>

Requiring preservation of specified reasonable legal notices or author
attributions in that material or in the Appropriate Legal Notices
displayed by works containing it; or

<LI>

Prohibiting misrepresentation of the origin of that material, or
requiring that modified versions of such material be marked in
reasonable ways as different from the original version; or

<LI>

Limiting the use for publicity purposes of names of licensors or
authors of the material; or

<LI>

Declining to grant rights under trademark law for use of some trade
names, trademarks, or service marks; or

<LI>

Requiring indemnification of licensors and authors of that material by
anyone who conveys the material (or modified versions of it) with
contractual assumptions of liability to the recipient, for any
liability that these contractual assumptions directly impose on those
licensors and authors.
</OL>

All other non-permissive additional terms are considered “further
restrictions” within the meaning of section 10.  If the Program as you
received it, or any part of it, contains a notice stating that it is
governed by this License along with a term that is a further
restriction, you may remove that term.  If a license document contains
a further restriction but permits relicensing or conveying under this
License, you may add to a covered work material governed by the terms
of that license document, provided that the further restriction does
not survive such relicensing or conveying.

If you add terms to a covered work in accord with this section, you
must place, in the relevant source files, a statement of the
additional terms that apply to those files, or a notice indicating
where to find the applicable terms.

Additional terms, permissive or non-permissive, may be stated in the
form of a separately written license, or stated as exceptions; the
above requirements apply either way.

<LI>Termination.

You may not propagate or modify a covered work except as expressly
provided under this License.  Any attempt otherwise to propagate or
modify it is void, and will automatically terminate your rights under
this License (including any patent licenses granted under the third
paragraph of section 11).

However, if you cease all violation of this License, then your license
from a particular copyright holder is reinstated (a) provisionally,
unless and until the copyright holder explicitly and finally
terminates your license, and (b) permanently, if the copyright holder
fails to notify you of the violation by some reasonable means prior to
60 days after the cessation.

Moreover, your license from a particular copyright holder is
reinstated permanently if the copyright holder notifies you of the
violation by some reasonable means, this is the first time you have
received notice of violation of this License (for any work) from that
copyright holder, and you cure the violation prior to 30 days after
your receipt of the notice.

Termination of your rights under this section does not terminate the
licenses of parties who have received copies or rights from you under
this License.  If your rights have been terminated and not permanently
reinstated, you do not qualify to receive new licenses for the same
material under section 10.

<LI>Acceptance Not Required for Having Copies.

You are not required to accept this License in order to receive or run
a copy of the Program.  Ancillary propagation of a covered work
occurring solely as a consequence of using peer-to-peer transmission
to receive a copy likewise does not require acceptance.  However,
nothing other than this License grants you permission to propagate or
modify any covered work.  These actions infringe copyright if you do
not accept this License.  Therefore, by modifying or propagating a
covered work, you indicate your acceptance of this License to do so.

<LI>Automatic Licensing of Downstream Recipients.

Each time you convey a covered work, the recipient automatically
receives a license from the original licensors, to run, modify and
propagate that work, subject to this License.  You are not responsible
for enforcing compliance by third parties with this License.

An “entity transaction” is a transaction transferring control of an
organization, or substantially all assets of one, or subdividing an
organization, or merging organizations.  If propagation of a covered
work results from an entity transaction, each party to that
transaction who receives a copy of the work also receives whatever
licenses to the work the party's predecessor in interest had or could
give under the previous paragraph, plus a right to possession of the
Corresponding Source of the work from the predecessor in interest, if
the predecessor has it or can get it with reasonable efforts.

You may not impose any further restrictions on the exercise of the
rights granted or affirmed under this License.  For example, you may
not impose a license fee, royalty, or other charge for exercise of
rights granted under this License, and you may not initiate litigation
(including a cross-claim or counterclaim in a lawsuit) alleging that
any patent claim is infringed by making, using, selling, offering for
sale, or importing the Program or any portion of it.

<LI>Patents.

A “contributor” is a copyright holder who authorizes use under this
License of the Program or a work on which the Program is based.  The
work thus licensed is called the contributor's “contributor version”.

A contributor's “essential patent claims” are all patent claims owned
or controlled by the contributor, whether already acquired or
hereafter acquired, that would be infringed by some manner, permitted
by this License, of making, using, or selling its contributor version,
but do not include claims that would be infringed only as a
consequence of further modification of the contributor version.  For
purposes of this definition, “control” includes the right to grant
patent sublicenses in a manner consistent with the requirements of
this License.

Each contributor grants you a non-exclusive, worldwide, royalty-free
patent license under the contributor's essential patent claims, to
make, use, sell, offer for sale, import and otherwise run, modify and
propagate the contents of its contributor version.

In the following three paragraphs, a “patent license” is any express
agreement or commitment, however denominated, not to enforce a patent
(such as an express permission to practice a patent or covenant not to
sue for patent infringement).  To “grant” such a patent license to a
party means to make such an agreement or commitment not to enforce a
patent against the party.

If you convey a covered work, knowingly relying on a patent license,
and the Corresponding Source of the work is not available for anyone
to copy, free of charge and under the terms of this License, through a
publicly available network server or other readily accessible means,
then you must either (1) cause the Corresponding Source to be so
available, or (2) arrange to deprive yourself of the benefit of the
patent license for this particular work, or (3) arrange, in a manner
consistent with the requirements of this License, to extend the patent
license to downstream recipients.  “Knowingly relying” means you have
actual knowledge that, but for the patent license, your conveying the
covered work in a country, or your recipient's use of the covered work
in a country, would infringe one or more identifiable patents in that
country that you have reason to believe are valid.

If, pursuant to or in connection with a single transaction or
arrangement, you convey, or propagate by procuring conveyance of, a
covered work, and grant a patent license to some of the parties
receiving the covered work authorizing them to use, propagate, modify
or convey a specific copy of the covered work, then the patent license
you grant is automatically extended to all recipients of the covered
work and works based on it.

A patent license is “discriminatory” if it does not include within the
scope of its coverage, prohibits the exercise of, or is conditioned on
the non-exercise of one or more of the rights that are specifically
granted under this License.  You may not convey a covered work if you
are a party to an arrangement with a third party that is in the
business of distributing software, under which you make payment to the
third party based on the extent of your activity of conveying the
work, and under which the third party grants, to any of the parties
who would receive the covered work from you, a discriminatory patent
license (a) in connection with copies of the covered work conveyed by
you (or copies made from those copies), or (b) primarily for and in
connection with specific products or compilations that contain the
covered work, unless you entered into that arrangement, or that patent
license was granted, prior to 28 March 2007.

Nothing in this License shall be construed as excluding or limiting
any implied license or other defenses to infringement that may
otherwise be available to you under applicable patent law.

<LI>No Surrender of Others' Freedom.

If conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot convey
a covered work so as to satisfy simultaneously your obligations under
this License and any other pertinent obligations, then as a
consequence you may not convey it at all.  For example, if you agree
to terms that obligate you to collect a royalty for further conveying
from those to whom you convey the Program, the only way you could
satisfy both those terms and this License would be to refrain entirely
from conveying the Program.

<LI>Use with the GNU Affero General Public License.

Notwithstanding any other provision of this License, you have
permission to link or combine any covered work with a work licensed
under version 3 of the GNU Affero General Public License into a single
combined work, and to convey the resulting work.  The terms of this
License will continue to apply to the part which is the covered work,
but the special requirements of the GNU Affero General Public License,
section 13, concerning interaction through a network will apply to the
combination as such.

<LI>Revised Versions of this License.

The Free Software Foundation may publish revised and/or new versions
of the GNU General Public License from time to time.  Such new
versions will be similar in spirit to the present version, but may
differ in detail to address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies that a certain numbered version of the GNU General Public
License “or any later version” applies to it, you have the option of
following the terms and conditions either of that numbered version or
of any later version published by the Free Software Foundation.  If
the Program does not specify a version number of the GNU General
Public License, you may choose any version ever published by the Free
Software Foundation.

If the Program specifies that a proxy can decide which future versions
of the GNU General Public License can be used, that proxy's public
statement of acceptance of a version permanently authorizes you to
choose that version for the Program.

Later license versions may give you additional or different
permissions.  However, no additional obligations are imposed on any
author or copyright holder as a result of your choosing to follow a
later version.

<LI>Disclaimer of Warranty.

THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY
APPLICABLE LAW.  EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT
HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM “AS IS” WITHOUT
WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE.  THE ENTIRE RISK AS TO THE QUALITY AND
PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE PROGRAM PROVE
DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR
CORRECTION.

<LI>Limitation of Liability.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES AND/OR
CONVEYS THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES
ARISING OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT
NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR
LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM
TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH HOLDER OR OTHER
PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

<LI>Interpretation of Sections 15 and 16.

If the disclaimer of warranty and limitation of liability provided
above cannot be given local legal effect according to their terms,
reviewing courts shall apply local law that most closely approximates
an absolute waiver of all civil liability in connection with the
Program, unless a warranty or assumption of liability accompanies a
copy of the Program in return for a fee.

</OL>


<H2>1.2  END OF TERMS AND CONDITIONS</H2>


<H2>1.3  How to Apply These Terms to Your New Programs</H2>

<P>
If you develop a new program, and you want it to be of the greatest
possible use to the public, the best way to achieve this is to make it
free software which everyone can redistribute and change under these
terms.

</P>
<P>
To do so, attach the following notices to the program.  It is safest
to attach them to the start of each source file to most effectively
state the exclusion of warranty; and each file should have at least
the “copyright” line and a pointer to where the full notice is found.

</P>

<PRE>
<VAR>one line to give the program's name and a brief idea of what it does.</VAR>
Copyright (C) <VAR>year</VAR> <VAR>name of author</VAR>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or (at
your option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <A HREF="http://www.gnu.org/licenses/">http://www.gnu.org/licenses/</A>.
</PRE>

<P>
Also add information on how to contact you by electronic and paper mail.

</P>
<P>
If the program does terminal interaction, make it output a short
notice like this when it starts in an interactive mode:

</P>

<PRE>
<VAR>program</VAR> Copyright (C) <VAR>year</VAR> <VAR>name of author</VAR>
This program comes with ABSOLUTELY NO WARRANTY; for details type <SAMP>&lsquo;show w&rsquo;</SAMP>.
This is free software, and you are welcome to redistribute it
under certain conditions; type <SAMP>&lsquo;show c&rsquo;</SAMP> for details.
</PRE>

<P>
The hypothetical commands <SAMP>&lsquo;show w&rsquo;</SAMP> and <SAMP>&lsquo;show c&rsquo;</SAMP> should show
the appropriate parts of the General Public License.  Of course, your
program's commands might be different; for a GUI interface, you would
use an “about box”.

</P>
<P>
You should also get your employer (if you work as a programmer) or school,
if any, to sign a “copyright disclaimer” for the program, if necessary.
For more information on this, and how to apply and follow the GNU GPL, see
<A HREF="http://www.gnu.org/licenses/">http://www.gnu.org/licenses/</A>.

</P>
<P>
The GNU General Public License does not permit incorporating your
program into proprietary programs.  If your program is a subroutine
library, you may consider it more useful to permit linking proprietary
applications with the library.  If this is what you want to do, use
the GNU Lesser General Public License instead of this License.  But
first, please read <A HREF="http://www.gnu.org/philosophy/why-not-lgpl.html">http://www.gnu.org/philosophy/why-not-lgpl.html</A>.

</P>


<H1><A NAME="SEC2" HREF="#TOC2">Contributors to GNU <CODE>gperf</CODE> Utility</A></H1>


<UL>
<LI>

<A NAME="IDX1"></A>
The GNU <CODE>gperf</CODE> perfect hash function generator utility was
written in GNU C++ by Douglas C. Schmidt.  The general
idea for the perfect hash function generator was inspired by Keith
Bostic's algorithm written in C, and distributed to net.sources around
1984.  The current program is a heavily modified, enhanced, and extended
implementation of Keith's basic idea, created at the University of
California, Irvine.  Bugs, patches, and suggestions should be reported
to <CODE>&#60;bug-gperf@gnu.org&#62;</CODE>.

<LI>

Special thanks is extended to Michael Tiemann and Doug Lea, for
providing a useful compiler, and for giving me a forum to exhibit my
creation.

In addition, Adam de Boor and Nels Olson provided many tips and insights
that greatly helped improve the quality and functionality of <CODE>gperf</CODE>.

<LI>

Bruno Haible enhanced and optimized the search algorithm.  He also rewrote
the input routines and the output routines for better reliability, and
added a testsuite.
</UL>



<H1><A NAME="SEC3" HREF="#TOC3">2  Introduction</A></H1>

<P>
<CODE>gperf</CODE> is a perfect hash function generator written in C++.  It
transforms an <VAR>n</VAR> element user-specified keyword set <VAR>W</VAR> into a
perfect hash function <VAR>F</VAR>.  <VAR>F</VAR> uniquely maps keywords in
<VAR>W</VAR> onto the range 0..<VAR>k</VAR>, where <VAR>k</VAR> &#62;= <VAR>n-1</VAR>.  If <VAR>k</VAR>
= <VAR>n-1</VAR> then <VAR>F</VAR> is a <EM>minimal</EM> perfect hash function.
<CODE>gperf</CODE> generates a 0..<VAR>k</VAR> element static lookup table and a
pair of C functions.  These functions determine whether a given
character string <VAR>s</VAR> occurs in <VAR>W</VAR>, using at most one probe into
the lookup table.

</P>
<P>
<CODE>gperf</CODE> currently generates the reserved keyword recognizer for
lexical analyzers in several production and research compilers and
language processing tools, including GNU C, GNU C++, GNU Java, GNU Pascal,
GNU Modula 3, and GNU indent.  Complete C++ source code for <CODE>gperf</CODE> is
available from <CODE>https://ftp.gnu.org/pub/gnu/gperf/</CODE>.
A paper describing <CODE>gperf</CODE>'s design and implementation in greater
detail is available in the Second USENIX C++ Conference proceedings
or from <CODE>http://www.cs.wustl.edu/~schmidt/resume.html</CODE>.

</P>


<H1><A NAME="SEC4" HREF="#TOC4">3  Static search structures and GNU <CODE>gperf</CODE></A></H1>
<P>
<A NAME="IDX2"></A>

</P>
<P>
A <EM>static search structure</EM> is an Abstract Data Type with certain
fundamental operations, e.g., <EM>initialize</EM>, <EM>insert</EM>,
and <EM>retrieve</EM>.  Conceptually, all insertions occur before any
retrievals.  In practice, <CODE>gperf</CODE> generates a <EM>static</EM> array
containing search set keywords and any associated attributes specified
by the user.  Thus, there is essentially no execution-time cost for the
insertions.  It is a useful data structure for representing <EM>static
search sets</EM>.  Static search sets occur frequently in software system
applications.  Typical static search sets include compiler reserved
words, assembler instruction opcodes, and built-in shell interpreter
commands.  Search set members, called <EM>keywords</EM>, are inserted into
the structure only once, usually during program initialization, and are
not generally modified at run-time.

</P>
<P>
Numerous static search structure implementations exist, e.g.,
arrays, linked lists, binary search trees, digital search tries, and
hash tables.  Different approaches offer trade-offs between space
utilization and search time efficiency.  For example, an <VAR>n</VAR> element
sorted array is space efficient, though the average-case time
complexity for retrieval operations using binary search is
proportional to log <VAR>n</VAR>.  Conversely, hash table implementations
often locate a table entry in constant time, but typically impose
additional memory overhead and exhibit poor worst case performance.

</P>
<P>
<A NAME="IDX3"></A>
<EM>Minimal perfect hash functions</EM> provide an optimal solution for a
particular class of static search sets.  A minimal perfect hash
function is defined by two properties:

</P>

<UL>
<LI>

It allows keyword recognition in a static search set using at most
<EM>one</EM> probe into the hash table.  This represents the “perfect”
property.
<LI>

The actual memory allocated to store the keywords is precisely large
enough for the keyword set, and <EM>no larger</EM>.  This is the
“minimal” property.
</UL>

<P>
For most applications it is far easier to generate <EM>perfect</EM> hash
functions than <EM>minimal perfect</EM> hash functions.  Moreover,
non-minimal perfect hash functions frequently execute faster than
minimal ones in practice.  This phenomena occurs since searching a
sparse keyword table increases the probability of locating a “null”
entry, thereby reducing string comparisons.  <CODE>gperf</CODE>'s default
behavior generates <EM>near-minimal</EM> perfect hash functions for
keyword sets.  However, <CODE>gperf</CODE> provides many options that permit
user control over the degree of minimality and perfection.

</P>
<P>
Static search sets often exhibit relative stability over time.  For
example, Ada's 63 reserved words have remained constant for nearly a
decade.  It is therefore frequently worthwhile to expend concerted
effort building an optimal search structure <EM>once</EM>, if it
subsequently receives heavy use multiple times.  <CODE>gperf</CODE> removes
the drudgery associated with constructing time- and space-efficient
search structures by hand.  It has proven a useful and practical tool
for serious programming projects.  Output from <CODE>gperf</CODE> is currently
used in several production and research compilers, including GNU C, GNU
C++, GNU Java, GNU Pascal, and GNU Modula 3.  The latter two compilers are
not yet part of the official GNU distribution.  Each compiler utilizes
<CODE>gperf</CODE> to automatically generate static search structures that
efficiently identify their respective reserved keywords.

</P>


<H1><A NAME="SEC5" HREF="#TOC5">4  High-Level Description of GNU <CODE>gperf</CODE></A></H1>

<P>
The perfect hash function generator <CODE>gperf</CODE> reads a set of
“keywords” from an input file (or from the standard input by
default).  It attempts to derive a perfect hashing function that
recognizes a member of the <EM>static keyword set</EM> with at most a
single probe into the lookup table.  If <CODE>gperf</CODE> succeeds in
generating such a function it produces a pair of C source code routines
that perform hashing and table lookup recognition.  All generated C code
is directed to the standard output.  Command-line options described
below allow you to modify the input and output format to <CODE>gperf</CODE>.

</P>
<P>
By default, <CODE>gperf</CODE> attempts to produce time-efficient code, with
less emphasis on efficient space utilization.  However, several options
exist that permit trading-off execution time for storage space and vice
versa.  In particular, expanding the generated table size produces a
sparse search structure, generally yielding faster searches.
Conversely, you can direct <CODE>gperf</CODE> to utilize a C <CODE>switch</CODE>
statement scheme that minimizes data space storage size.  Furthermore,
using a C <CODE>switch</CODE> may actually speed up the keyword retrieval time
somewhat.  Actual results depend on your C compiler, of course.

</P>
<P>
In general, <CODE>gperf</CODE> assigns values to the bytes it is using
for hashing until some set of values gives each keyword a unique value.
A helpful heuristic is that the larger the hash value range, the easier
it is for <CODE>gperf</CODE> to find and generate a perfect hash function.
Experimentation is the key to getting the most from <CODE>gperf</CODE>.

</P>


<H2><A NAME="SEC6" HREF="#TOC6">4.1  Input Format to <CODE>gperf</CODE></A></H2>
<P>
<A NAME="IDX4"></A>
<A NAME="IDX5"></A>
<A NAME="IDX6"></A>
<A NAME="IDX7"></A>
You can control the input file format by varying certain command-line
arguments, in particular the <SAMP>&lsquo;-t&rsquo;</SAMP> option.  The input's appearance
is similar to GNU utilities <CODE>flex</CODE> and <CODE>bison</CODE> (or UNIX
utilities <CODE>lex</CODE> and <CODE>yacc</CODE>).  Here's an outline of the general
format:

</P>

<PRE>
declarations
%%
keywords
%%
functions
</PRE>

<P>
<EM>Unlike</EM> <CODE>flex</CODE> or <CODE>bison</CODE>, the declarations section and
the functions section are optional.  The following sections describe the
input format for each section.

</P>

<P>
It is possible to omit the declaration section entirely, if the <SAMP>&lsquo;-t&rsquo;</SAMP>
option is not given.  In this case the input file begins directly with the
first keyword line, e.g.:

</P>

<PRE>
january
february
march
april
...
</PRE>



<H3><A NAME="SEC7" HREF="#TOC7">4.1.1  Declarations</A></H3>

<P>
The keyword input file optionally contains a section for including
arbitrary C declarations and definitions, <CODE>gperf</CODE> declarations that
act like command-line options, as well as for providing a user-supplied
<CODE>struct</CODE>.

</P>



<H4><A NAME="SEC8" HREF="#TOC8">4.1.1.1  User-supplied <CODE>struct</CODE></A></H4>

<P>
If the <SAMP>&lsquo;-t&rsquo;</SAMP> option (or, equivalently, the <SAMP>&lsquo;%struct-type&rsquo;</SAMP> declaration)
<EM>is</EM> enabled, you <EM>must</EM> provide a C <CODE>struct</CODE> as the last
component in the declaration section from the input file.  The first
field in this struct must be of type <CODE>char *</CODE> or <CODE>const char *</CODE>
if the <SAMP>&lsquo;-P&rsquo;</SAMP> option is not given, or of type <CODE>int</CODE> if the option
<SAMP>&lsquo;-P&rsquo;</SAMP> (or, equivalently, the <SAMP>&lsquo;%pic&rsquo;</SAMP> declaration) is enabled.
This first field must be called <SAMP>&lsquo;name&rsquo;</SAMP>, although it is possible to modify
its name with the <SAMP>&lsquo;-K&rsquo;</SAMP> option (or, equivalently, the
<SAMP>&lsquo;%define slot-name&rsquo;</SAMP> declaration) described below.

</P>
<P>
Here is a simple example, using months of the year and their attributes as
input:

</P>

<PRE>
struct month { char *name; int number; int days; int leap_days; };
%%
january,   1, 31, 31
february,  2, 28, 29
march,     3, 31, 31
april,     4, 30, 30
may,       5, 31, 31
june,      6, 30, 30
july,      7, 31, 31
august,    8, 31, 31
september, 9, 30, 30
october,  10, 31, 31
november, 11, 30, 30
december, 12, 31, 31
</PRE>

<P>
<A NAME="IDX8"></A>
Separating the <CODE>struct</CODE> declaration from the list of keywords and
other fields are a pair of consecutive percent signs, <SAMP>&lsquo;%%&rsquo;</SAMP>,
appearing left justified in the first column, as in the UNIX utility
<CODE>lex</CODE>.

</P>
<P>
If the <CODE>struct</CODE> has already been declared in an include file, it can
be mentioned in an abbreviated form, like this:

</P>

<PRE>
struct month;
%%
january,   1, 31, 31
...
</PRE>



<H4><A NAME="SEC9" HREF="#TOC9">4.1.1.2  Gperf Declarations</A></H4>

<P>
The declaration section can contain <CODE>gperf</CODE> declarations.  They
influence the way <CODE>gperf</CODE> works, like command line options do.
In fact, every such declaration is equivalent to a command line option.
There are three forms of declarations:

</P>

<OL>
<LI>

Declarations without argument, like <SAMP>&lsquo;%compare-lengths&rsquo;</SAMP>.

<LI>

Declarations with an argument, like <SAMP>&lsquo;%switch=<VAR>count</VAR>&rsquo;</SAMP>.

<LI>

Declarations of names of entities in the output file, like
<SAMP>&lsquo;%define lookup-function-name <VAR>name</VAR>&rsquo;</SAMP>.
</OL>

<P>
When a declaration is given both in the input file and as a command line
option, the command-line option's value prevails.

</P>
<P>
The following <CODE>gperf</CODE> declarations are available.

</P>
<DL COMPACT>

<DT><SAMP>&lsquo;%delimiters=<VAR>delimiter-list</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX9"></A>
Allows you to provide a string containing delimiters used to
separate keywords from their attributes.  The default is ",".  This
option is essential if you want to use keywords that have embedded
commas or newlines.

<DT><SAMP>&lsquo;%struct-type&rsquo;</SAMP>
<DD>
<A NAME="IDX10"></A>
Allows you to include a <CODE>struct</CODE> type declaration for generated
code; see above for an example.

<DT><SAMP>&lsquo;%ignore-case&rsquo;</SAMP>
<DD>
<A NAME="IDX11"></A>
Consider upper and lower case ASCII characters as equivalent.  The string
comparison will use a case insignificant character comparison.  Note that
locale dependent case mappings are ignored.

<DT><SAMP>&lsquo;%language=<VAR>language-name</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX12"></A>
Instructs <CODE>gperf</CODE> to generate code in the language specified by the
option's argument.  Languages handled are currently:

<DL COMPACT>

<DT><SAMP>&lsquo;KR-C&rsquo;</SAMP>
<DD>
Old-style K&#38;R C.  This language is understood by old-style C compilers and
ANSI C compilers, but ANSI C compilers may flag warnings (or even errors)
because of lacking <SAMP>&lsquo;const&rsquo;</SAMP>.

<DT><SAMP>&lsquo;C&rsquo;</SAMP>
<DD>
Common C.  This language is understood by ANSI C compilers, and also by
old-style C compilers, provided that you <CODE>#define const</CODE> to empty
for compilers which don't know about this keyword.

<DT><SAMP>&lsquo;ANSI-C&rsquo;</SAMP>
<DD>
ANSI C.  This language is understood by ANSI C (C89, ISO C90) compilers,
ISO C99 compilers, and C++ compilers.

<DT><SAMP>&lsquo;C++&rsquo;</SAMP>
<DD>
C++.  This language is understood by C++ compilers.
</DL>

The default is ANSI-C.

<DT><SAMP>&lsquo;%define slot-name <VAR>name</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX13"></A>
This declaration is only useful when option <SAMP>&lsquo;-t&rsquo;</SAMP> (or, equivalently, the
<SAMP>&lsquo;%struct-type&rsquo;</SAMP> declaration) has been given.
By default, the program assumes the structure component identifier for
the keyword is <SAMP>&lsquo;name&rsquo;</SAMP>.  This option allows an arbitrary choice of
identifier for this component, although it still must occur as the first
field in your supplied <CODE>struct</CODE>.

<DT><SAMP>&lsquo;%define initializer-suffix <VAR>initializers</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX14"></A>
This declaration is only useful when option <SAMP>&lsquo;-t&rsquo;</SAMP> (or, equivalently, the
<SAMP>&lsquo;%struct-type&rsquo;</SAMP> declaration) has been given.
It permits to specify initializers for the structure members following
<VAR>slot-name</VAR> in empty hash table entries.  The list of initializers
should start with a comma.  By default, the emitted code will
zero-initialize structure members following <VAR>slot-name</VAR>.

<DT><SAMP>&lsquo;%define hash-function-name <VAR>name</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX15"></A>
Allows you to specify the name for the generated hash function.  Default
name is <SAMP>&lsquo;hash&rsquo;</SAMP>.  This option permits the use of two hash tables in
the same file.

<DT><SAMP>&lsquo;%define lookup-function-name <VAR>name</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX16"></A>
Allows you to specify the name for the generated lookup function.
Default name is <SAMP>&lsquo;in_word_set&rsquo;</SAMP>.  This option permits multiple
generated hash functions to be used in the same application.

<DT><SAMP>&lsquo;%define class-name <VAR>name</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX17"></A>
This option is only useful when option <SAMP>&lsquo;-L C++&rsquo;</SAMP> (or, equivalently,
the <SAMP>&lsquo;%language=C++&rsquo;</SAMP> declaration) has been given.  It
allows you to specify the name of generated C++ class.  Default name is
<CODE>Perfect_Hash</CODE>.

<DT><SAMP>&lsquo;%7bit&rsquo;</SAMP>
<DD>
<A NAME="IDX18"></A>
This option specifies that all strings that will be passed as arguments
to the generated hash function and the generated lookup function will
solely consist of 7-bit ASCII characters (bytes in the range 0..127).
(Note that the ANSI C functions <CODE>isalnum</CODE> and <CODE>isgraph</CODE> do
<EM>not</EM> guarantee that a byte is in this range.  Only an explicit
test like <SAMP>&lsquo;c &#62;= 'A' &#38;&#38; c &#60;= 'Z'&rsquo;</SAMP> guarantees this.)

<DT><SAMP>&lsquo;%compare-lengths&rsquo;</SAMP>
<DD>
<A NAME="IDX19"></A>
Compare keyword lengths before trying a string comparison.  This option
is mandatory for binary comparisons (see section <A HREF="#SEC15">4.3  Use of NUL bytes</A>).  It also might
cut down on the number of string comparisons made during the lookup, since
keywords with different lengths are never compared via <CODE>strcmp</CODE>.
However, using <SAMP>&lsquo;%compare-lengths&rsquo;</SAMP> might greatly increase the size of the
generated C code if the lookup table range is large (which implies that
the switch option <SAMP>&lsquo;-S&rsquo;</SAMP> or <SAMP>&lsquo;%switch&rsquo;</SAMP> is not enabled), since the length
table contains as many elements as there are entries in the lookup table.

<DT><SAMP>&lsquo;%compare-strncmp&rsquo;</SAMP>
<DD>
<A NAME="IDX20"></A>
Generates C code that uses the <CODE>strncmp</CODE> function to perform
string comparisons.  The default action is to use <CODE>strcmp</CODE>.

<DT><SAMP>&lsquo;%readonly-tables&rsquo;</SAMP>
<DD>
<A NAME="IDX21"></A>
Makes the contents of all generated lookup tables constant, i.e.,
“readonly”.  Many compilers can generate more efficient code for this
by putting the tables in readonly memory.

<DT><SAMP>&lsquo;%enum&rsquo;</SAMP>
<DD>
<A NAME="IDX22"></A>
Define constant values using an enum local to the lookup function rather
than with #defines.  This also means that different lookup functions can
reside in the same file.  Thanks to James Clark <CODE>&#60;jjc@ai.mit.edu&#62;</CODE>.

<DT><SAMP>&lsquo;%includes&rsquo;</SAMP>
<DD>
<A NAME="IDX23"></A>
Include the necessary system include file, <CODE>&#60;string.h&#62;</CODE>, at the
beginning of the code.  By default, this is not done; the user must
include this header file himself to allow compilation of the code.

<DT><SAMP>&lsquo;%global-table&rsquo;</SAMP>
<DD>
<A NAME="IDX24"></A>
Generate the static table of keywords as a static global variable,
rather than hiding it inside of the lookup function (which is the
default behavior).

<DT><SAMP>&lsquo;%pic&rsquo;</SAMP>
<DD>
<A NAME="IDX25"></A>
Optimize the generated table for inclusion in shared libraries.  This
reduces the startup time of programs using a shared library containing
the generated code.  If the <SAMP>&lsquo;%struct-type&rsquo;</SAMP> declaration (or,
equivalently, the option <SAMP>&lsquo;-t&rsquo;</SAMP>) is also given, the first field of the
user-defined struct must be of type <SAMP>&lsquo;int&rsquo;</SAMP>, not <SAMP>&lsquo;char *&rsquo;</SAMP>, because
it will contain offsets into the string pool instead of actual strings.
To convert such an offset to a string, you can use the expression
<SAMP>&lsquo;stringpool + <VAR>o</VAR>&rsquo;</SAMP>, where <VAR>o</VAR> is the offset.  The string pool
name can be changed through the <SAMP>&lsquo;%define string-pool-name&rsquo;</SAMP> declaration.

<DT><SAMP>&lsquo;%define string-pool-name <VAR>name</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX26"></A>
Allows you to specify the name of the generated string pool created by
the declaration <SAMP>&lsquo;%pic&rsquo;</SAMP> (or, equivalently, the option <SAMP>&lsquo;-P&rsquo;</SAMP>).
The default name is <SAMP>&lsquo;stringpool&rsquo;</SAMP>.  This declaration permits the use of
two hash tables in the same file, with <SAMP>&lsquo;%pic&rsquo;</SAMP> and even when the
<SAMP>&lsquo;%global-table&rsquo;</SAMP> declaration (or, equivalently, the option <SAMP>&lsquo;-G&rsquo;</SAMP>)
is given.

<DT><SAMP>&lsquo;%null-strings&rsquo;</SAMP>
<DD>
<A NAME="IDX27"></A>
Use NULL strings instead of empty strings for empty keyword table entries.
This reduces the startup time of programs using a shared library containing
the generated code (but not as much as the declaration <SAMP>&lsquo;%pic&rsquo;</SAMP>), at the
expense of one more test-and-branch instruction at run time.

<DT><SAMP>&lsquo;%define constants-prefix <VAR>prefix</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX28"></A>
Allows you to specify a prefix for the constants <CODE>TOTAL_KEYWORDS</CODE>,
<CODE>MIN_WORD_LENGTH</CODE>, <CODE>MAX_WORD_LENGTH</CODE>, and so on.  This option
permits the use of two hash tables in the same file, even when the option
<SAMP>&lsquo;-E&rsquo;</SAMP> (or, equivalently, the <SAMP>&lsquo;%enum&rsquo;</SAMP> declaration) is not given or
the option <SAMP>&lsquo;-G&rsquo;</SAMP> (or, equivalently, the <SAMP>&lsquo;%global-table&rsquo;</SAMP> declaration)
is given.

<DT><SAMP>&lsquo;%define word-array-name <VAR>name</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX29"></A>
Allows you to specify the name for the generated array containing the
hash table.  Default name is <SAMP>&lsquo;wordlist&rsquo;</SAMP>.  This option permits the
use of two hash tables in the same file, even when the option <SAMP>&lsquo;-G&rsquo;</SAMP>
(or, equivalently, the <SAMP>&lsquo;%global-table&rsquo;</SAMP> declaration) is given.

<DT><SAMP>&lsquo;%define length-table-name <VAR>name</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX30"></A>
Allows you to specify the name for the generated array containing the
length table.  Default name is <SAMP>&lsquo;lengthtable&rsquo;</SAMP>.  This option permits the
use of two length tables in the same file, even when the option <SAMP>&lsquo;-G&rsquo;</SAMP>
(or, equivalently, the <SAMP>&lsquo;%global-table&rsquo;</SAMP> declaration) is given.

<DT><SAMP>&lsquo;%switch=<VAR>count</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX31"></A>
Causes the generated C code to use a <CODE>switch</CODE> statement scheme,
rather than an array lookup table.  This can lead to a reduction in both
time and space requirements for some input files.  The argument to this
option determines how many <CODE>switch</CODE> statements are generated.  A
value of 1 generates 1 <CODE>switch</CODE> containing all the elements, a
value of 2 generates 2 tables with 1/2 the elements in each
<CODE>switch</CODE>, etc.  This is useful since many C compilers cannot
correctly generate code for large <CODE>switch</CODE> statements.  This option
was inspired in part by Keith Bostic's original C program.

<DT><SAMP>&lsquo;%omit-struct-type&rsquo;</SAMP>
<DD>
<A NAME="IDX32"></A>
Prevents the transfer of the type declaration to the output file.  Use
this option if the type is already defined elsewhere.
</DL>



<H4><A NAME="SEC10" HREF="#TOC10">4.1.1.3  C Code Inclusion</A></H4>

<P>
<A NAME="IDX33"></A>
<A NAME="IDX34"></A>
Using a syntax similar to GNU utilities <CODE>flex</CODE> and <CODE>bison</CODE>, it
is possible to directly include C source text and comments verbatim into
the generated output file.  This is accomplished by enclosing the region
inside left-justified surrounding <SAMP>&lsquo;%{&rsquo;</SAMP>, <SAMP>&lsquo;%}&rsquo;</SAMP> pairs.  Here is
an input fragment based on the previous example that illustrates this
feature:

</P>

<PRE>
%{
#include &#60;assert.h&#62;
/* This section of code is inserted directly into the output. */
int return_month_days (struct month *months, int is_leap_year);
%}
struct month { char *name; int number; int days; int leap_days; };
%%
january,   1, 31, 31
february,  2, 28, 29
march,     3, 31, 31
...
</PRE>



<H3><A NAME="SEC11" HREF="#TOC11">4.1.2  Format for Keyword Entries</A></H3>

<P>
The second input file format section contains lines of keywords and any
associated attributes you might supply.  A line beginning with <SAMP>&lsquo;#&rsquo;</SAMP>
in the first column is considered a comment.  Everything following the
<SAMP>&lsquo;#&rsquo;</SAMP> is ignored, up to and including the following newline.  A line
beginning with <SAMP>&lsquo;%&rsquo;</SAMP> in the first column is an option declaration and
must not occur within the keywords section.

</P>
<P>
The first field of each non-comment line is always the keyword itself.  It
can be given in two ways: as a simple name, i.e., without surrounding
string quotation marks, or as a string enclosed in double-quotes, in
C syntax, possibly with backslash escapes like <CODE>\"</CODE> or <CODE>\234</CODE>
or <CODE>\xa8</CODE>.  In either case, it must start right at the beginning
of the line, without leading whitespace.
In this context, a “field” is considered to extend up to, but
not include, the first blank, comma, or newline.  Here is a simple
example taken from a partial list of C reserved words:

</P>

<PRE>
# These are a few C reserved words, see the c.gperf file 
# for a complete list of ANSI C reserved words.
unsigned
sizeof
switch
signed
if
default
for
while
return
</PRE>

<P>
Note that unlike <CODE>flex</CODE> or <CODE>bison</CODE> the first <SAMP>&lsquo;%%&rsquo;</SAMP> marker
may be elided if the declaration section is empty.

</P>
<P>
Additional fields may optionally follow the leading keyword.  Fields
should be separated by commas, and terminate at the end of line.  What
these fields mean is entirely up to you; they are used to initialize the
elements of the user-defined <CODE>struct</CODE> provided by you in the
declaration section.  If the <SAMP>&lsquo;-t&rsquo;</SAMP> option (or, equivalently, the
<SAMP>&lsquo;%struct-type&rsquo;</SAMP> declaration) is <EM>not</EM> enabled
these fields are simply ignored.  All previous examples except the last
one contain keyword attributes.

</P>


<H3><A NAME="SEC12" HREF="#TOC12">4.1.3  Including Additional C Functions</A></H3>

<P>
The optional third section also corresponds closely with conventions
found in <CODE>flex</CODE> and <CODE>bison</CODE>.  All text in this section,
starting at the final <SAMP>&lsquo;%%&rsquo;</SAMP> and extending to the end of the input
file, is included verbatim into the generated output file.  Naturally,
it is your responsibility to ensure that the code contained in this
section is valid C.

</P>


<H3><A NAME="SEC13" HREF="#TOC13">4.1.4  Where to place directives for GNU <CODE>indent</CODE>.</A></H3>

<P>
If you want to invoke GNU <CODE>indent</CODE> on a <CODE>gperf</CODE> input file,
you will see that GNU <CODE>indent</CODE> doesn't understand the <SAMP>&lsquo;%%&rsquo;</SAMP>,
<SAMP>&lsquo;%{&rsquo;</SAMP> and <SAMP>&lsquo;%}&rsquo;</SAMP> directives that control <CODE>gperf</CODE>'s
interpretation of the input file.  Therefore you have to insert some
directives for GNU <CODE>indent</CODE>.  More precisely, assuming the most
general input file structure

</P>

<PRE>
declarations part 1
%{
verbatim code
%}
declarations part 2
%%
keywords
%%
functions
</PRE>

<P>
you would insert <SAMP>&lsquo;*INDENT-OFF*&rsquo;</SAMP> and <SAMP>&lsquo;*INDENT-ON*&rsquo;</SAMP> comments
as follows:

</P>

<PRE>
/* *INDENT-OFF* */
declarations part 1
%{
/* *INDENT-ON* */
verbatim code
/* *INDENT-OFF* */
%}
declarations part 2
%%
keywords
%%
/* *INDENT-ON* */
functions
</PRE>



<H2><A NAME="SEC14" HREF="#TOC14">4.2  Output Format for Generated C Code with <CODE>gperf</CODE></A></H2>
<P>
<A NAME="IDX35"></A>

</P>
<P>
Several options control how the generated C code appears on the standard 
output.  Two C functions are generated.  They are called <CODE>hash</CODE> and 
<CODE>in_word_set</CODE>, although you may modify their names with a command-line 
option.  Both functions require two arguments, a string, <CODE>char *</CODE> 
<VAR>str</VAR>, and a length parameter, <CODE>int</CODE> <VAR>len</VAR>.  Their default 
function prototypes are as follows:

</P>
<P>
<DL>
<DT><U>Function:</U> unsigned int <B>hash</B> <I>(const char * <VAR>str</VAR>, size_t <VAR>len</VAR>)</I>
<DD><A NAME="IDX36"></A>
By default, the generated <CODE>hash</CODE> function returns an integer value
created by adding <VAR>len</VAR> to several user-specified <VAR>str</VAR> byte
positions indexed into an <EM>associated values</EM> table stored in a
local static array.  The associated values table is constructed
internally by <CODE>gperf</CODE> and later output as a static local C array
called <SAMP>&lsquo;hash_table&rsquo;</SAMP>.  The relevant selected positions (i.e. indices
into <VAR>str</VAR>) are specified via the <SAMP>&lsquo;-k&rsquo;</SAMP> option when running
<CODE>gperf</CODE>, as detailed in the <EM>Options</EM> section below (see section <A HREF="#SEC18">5  Invoking <CODE>gperf</CODE></A>).
</DL>

</P>
<P>
<DL>
<DT><U>Function:</U>  <B>in_word_set</B> <I>(const char * <VAR>str</VAR>, size_t <VAR>len</VAR>)</I>
<DD><A NAME="IDX37"></A>
If <VAR>str</VAR> is in the keyword set, returns a pointer to that
keyword.  More exactly, if the option <SAMP>&lsquo;-t&rsquo;</SAMP> (or, equivalently, the
<SAMP>&lsquo;%struct-type&rsquo;</SAMP> declaration) was given, it returns
a pointer to the matching keyword's structure.  Otherwise it returns
<CODE>NULL</CODE>.
</DL>

</P>
<P>
If the option <SAMP>&lsquo;-c&rsquo;</SAMP> (or, equivalently, the <SAMP>&lsquo;%compare-strncmp&rsquo;</SAMP>
declaration) is not used, <VAR>str</VAR> must be a NUL terminated
string of exactly length <VAR>len</VAR>.  If <SAMP>&lsquo;-c&rsquo;</SAMP> (or, equivalently, the
<SAMP>&lsquo;%compare-strncmp&rsquo;</SAMP> declaration) is used, <VAR>str</VAR> must
simply be an array of <VAR>len</VAR> bytes and does not need to be NUL
terminated.

</P>
<P>
The code generated for these two functions is affected by the following
options:

</P>
<DL COMPACT>

<DT><SAMP>&lsquo;-t&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--struct-type&rsquo;</SAMP>
<DD>
Make use of the user-defined <CODE>struct</CODE>.

<DT><SAMP>&lsquo;-S <VAR>total-switch-statements</VAR>&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--switch=<VAR>total-switch-statements</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX38"></A>
Generate 1 or more C <CODE>switch</CODE> statement rather than use a large,
(and potentially sparse) static array.  Although the exact time and
space savings of this approach vary according to your C compiler's
degree of optimization, this method often results in smaller and faster
code.
</DL>

<P>
If the <SAMP>&lsquo;-t&rsquo;</SAMP> and <SAMP>&lsquo;-S&rsquo;</SAMP> options (or, equivalently, the
<SAMP>&lsquo;%struct-type&rsquo;</SAMP> and <SAMP>&lsquo;%switch&rsquo;</SAMP> declarations) are omitted, the default
action
is to generate a <CODE>char *</CODE> array containing the keywords, together with
additional empty strings used for padding the array.  By experimenting
with the various input and output options, and timing the resulting C
code, you can determine the best option choices for different keyword
set characteristics.

</P>


<H2><A NAME="SEC15" HREF="#TOC15">4.3  Use of NUL bytes</A></H2>
<P>
<A NAME="IDX39"></A>

</P>
<P>
By default, the code generated by <CODE>gperf</CODE> operates on zero
terminated strings, the usual representation of strings in C.  This means
that the keywords in the input file must not contain NUL bytes,
and the <VAR>str</VAR> argument passed to <CODE>hash</CODE> or <CODE>in_word_set</CODE>
must be NUL terminated and have exactly length <VAR>len</VAR>.

</P>
<P>
If option <SAMP>&lsquo;-c&rsquo;</SAMP> (or, equivalently, the <SAMP>&lsquo;%compare-strncmp&rsquo;</SAMP>
declaration) is used, then the <VAR>str</VAR> argument does not need
to be NUL terminated.  The code generated by <CODE>gperf</CODE> will only
access the first <VAR>len</VAR>, not <VAR>len+1</VAR>, bytes starting at <VAR>str</VAR>.
However, the keywords in the input file still must not contain NUL
bytes.

</P>
<P>
If option <SAMP>&lsquo;-l&rsquo;</SAMP> (or, equivalently, the <SAMP>&lsquo;%compare-lengths&rsquo;</SAMP>
declaration) is used, then the hash table performs binary
comparison.  The keywords in the input file may contain NUL bytes,
written in string syntax as <CODE>\000</CODE> or <CODE>\x00</CODE>, and the code
generated by <CODE>gperf</CODE> will treat NUL like any other byte.
Also, in this case the <SAMP>&lsquo;-c&rsquo;</SAMP> option (or, equivalently, the
<SAMP>&lsquo;%compare-strncmp&rsquo;</SAMP> declaration) is ignored.

</P>


<H2><A NAME="SEC16" HREF="#TOC16">4.4  Controlling Identifiers</A></H2>

<P>
The identifiers of the functions, tables, and constants defined by the code
generated by <CODE>gperf</CODE> can be controlled through <CODE>gperf</CODE> declarations
or the equivalent command-line options.  This is useful for three purposes:

</P>

<UL>
<LI>

Esthetics of the generated code.

For this purpose, just use the available declarations or options at will.

<LI>

Controlling the exported identifiers of a library.

Assume you include code generated by <CODE>gperf</CODE> in a library, and to
avoid collisions with other libraries, you want to ensure that all exported
identifiers of this library start with a certain prefix.

By default, the only exported identifier is the lookup function.  You can
therefore use the option <SAMP>&lsquo;-N&rsquo;</SAMP> (or, equivalently, the
<SAMP>&lsquo;%define lookup-function-name&rsquo;</SAMP> declaration).

When you use the option <SAMP>&lsquo;-L C++&rsquo;</SAMP> (or, equivalently, the
<SAMP>&lsquo;%language=C++&rsquo;</SAMP> declaration), the only exported entity is a class.
You control its name through the option <SAMP>&lsquo;-Z&rsquo;</SAMP> (or, equivalently, the
<SAMP>&lsquo;%define class-name&rsquo;</SAMP> declaration).

<LI>

Allowing multiple <CODE>gperf</CODE> generated codes in a single compilation unit.

Assume you invoke <CODE>gperf</CODE> multiple times, with different input files,
and want the generated code to be included from the same source file.  In this
case, you have to customize not only the exported identifiers, but also the
names of functions with <SAMP>&lsquo;static&rsquo;</SAMP> scope, types, and constants.

By default, you will have to deal with the lookup function, the hash
function, and the constants.  You should therefore use the option <SAMP>&lsquo;-N&rsquo;</SAMP>
(or, equivalently, the <SAMP>&lsquo;%define lookup-function-name&rsquo;</SAMP> declaration),
the option <SAMP>&lsquo;-H&rsquo;</SAMP> (or, equivalently, the
<SAMP>&lsquo;%define hash-function-name&rsquo;</SAMP> declaration), and the option
<SAMP>&lsquo;--constants-prefix&rsquo;</SAMP> (or, equivalently, the
<SAMP>&lsquo;%define constants-prefix&rsquo;</SAMP> declaration).

If you use the option <SAMP>&lsquo;-G&rsquo;</SAMP> (or, equivalently, the <SAMP>&lsquo;%global-table&rsquo;</SAMP>
declaration), you will also have to deal with the word array, the length
table if present, and the string pool if present.  This means: You should
use the option <SAMP>&lsquo;-W&rsquo;</SAMP> (or, equivalently, the
<SAMP>&lsquo;%define word-array-name&rsquo;</SAMP> declaration).  If you use the option
<SAMP>&lsquo;-l&rsquo;</SAMP> (or, equivalently, the <SAMP>&lsquo;%compare-lengths&rsquo;</SAMP> declaration), you
should use the option <SAMP>&lsquo;--length-table-name&rsquo;</SAMP> (or, equivalently, the
<SAMP>&lsquo;%define length-table-name&rsquo;</SAMP> declaration). If you use the option
<SAMP>&lsquo;-P&rsquo;</SAMP> (or, equivalently, the <SAMP>&lsquo;%pic&rsquo;</SAMP> declaration), you should use
the option <SAMP>&lsquo;-Q&rsquo;</SAMP> (or, equivalently, the <SAMP>&lsquo;%define string-pool-name&rsquo;</SAMP>
declaration).
</UL>



<H2><A NAME="SEC17" HREF="#TOC17">4.5  The Copyright of the Output</A></H2>
<P>
<A NAME="IDX40"></A>

</P>
<P>
<CODE>gperf</CODE> is under GPL, but that does not cause the output produced
by <CODE>gperf</CODE> to be under GPL.  The reason is that the output contains
only small pieces of text that come directly from <CODE>gperf</CODE>'s source
code -- only about 7 lines long, too small for being significant --, and
therefore the output is not a “work based on <CODE>gperf</CODE>” (in the
sense of the GPL version 3).

</P>
<P>
On the other hand, the output produced by <CODE>gperf</CODE> contains
essentially all of the input file.  Therefore the output is a
“derivative work” of the input (in the sense of U.S. copyright law);
and its copyright status depends on the copyright of the input.  For most
software licenses, the result is that the output is under the same
license, with the same copyright holder, as the input that was passed to
<CODE>gperf</CODE>.

</P>


<H1><A NAME="SEC18" HREF="#TOC18">5  Invoking <CODE>gperf</CODE></A></H1>

<P>
There are <EM>many</EM> options to <CODE>gperf</CODE>.  They were added to make
the program more convenient for use with real applications.  “On-line”
help is readily available via the <SAMP>&lsquo;--help&rsquo;</SAMP> option.  Here is the
complete list of options.

</P>



<H2><A NAME="SEC19" HREF="#TOC19">5.1  Specifying the Location of the Output File</A></H2>

<DL COMPACT>

<DT><SAMP>&lsquo;--output-file=<VAR>file</VAR>&rsquo;</SAMP>
<DD>
Allows you to specify the name of the file to which the output is written to.
</DL>

<P>
The results are written to standard output if no output file is specified
or if it is <SAMP>&lsquo;-&rsquo;</SAMP>.

</P>


<H2><A NAME="SEC20" HREF="#TOC20">5.2  Options that affect Interpretation of the Input File</A></H2>

<P>
These options are also available as declarations in the input file
(see section <A HREF="#SEC9">4.1.1.2  Gperf Declarations</A>).

</P>
<DL COMPACT>

<DT><SAMP>&lsquo;-e <VAR>keyword-delimiter-list</VAR>&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--delimiters=<VAR>keyword-delimiter-list</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX41"></A>
Allows you to provide a string containing delimiters used to
separate keywords from their attributes.  The default is ",".  This
option is essential if you want to use keywords that have embedded
commas or newlines.  One useful trick is to use -e'TAB', where TAB is
the literal tab character.

<DT><SAMP>&lsquo;-t&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--struct-type&rsquo;</SAMP>
<DD>
Allows you to include a <CODE>struct</CODE> type declaration for generated
code.  Any text before a pair of consecutive <SAMP>&lsquo;%%&rsquo;</SAMP> is considered
part of the type declaration.  Keywords and additional fields may follow
this, one group of fields per line.  A set of examples for generating
perfect hash tables and functions for Ada, C, C++, Pascal, Modula 2,
Modula 3 and JavaScript reserved words are distributed with this release.

<DT><SAMP>&lsquo;--ignore-case&rsquo;</SAMP>
<DD>
Consider upper and lower case ASCII characters as equivalent.  The string
comparison will use a case insignificant character comparison.  Note that
locale dependent case mappings are ignored.  This option is therefore not
suitable if a properly internationalized or locale aware case mapping
should be used.  (For example, in a Turkish locale, the upper case equivalent
of the lowercase ASCII letter <SAMP>&lsquo;i&rsquo;</SAMP> is the non-ASCII character
<SAMP>&lsquo;capital i with dot above&rsquo;</SAMP>.)  For this case, it is better to apply
an uppercase or lowercase conversion on the string before passing it to
the <CODE>gperf</CODE> generated function.
</DL>



<H2><A NAME="SEC21" HREF="#TOC21">5.3  Options to specify the Language for the Output Code</A></H2>

<P>
These options are also available as declarations in the input file
(see section <A HREF="#SEC9">4.1.1.2  Gperf Declarations</A>).

</P>
<DL COMPACT>

<DT><SAMP>&lsquo;-L <VAR>generated-language-name</VAR>&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--language=<VAR>generated-language-name</VAR>&rsquo;</SAMP>
<DD>
Instructs <CODE>gperf</CODE> to generate code in the language specified by the
option's argument.  Languages handled are currently:

<DL COMPACT>

<DT><SAMP>&lsquo;KR-C&rsquo;</SAMP>
<DD>
Old-style K&#38;R C.  This language is understood by old-style C compilers and
ANSI C compilers, but ANSI C compilers may flag warnings (or even errors)
because of lacking <SAMP>&lsquo;const&rsquo;</SAMP>.

<DT><SAMP>&lsquo;C&rsquo;</SAMP>
<DD>
Common C.  This language is understood by ANSI C compilers, and also by
old-style C compilers, provided that you <CODE>#define const</CODE> to empty
for compilers which don't know about this keyword.

<DT><SAMP>&lsquo;ANSI-C&rsquo;</SAMP>
<DD>
ANSI C.  This language is understood by ANSI C compilers and C++ compilers.

<DT><SAMP>&lsquo;C++&rsquo;</SAMP>
<DD>
C++.  This language is understood by C++ compilers.
</DL>

The default is ANSI-C.

<DT><SAMP>&lsquo;-a&rsquo;</SAMP>
<DD>
This option is supported for compatibility with previous releases of
<CODE>gperf</CODE>.  It does not do anything.

<DT><SAMP>&lsquo;-g&rsquo;</SAMP>
<DD>
This option is supported for compatibility with previous releases of
<CODE>gperf</CODE>.  It does not do anything.
</DL>



<H2><A NAME="SEC22" HREF="#TOC22">5.4  Options for fine tuning Details in the Output Code</A></H2>

<P>
Most of these options are also available as declarations in the input file
(see section <A HREF="#SEC9">4.1.1.2  Gperf Declarations</A>).

</P>
<DL COMPACT>

<DT><SAMP>&lsquo;-K <VAR>slot-name</VAR>&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--slot-name=<VAR>slot-name</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX42"></A>
This option is only useful when option <SAMP>&lsquo;-t&rsquo;</SAMP> (or, equivalently, the
<SAMP>&lsquo;%struct-type&rsquo;</SAMP> declaration) has been given.
By default, the program assumes the structure component identifier for
the keyword is <SAMP>&lsquo;name&rsquo;</SAMP>.  This option allows an arbitrary choice of
identifier for this component, although it still must occur as the first
field in your supplied <CODE>struct</CODE>.

<DT><SAMP>&lsquo;-F <VAR>initializers</VAR>&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--initializer-suffix=<VAR>initializers</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX43"></A>
This option is only useful when option <SAMP>&lsquo;-t&rsquo;</SAMP> (or, equivalently, the
<SAMP>&lsquo;%struct-type&rsquo;</SAMP> declaration) has been given.
It permits to specify initializers for the structure members following
<VAR>slot-name</VAR> in empty hash table entries.  The list of initializers
should start with a comma.  By default, the emitted code will
zero-initialize structure members following <VAR>slot-name</VAR>.

<DT><SAMP>&lsquo;-H <VAR>hash-function-name</VAR>&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--hash-function-name=<VAR>hash-function-name</VAR>&rsquo;</SAMP>
<DD>
Allows you to specify the name for the generated hash function.  Default
name is <SAMP>&lsquo;hash&rsquo;</SAMP>.  This option permits the use of two hash tables in
the same file.

<DT><SAMP>&lsquo;-N <VAR>lookup-function-name</VAR>&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--lookup-function-name=<VAR>lookup-function-name</VAR>&rsquo;</SAMP>
<DD>
Allows you to specify the name for the generated lookup function.
Default name is <SAMP>&lsquo;in_word_set&rsquo;</SAMP>.  This option permits multiple
generated hash functions to be used in the same application.

<DT><SAMP>&lsquo;-Z <VAR>class-name</VAR>&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--class-name=<VAR>class-name</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX44"></A>
This option is only useful when option <SAMP>&lsquo;-L C++&rsquo;</SAMP> (or, equivalently,
the <SAMP>&lsquo;%language=C++&rsquo;</SAMP> declaration) has been given.  It
allows you to specify the name of generated C++ class.  Default name is
<CODE>Perfect_Hash</CODE>.

<DT><SAMP>&lsquo;-7&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--seven-bit&rsquo;</SAMP>
<DD>
This option specifies that all strings that will be passed as arguments
to the generated hash function and the generated lookup function will
solely consist of 7-bit ASCII characters (bytes in the range 0..127).
(Note that the ANSI C functions <CODE>isalnum</CODE> and <CODE>isgraph</CODE> do
<EM>not</EM> guarantee that a byte is in this range.  Only an explicit
test like <SAMP>&lsquo;c &#62;= 'A' &#38;&#38; c &#60;= 'Z'&rsquo;</SAMP> guarantees this.) This was the
default in versions of <CODE>gperf</CODE> earlier than 2.7; now the default is
to support 8-bit and multibyte characters.

<DT><SAMP>&lsquo;-l&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--compare-lengths&rsquo;</SAMP>
<DD>
Compare keyword lengths before trying a string comparison.  This option
is mandatory for binary comparisons (see section <A HREF="#SEC15">4.3  Use of NUL bytes</A>).  It also might
cut down on the number of string comparisons made during the lookup, since
keywords with different lengths are never compared via <CODE>strcmp</CODE>.
However, using <SAMP>&lsquo;-l&rsquo;</SAMP> might greatly increase the size of the
generated C code if the lookup table range is large (which implies that
the switch option <SAMP>&lsquo;-S&rsquo;</SAMP> or <SAMP>&lsquo;%switch&rsquo;</SAMP> is not enabled), since the length
table contains as many elements as there are entries in the lookup table.

<DT><SAMP>&lsquo;-c&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--compare-strncmp&rsquo;</SAMP>
<DD>
Generates C code that uses the <CODE>strncmp</CODE> function to perform
string comparisons.  The default action is to use <CODE>strcmp</CODE>.

<DT><SAMP>&lsquo;-C&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--readonly-tables&rsquo;</SAMP>
<DD>
Makes the contents of all generated lookup tables constant, i.e.,
“readonly”.  Many compilers can generate more efficient code for this
by putting the tables in readonly memory.

<DT><SAMP>&lsquo;-E&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--enum&rsquo;</SAMP>
<DD>
<A NAME="IDX45"></A>
Define constant values using an enum local to the lookup function rather
than with #defines.  This also means that different lookup functions can
reside in the same file.  Thanks to James Clark <CODE>&#60;jjc@ai.mit.edu&#62;</CODE>.

<DT><SAMP>&lsquo;-I&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--includes&rsquo;</SAMP>
<DD>
Include the necessary system include file, <CODE>&#60;string.h&#62;</CODE>, at the
beginning of the code.  By default, this is not done; the user must
include this header file himself to allow compilation of the code.

<DT><SAMP>&lsquo;-G&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--global-table&rsquo;</SAMP>
<DD>
Generate the static table of keywords as a static global variable,
rather than hiding it inside of the lookup function (which is the
default behavior).

<DT><SAMP>&lsquo;-P&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--pic&rsquo;</SAMP>
<DD>
Optimize the generated table for inclusion in shared libraries.  This
reduces the startup time of programs using a shared library containing
the generated code.  If the option <SAMP>&lsquo;-t&rsquo;</SAMP> (or, equivalently, the
<SAMP>&lsquo;%struct-type&rsquo;</SAMP> declaration) is also given, the first field of the
user-defined struct must be of type <SAMP>&lsquo;int&rsquo;</SAMP>, not <SAMP>&lsquo;char *&rsquo;</SAMP>, because
it will contain offsets into the string pool instead of actual strings.
To convert such an offset to a string, you can use the expression
<SAMP>&lsquo;stringpool + <VAR>o</VAR>&rsquo;</SAMP>, where <VAR>o</VAR> is the offset.  The string pool
name can be changed through the option <SAMP>&lsquo;--string-pool-name&rsquo;</SAMP>.

<DT><SAMP>&lsquo;-Q <VAR>string-pool-name</VAR>&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--string-pool-name=<VAR>string-pool-name</VAR>&rsquo;</SAMP>
<DD>
Allows you to specify the name of the generated string pool created by
option <SAMP>&lsquo;-P&rsquo;</SAMP>.  The default name is <SAMP>&lsquo;stringpool&rsquo;</SAMP>.  This option
permits the use of two hash tables in the same file, with <SAMP>&lsquo;-P&rsquo;</SAMP> and
even when the option <SAMP>&lsquo;-G&rsquo;</SAMP> (or, equivalently, the <SAMP>&lsquo;%global-table&rsquo;</SAMP>
declaration) is given.

<DT><SAMP>&lsquo;--null-strings&rsquo;</SAMP>
<DD>
Use NULL strings instead of empty strings for empty keyword table entries.
This reduces the startup time of programs using a shared library containing
the generated code (but not as much as option <SAMP>&lsquo;-P&rsquo;</SAMP>), at the expense
of one more test-and-branch instruction at run time.

<DT><SAMP>&lsquo;--constants-prefix=<VAR>prefix</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX46"></A>
Allows you to specify a prefix for the constants <CODE>TOTAL_KEYWORDS</CODE>,
<CODE>MIN_WORD_LENGTH</CODE>, <CODE>MAX_WORD_LENGTH</CODE>, and so on.  This option
permits the use of two hash tables in the same file, even when the option
<SAMP>&lsquo;-E&rsquo;</SAMP> (or, equivalently, the <SAMP>&lsquo;%enum&rsquo;</SAMP> declaration) is not given or
the option <SAMP>&lsquo;-G&rsquo;</SAMP> (or, equivalently, the <SAMP>&lsquo;%global-table&rsquo;</SAMP> declaration)
is given.

<DT><SAMP>&lsquo;-W <VAR>hash-table-array-name</VAR>&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--word-array-name=<VAR>hash-table-array-name</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX47"></A>
Allows you to specify the name for the generated array containing the
hash table.  Default name is <SAMP>&lsquo;wordlist&rsquo;</SAMP>.  This option permits the
use of two hash tables in the same file, even when the option <SAMP>&lsquo;-G&rsquo;</SAMP>
(or, equivalently, the <SAMP>&lsquo;%global-table&rsquo;</SAMP> declaration) is given.

<DT><SAMP>&lsquo;--length-table-name=<VAR>length-table-array-name</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX48"></A>
Allows you to specify the name for the generated array containing the
length table.  Default name is <SAMP>&lsquo;lengthtable&rsquo;</SAMP>.  This option permits the
use of two length tables in the same file, even when the option <SAMP>&lsquo;-G&rsquo;</SAMP>
(or, equivalently, the <SAMP>&lsquo;%global-table&rsquo;</SAMP> declaration) is given.

<DT><SAMP>&lsquo;-S <VAR>total-switch-statements</VAR>&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--switch=<VAR>total-switch-statements</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX49"></A>
Causes the generated C code to use a <CODE>switch</CODE> statement scheme,
rather than an array lookup table.  This can lead to a reduction in both
time and space requirements for some input files.  The argument to this
option determines how many <CODE>switch</CODE> statements are generated.  A
value of 1 generates 1 <CODE>switch</CODE> containing all the elements, a
value of 2 generates 2 tables with 1/2 the elements in each
<CODE>switch</CODE>, etc.  This is useful since many C compilers cannot
correctly generate code for large <CODE>switch</CODE> statements.  This option
was inspired in part by Keith Bostic's original C program.

<DT><SAMP>&lsquo;-T&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--omit-struct-type&rsquo;</SAMP>
<DD>
Prevents the transfer of the type declaration to the output file.  Use
this option if the type is already defined elsewhere.

<DT><SAMP>&lsquo;-p&rsquo;</SAMP>
<DD>
This option is supported for compatibility with previous releases of
<CODE>gperf</CODE>.  It does not do anything.
</DL>



<H2><A NAME="SEC23" HREF="#TOC23">5.5  Options for changing the Algorithms employed by <CODE>gperf</CODE></A></H2>

<DL COMPACT>

<DT><SAMP>&lsquo;-k <VAR>selected-byte-positions</VAR>&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--key-positions=<VAR>selected-byte-positions</VAR>&rsquo;</SAMP>
<DD>
Allows selection of the byte positions used in the keywords'
hash function.  The allowable choices range between 1-255, inclusive.
The positions are separated by commas, e.g., <SAMP>&lsquo;-k 9,4,13,14&rsquo;</SAMP>;
ranges may be used, e.g., <SAMP>&lsquo;-k 2-7&rsquo;</SAMP>; and positions may occur
in any order.  Furthermore, the wildcard '*' causes the generated
hash function to consider <STRONG>all</STRONG> byte positions in each keyword,
whereas '$' instructs the hash function to use the “final byte”
of a keyword (this is the only way to use a byte position greater than
255, incidentally).

For instance, the option <SAMP>&lsquo;-k 1,2,4,6-10,'$'&rsquo;</SAMP> generates a hash
function that considers positions 1,2,4,6,7,8,9,10, plus the last
byte in each keyword (which may be at a different position for each
keyword, obviously).  Keywords
with length less than the indicated byte positions work properly, since
selected byte positions exceeding the keyword length are simply not
referenced in the hash function.

This option is not normally needed since version 2.8 of <CODE>gperf</CODE>;
the default byte positions are computed depending on the keyword set,
through a search that minimizes the number of byte positions.

<DT><SAMP>&lsquo;-D&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--duplicates&rsquo;</SAMP>
<DD>
<A NAME="IDX50"></A>
Handle keywords whose selected byte sets hash to duplicate values.
Duplicate hash values can occur if a set of keywords has the same names, but
possesses different attributes, or if the selected byte positions are not well
chosen.  With the -D option <CODE>gperf</CODE> treats all these keywords as
part of an equivalence class and generates a perfect hash function with
multiple comparisons for duplicate keywords.  It is up to you to completely
disambiguate the keywords by modifying the generated C code.  However,
<CODE>gperf</CODE> helps you out by organizing the output.

Using this option usually means that the generated hash function is no
longer perfect.  On the other hand, it permits <CODE>gperf</CODE> to work on
keyword sets that it otherwise could not handle.

<DT><SAMP>&lsquo;-m <VAR>iterations</VAR>&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--multiple-iterations=<VAR>iterations</VAR>&rsquo;</SAMP>
<DD>
Perform multiple choices of the <SAMP>&lsquo;-i&rsquo;</SAMP> and <SAMP>&lsquo;-j&rsquo;</SAMP> values, and
choose the best results.  This increases the running time by a factor of
<VAR>iterations</VAR> but does a good job minimizing the generated table size.

<DT><SAMP>&lsquo;-i <VAR>initial-value</VAR>&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--initial-asso=<VAR>initial-value</VAR>&rsquo;</SAMP>
<DD>
Provides an initial <VAR>value</VAR> for the associate values array.  Default
is 0.  Increasing the initial value helps inflate the final table size,
possibly leading to more time efficient keyword lookups.  Note that this
option is not particularly useful when <SAMP>&lsquo;-S&rsquo;</SAMP> (or, equivalently,
<SAMP>&lsquo;%switch&rsquo;</SAMP>) is used.  Also,
<SAMP>&lsquo;-i&rsquo;</SAMP> is overridden when the <SAMP>&lsquo;-r&rsquo;</SAMP> option is used.

<DT><SAMP>&lsquo;-j <VAR>jump-value</VAR>&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--jump=<VAR>jump-value</VAR>&rsquo;</SAMP>
<DD>
<A NAME="IDX51"></A>
Affects the “jump value”, i.e., how far to advance the associated
byte value upon collisions.  <VAR>Jump-value</VAR> is rounded up to an
odd number, the default is 5.  If the <VAR>jump-value</VAR> is 0 <CODE>gperf</CODE>
jumps by random amounts.

<DT><SAMP>&lsquo;-n&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--no-strlen&rsquo;</SAMP>
<DD>
Instructs the generator not to include the length of a keyword when
computing its hash value.  This may save a few assembly instructions in
the generated lookup table.

<DT><SAMP>&lsquo;-r&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--random&rsquo;</SAMP>
<DD>
Utilizes randomness to initialize the associated values table.  This
frequently generates solutions faster than using deterministic
initialization (which starts all associated values at 0).  Furthermore,
using the randomization option generally increases the size of the
table.

<DT><SAMP>&lsquo;-s <VAR>size-multiple</VAR>&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--size-multiple=<VAR>size-multiple</VAR>&rsquo;</SAMP>
<DD>
Affects the size of the generated hash table.  The numeric argument for
this option indicates “how many times larger or smaller” the maximum
associated value range should be, in relationship to the number of keywords.
It can be written as an integer, a floating-point number or a fraction.
For example, a value of 3 means “allow the maximum associated value to be
about 3 times larger than the number of input keywords”.
Conversely, a value of 1/3 means “allow the maximum associated value to
be about 3 times smaller than the number of input keywords”.  Values
smaller than 1 are useful for limiting the overall size of the generated hash
table, though the option <SAMP>&lsquo;-m&rsquo;</SAMP> is better at this purpose.

If `generate switch' option <SAMP>&lsquo;-S&rsquo;</SAMP> (or, equivalently, <SAMP>&lsquo;%switch&rsquo;</SAMP>) is
<EM>not</EM> enabled, the maximum
associated value influences the static array table size, and a larger
table should decrease the time required for an unsuccessful search, at
the expense of extra table space.

The default value is 1, thus the default maximum associated value is about
the same size as the number of keywords.  (For efficiency, the maximum
associated value is always rounded up to a power of 2.)  The actual
table size may vary somewhat, since this technique is essentially a
heuristic.
</DL>



<H2><A NAME="SEC24" HREF="#TOC24">5.6  Informative Output</A></H2>

<DL COMPACT>

<DT><SAMP>&lsquo;-h&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--help&rsquo;</SAMP>
<DD>
Prints a short summary on the meaning of each program option.  Aborts
further program execution.

<DT><SAMP>&lsquo;-v&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--version&rsquo;</SAMP>
<DD>
Prints out the current version number.

<DT><SAMP>&lsquo;-d&rsquo;</SAMP>
<DD>
<DT><SAMP>&lsquo;--debug&rsquo;</SAMP>
<DD>
Enables the debugging option.  This produces verbose diagnostics to
“standard error” when <CODE>gperf</CODE> is executing.  It is useful both for
maintaining the program and for determining whether a given set of
options is actually speeding up the search for a solution.  Some useful
information is dumped at the end of the program when the <SAMP>&lsquo;-d&rsquo;</SAMP>
option is enabled.
</DL>



<H1><A NAME="SEC25" HREF="#TOC25">6  Known Bugs and Limitations with <CODE>gperf</CODE></A></H1>

<P>
The following are some limitations with the current release of
<CODE>gperf</CODE>:

</P>

<UL>
<LI>

The <CODE>gperf</CODE> utility is tuned to execute quickly, and works quickly
for small to medium size data sets (around 1000 keywords).  It is
extremely useful for maintaining perfect hash functions for compiler
keyword sets.  Since version 3.0, <CODE>gperf</CODE> also works
efficiently on much larger keyword sets (over 15,000 keywords).

<LI>

The size of the generate static keyword array can get <EM>extremely</EM>
large if the input keyword file is large or if the keywords are quite
similar.  This tends to slow down the compilation of the generated C
code, and <EM>greatly</EM> inflates the object code size.  If this
situation occurs, consider using the <SAMP>&lsquo;-S&rsquo;</SAMP> option to reduce data
size, potentially increasing the keyword recognition time by a negligible
amount.  Since many C compilers cannot correctly generate code for
large switch statements it is important to qualify the <VAR>-S</VAR> option
with an appropriate numerical argument that controls the number of
switch statements generated.

<LI>

The maximum number of selected byte positions has an
arbitrary limit of 255.  This restriction should be removed, and if
anyone considers this a problem write me and let me know so I can remove
the constraint.
</UL>



<H1><A NAME="SEC26" HREF="#TOC26">7  Things Still Left to Do</A></H1>

<P>
It should be “relatively” easy to replace the current perfect hash
function algorithm with a more exhaustive approach; the perfect hash
module is essential independent from other program modules.  Additional
worthwhile improvements include:

</P>

<UL>
<LI>

Another useful extension involves modifying the program to generate
“minimal” perfect hash functions (under certain circumstances, the
current version can be rather extravagant in the generated table size).
This is mostly of theoretical interest, since a sparse table
often produces faster lookups, and use of the <SAMP>&lsquo;-S&rsquo;</SAMP> <CODE>switch</CODE>
option can minimize the data size, at the expense of slightly longer
lookups (note that the gcc compiler generally produces good code for
<CODE>switch</CODE> statements, reducing the need for more complex schemes).

<LI>

In addition to improving the algorithm, it would also be useful to
generate an Ada package as the code output, in addition to the current
C and C++ routines.
</UL>



<H1><A NAME="SEC27" HREF="#TOC27">8  Bibliography</A></H1>

<P>
[1] Chang, C.C.: <I>A Scheme for Constructing Ordered Minimal Perfect
Hashing Functions</I> Information Sciences 39(1986), 187-195.

</P>
<P>
[2] Cichelli, Richard J. <I>Author's Response to “On Cichelli's Minimal Perfect Hash
Functions Method”</I> Communications of the ACM, 23, 12(December 1980), 729.

</P>
<P>
[3] Cichelli, Richard J. <I>Minimal Perfect Hash Functions Made Simple</I>
Communications of the ACM, 23, 1(January 1980), 17-19.

</P>
<P>
[4] Cook, C. R. and Oldehoeft, R.R. <I>A Letter Oriented Minimal
Perfect Hashing Function</I> SIGPLAN Notices, 17, 9(September 1982), 18-27.

</P>
<P>
[5] Cormack, G. V. and Horspool, R. N. S. and Kaiserwerth, M.
<I>Practical Perfect Hashing</I> Computer Journal, 28, 1(January 1985), 54-58.

</P>
<P>
[6] Jaeschke, G. <I>Reciprocal Hashing: A Method for Generating Minimal
Perfect Hashing Functions</I> Communications of the ACM, 24, 12(December
1981), 829-833.

</P>
<P>
[7] Jaeschke, G. and Osterburg, G. <I>On Cichelli's Minimal Perfect
Hash Functions Method</I> Communications of the ACM, 23, 12(December 1980),
728-729.

</P>
<P>
[8] Sager, Thomas J. <I>A Polynomial Time Generator for Minimal Perfect
Hash Functions</I> Communications of the ACM, 28, 5(December 1985), 523-532

</P>
<P>
[9] Schmidt, Douglas C. <I>GPERF: A Perfect Hash Function Generator</I>
Second USENIX C++ Conference Proceedings, April 1990.

</P>
<P>
[10] Schmidt, Douglas C. <I>GPERF: A Perfect Hash Function Generator</I>
C++ Report, SIGS 10 10 (November/December 1998).

</P>
<P>
[11] Sebesta, R.W. and Taylor, M.A. <I>Minimal Perfect Hash Functions
for Reserved Word Lists</I>  SIGPLAN Notices, 20, 12(September 1985), 47-53.

</P>
<P>
[12] Sprugnoli, R. <I>Perfect Hashing Functions: A Single Probe
Retrieving Method for Static Sets</I> Communications of the ACM, 20
11(November 1977), 841-850.

</P>
<P>
[13] Stallman, Richard M. <I>Using and Porting GNU CC</I> Free Software Foundation,
1988.

</P>
<P>
[14] Stroustrup, Bjarne <I>The C++ Programming Language.</I> Addison-Wesley, 1986.

</P>
<P>
[15] Tiemann, Michael D. <I>User's Guide to GNU C++</I> Free Software
Foundation, 1989.

</P>


<H1><A NAME="SEC28" HREF="#TOC28">Concept Index</A></H1>

<P>
Jump to:
<A HREF="#cindex_&">&#38;</A>
-
<A HREF="#cindex_a">a</A>
-
<A HREF="#cindex_b">b</A>
-
<A HREF="#cindex_c">c</A>
-
<A HREF="#cindex_d">d</A>
-
<A HREF="#cindex_f">f</A>
-
<A HREF="#cindex_h">h</A>
-
<A HREF="#cindex_i">i</A>
-
<A HREF="#cindex_j">j</A>
-
<A HREF="#cindex_k">k</A>
-
<A HREF="#cindex_m">m</A>
-
<A HREF="#cindex_n">n</A>
-
<A HREF="#cindex_s">s</A>
<P>
<H2><A NAME="cindex_&">&#38;</A></H2>
<DIR>
<LI><A HREF="#IDX8"><SAMP>&lsquo;%%&rsquo;</SAMP></A>
<LI><A HREF="#IDX18"><SAMP>&lsquo;%7bit&rsquo;</SAMP></A>
<LI><A HREF="#IDX19"><SAMP>&lsquo;%compare-lengths&rsquo;</SAMP></A>
<LI><A HREF="#IDX20"><SAMP>&lsquo;%compare-strncmp&rsquo;</SAMP></A>
<LI><A HREF="#IDX17"><SAMP>&lsquo;%define class-name&rsquo;</SAMP></A>
<LI><A HREF="#IDX28"><SAMP>&lsquo;%define constants-prefix&rsquo;</SAMP></A>
<LI><A HREF="#IDX15"><SAMP>&lsquo;%define hash-function-name&rsquo;</SAMP></A>
<LI><A HREF="#IDX14"><SAMP>&lsquo;%define initializer-suffix&rsquo;</SAMP></A>
<LI><A HREF="#IDX30"><SAMP>&lsquo;%define length-table-name&rsquo;</SAMP></A>
<LI><A HREF="#IDX16"><SAMP>&lsquo;%define lookup-function-name&rsquo;</SAMP></A>
<LI><A HREF="#IDX13"><SAMP>&lsquo;%define slot-name&rsquo;</SAMP></A>
<LI><A HREF="#IDX26"><SAMP>&lsquo;%define string-pool-name&rsquo;</SAMP></A>
<LI><A HREF="#IDX29"><SAMP>&lsquo;%define word-array-name&rsquo;</SAMP></A>
<LI><A HREF="#IDX9"><SAMP>&lsquo;%delimiters&rsquo;</SAMP></A>
<LI><A HREF="#IDX22"><SAMP>&lsquo;%enum&rsquo;</SAMP></A>
<LI><A HREF="#IDX24"><SAMP>&lsquo;%global-table&rsquo;</SAMP></A>
<LI><A HREF="#IDX11"><SAMP>&lsquo;%ignore-case&rsquo;</SAMP></A>
<LI><A HREF="#IDX23"><SAMP>&lsquo;%includes&rsquo;</SAMP></A>
<LI><A HREF="#IDX12"><SAMP>&lsquo;%language&rsquo;</SAMP></A>
<LI><A HREF="#IDX27"><SAMP>&lsquo;%null-strings&rsquo;</SAMP></A>
<LI><A HREF="#IDX32"><SAMP>&lsquo;%omit-struct-type&rsquo;</SAMP></A>
<LI><A HREF="#IDX25"><SAMP>&lsquo;%pic&rsquo;</SAMP></A>
<LI><A HREF="#IDX21"><SAMP>&lsquo;%readonly-tables&rsquo;</SAMP></A>
<LI><A HREF="#IDX10"><SAMP>&lsquo;%struct-type&rsquo;</SAMP></A>
<LI><A HREF="#IDX31"><SAMP>&lsquo;%switch&rsquo;</SAMP></A>
<LI><A HREF="#IDX33"><SAMP>&lsquo;%{&rsquo;</SAMP></A>
<LI><A HREF="#IDX34"><SAMP>&lsquo;%}&rsquo;</SAMP></A>
</DIR>
<H2><A NAME="cindex_a">a</A></H2>
<DIR>
<LI><A HREF="#IDX47">Array name</A>, <A HREF="#IDX48">Array name</A>
</DIR>
<H2><A NAME="cindex_b">b</A></H2>
<DIR>
<LI><A HREF="#IDX1">Bugs</A>
</DIR>
<H2><A NAME="cindex_c">c</A></H2>
<DIR>
<LI><A HREF="#IDX44">Class name</A>
<LI><A HREF="#IDX45">Constants definition</A>
<LI><A HREF="#IDX46">Constants prefix</A>
<LI><A HREF="#IDX40">Copyright</A>
</DIR>
<H2><A NAME="cindex_d">d</A></H2>
<DIR>
<LI><A HREF="#IDX5">Declaration section</A>
<LI><A HREF="#IDX41">Delimiters</A>
<LI><A HREF="#IDX50">Duplicates</A>
</DIR>
<H2><A NAME="cindex_f">f</A></H2>
<DIR>
<LI><A HREF="#IDX4">Format</A>
<LI><A HREF="#IDX7">Functions section</A>
</DIR>
<H2><A NAME="cindex_h">h</A></H2>
<DIR>
<LI><A HREF="#IDX36">hash</A>
<LI><A HREF="#IDX35">hash table</A>
</DIR>
<H2><A NAME="cindex_i">i</A></H2>
<DIR>
<LI><A HREF="#IDX37">in_word_set</A>
<LI><A HREF="#IDX43">Initializers</A>
</DIR>
<H2><A NAME="cindex_j">j</A></H2>
<DIR>
<LI><A HREF="#IDX51">Jump value</A>
</DIR>
<H2><A NAME="cindex_k">k</A></H2>
<DIR>
<LI><A HREF="#IDX6">Keywords section</A>
</DIR>
<H2><A NAME="cindex_m">m</A></H2>
<DIR>
<LI><A HREF="#IDX3">Minimal perfect hash functions</A>
</DIR>
<H2><A NAME="cindex_n">n</A></H2>
<DIR>
<LI><A HREF="#IDX39">NUL</A>
</DIR>
<H2><A NAME="cindex_s">s</A></H2>
<DIR>
<LI><A HREF="#IDX42">Slot name</A>
<LI><A HREF="#IDX2">Static search structure</A>
<LI><A HREF="#IDX38"><CODE>switch</CODE></A>, <A HREF="#IDX49"><CODE>switch</CODE></A>
</DIR>

</P>

<P><HR><P>
This document was generated on 16 April 2025 using the
<A HREF="http://wwwinfo.cern.ch/dis/texi2html/">texi2html</A>
translator version 1.52b.</P>

</div>


## Editorial notes on the fixed source

- In guide section 4.2, the sentence “Otherwise it returns NULL” after the struct-return description is ambiguous for a successful non-struct lookup. The fixed 3.3 implementation (`src/output.cc`, ordinary lookup success branch) returns the matching keyword string pointer without `--struct-type`, and a structure pointer with that option. The failure path returns NULL. The original guide text is retained; this is a separate implementation note, not an upstream correction.
- The CLI states that `--jump` must be odd, while guide section 5.5 describes rounding up even values. The fixed `src/options.cc` parser rejects negative values and adds one to a nonzero even value. Both original texts are retained. The zero-value random behavior has not been independently executed here.
- In guide section 4.2, the introductory prose calls the parameters `char * str` and `int len`, while the displayed default prototypes use `const char * str` and `size_t len`. Both original forms are retained. This note identifies a difference within the fixed guide and does not replace either form or claim an independently executed signature test.
