# GNU gperf 3.3 document editing sources / 文書の編集用ソース

This package provides the preferred editable English canonical and Japanese Markdown,
the fixed upstream archive and documentation inputs, translation HTML fragments,
conversion scripts, and the Libx app configuration and custom copy UI source.
Paths below this directory retain their Libx repository layout.

固定GNU gperf 3.3原配布アーカイブ、全英日Markdown 4ファイル、原入力、訳文HTML断片、
生成器、アプリ設定とコピー操作のソースを、編集可能な形で収録しています。
利用ガイドの版表示は第3.2版（2024年10月28日）、CLIは3.3（2025年4月）です。
ソフトウェアの版と文書の版を混同していません。

Upstream: https://ftp.gnu.org/pub/gnu/gperf/gperf-3.3.tar.gz
SHA-256: fd87e0aba7e43ae054837afd6cd4db03a3f2693deb3619085e6ed9d8d9604ad8
The detached signature is not cryptographically verified; the fixed hash is an integrity record.
署名の暗号学的検証は未実施です。固定ハッシュは整合性の記録です。

## Notices / 通知

The complete derived user guide uses the original manual permission notice, reproduced
in each guide. The entire original English GPL chapter remains unchanged. This guide
permission takes precedence over the software-license fallback.
The complete CLI work, including unofficial Japanese translation, formatting, and separate
editorial notes, is provided under GPL-3.0-or-later using the annotated software-license
fallback. The original man-page notice and complete COPYING are preserved.
Libx gperf conversion, checking, packaging, and custom copy-UI additions are provided
under GPL-3.0-or-later. Existing shared Libx code retains its existing conditions;
this notice does not relicense it or the other upstream components.

利用ガイドの派生物全体には、各本文に保持した原マニュアルと同一の許諾通知を適用します。
原英語のGPL章は変更していません。ガイド固有の許諾を本体GPLで置き換えていません。
CLIの日本語訳・整形・別掲の編集注記を含む全体には、文書専用の別許諾が未確認のため、
注釈付きでソフトウェア本体のGPL-3.0-or-laterを適用しています。
原manの著作権・許諾・無保証通知とCOPYING全文を保存しています。
Libxのgperf用変換・検査・梱包・コピーUIの追加部分をGPL-3.0-or-laterで提供します。
既存の共有Libxコードと他の原配布成分の条件はそれぞれ保持し、一括で再許諾していません。

Libx modification date (Japan Standard Time): 2026-10-04.
Changes: unofficial Japanese translation, format and internal-link conversion, original
notice preservation, three separately marked editorial notes, and functional code-copy controls.
Libx変更日（日本標準時）: 2026-10-04。変更は非公式日本語訳、書式・内部リンク、
原通知の保持、別掲した3編集注記、通常コード例へのコピー操作です。

## Regeneration / 再生成

The editable Markdown can be reused directly, subject to the applicable notices.
For the full site environment, use Libx https://github.com/dolphilia/libx at baseline
077b6923e2fbede0b6c1e43656ae7d7316ffcbb4, then overlay this package's files.
Shared UI/packages and general-purpose external dependencies are supplied by that
repository and the registries; this is a document-editing source package, not a complete
self-contained site distribution. Requires Node >=20, pnpm10.10.0 and Python3.

pnpm install --frozen-lockfile
node scripts/document-import/gperf/import.mjs --check
pnpm --filter apps-gperf build
node scripts/document-import/gperf/check-rendered.mjs
python3 scripts/document-import/gperf/package-sources.py --check

Markdownは各通知に従い直接編集できます。サイト環境での再生成には、上記Libx固定commitへ
このパッケージを重ね、既存の共有パッケージと一般的な依存関係を使用します。
この配布物は文書の編集用ソースであり、サイト全体を単独実行する配布物ではありません。
FILE_MANIFEST.json records each member SHA-256; it is not a content-review certificate.
FILE_MANIFEST.jsonは各収録ファイルの整合性一覧であり、内容レビュー合格証明ではありません。
