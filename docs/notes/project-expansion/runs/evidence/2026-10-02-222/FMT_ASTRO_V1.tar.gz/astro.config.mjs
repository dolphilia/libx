import {defineConfig} from 'astro/config';
import {defineDocsConfig} from '@docs/config';
const shared=defineDocsConfig({rootDir:'/private/tmp/libx-fmt-astro-trial-222'});
export default defineConfig({markdown:{...shared.markdown,smartypants:false},output:'static'});
