import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { collectAnchors, checkFile } from '../../scripts/check-markdown-links.js';

test('HTML id and named anchors are checked with exact case and duplicate headings remain valid', (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'libx-markdown-anchor-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const file = path.join(dir, 'page.md');
  fs.writeFileSync(
    file,
    [
      '# Heading',
      '# Heading',
      '<span class="anchor" id="source-PUGIXML_API"></span>',
      "<a name='legacy'></a>",
      '<!-- <span id="comment"></span> -->',
      '`<span id="inline-code"></span>`',
      '```html',
      '<span id="fenced-code"></span>',
      '```',
      '<pre><code>&lt;span id="escaped-code"&gt;</code></pre>',
      '[explicit](#source-PUGIXML_API) [named](#legacy) [duplicate](#heading-1)',
      '[wrong case](#source-pugixml_api) [missing](#absent)',
    ].join('\n')
  );
  const anchors = collectAnchors(file);
  assert.ok(anchors.has('source-PUGIXML_API'));
  assert.ok(anchors.has('legacy'));
  for (const invalid of ['comment', 'inline-code', 'fenced-code', 'escaped-code'])
    assert.ok(!anchors.has(invalid));
  assert.deepEqual(
    checkFile(file).map((x) => x.target),
    ['#source-pugixml_api', '#absent']
  );
});

test('source heading markers need an adjacent heading and cannot come from literal code', (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'libx-source-heading-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const file = path.join(dir, 'page.md');
  fs.writeFileSync(
    file,
    [
      '<!--libx-source-heading:Macro_reference-->',
      '',
      '# 日本語見出し',
      '<!--libx-source-heading:orphan-->',
      '',
      'not a heading',
      '```md',
      '<!--libx-source-heading:literal-->',
      '# Code',
      '```',
      '[valid](#Macro_reference) [wrong](#macro_reference) [orphan](#orphan) [code](#literal)',
    ].join('\n')
  );
  assert.deepEqual(
    checkFile(file).map((x) => x.target),
    ['#macro_reference', '#orphan', '#literal']
  );
});

test('split drafts check fragments against a byte-identical assembled document', (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'libx-link-context-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const first = '[other section](#target) [missing](#absent)\n';
  const last = '<!--libx-source-heading:target-->\n# 別の節\n';
  fs.writeFileSync(path.join(dir, 'first.md'), first);
  fs.writeFileSync(path.join(dir, 'last.md'), last);
  fs.writeFileSync(path.join(dir, 'whole.md'), first + last);
  fs.writeFileSync(
    path.join(dir, 'link-context.json'),
    JSON.stringify({
      target: 'whole.md',
      segments: ['first.md', 'last.md'],
    })
  );
  assert.deepEqual(
    checkFile(path.join(dir, 'first.md')).map((x) => x.target),
    ['#absent']
  );
  fs.appendFileSync(path.join(dir, 'last.md'), 'changed');
  assert.match(checkFile(path.join(dir, 'first.md'))[0].reason, /結合.*一致しません/);
});
