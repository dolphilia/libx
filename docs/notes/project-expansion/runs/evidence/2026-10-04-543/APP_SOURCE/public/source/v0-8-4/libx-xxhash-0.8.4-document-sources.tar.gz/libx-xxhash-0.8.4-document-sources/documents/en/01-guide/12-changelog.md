---
title: "CHANGELOG"
licenseSource: "xxhash-library"
---

v0.8.4
- perf : added RISC-V Vector extension (RVV) implementation, by @zijianli1234, @BoBoDai and @camel-cdr
- perf : added LoongArch LASX implementation and improved LSX, by @24bit-xjkp
- perf : prefer NEON over SVE on AArch64, improving XXH3 speed by 25-40%, by @Nicoshev
- perf : improved XXH3 streaming speed for very small updates, suggested by @aleksazr
- api  : `XXH_memcpy()`, `XXH_memset()` and `XXH_memcmp()` can be redirected at compile time
- api  : new `XXH_NO_EXTERNC_GUARD` build macro for complex C++ integration
- cli  : added 64-bit seed support (`-s`, `--seed`), by @d06i
- cli  : options can appear after filenames; `--` terminates option parsing, #1098 reported by @unterkomplex
- cli  : continue processing subsequent files after read errors, #1064 reported by @ZoomRmc
- cli  : support long and special Windows paths, #1060, based on #1061 by @t-mat
- cli  : improved benchmark accuracy, error handling and unit labels, #1051 reported by @calgray
- fix  : unaligned reads could be miscompiled by GCC under strict aliasing, #1013 by @lassipulkkinen
- fix  : `XXH_INLINE_ALL` compatibility with `XXH_NAMESPACE` and x86 runtime dispatch, by @pps83, #1071 reported by @Dr-Hex
- fix  : avoid including system headers inside an `extern "C"` block, #1122 reported by @andreas-schwab
- fix  : compilation with MSVC link-time optimization and warnings as errors, #1038 reported by @mi2think
- build: improved runtime dispatch detection for cross-compilation and non-x86 targets, with help from @eworm-de, #1081 reported by @PotMJ
- build: `LIBXXH_DISPATCH=1` now applies to static and dynamic libraries, #1058 reported by @xiota
- build: Make builds now isolate objects by configuration and support parallel test builds
- build: moved CMake integration to `build/cmake` and improved cross-compilation detection
- install: improved package metadata and installation paths on Windows and FreeBSD, by @iwamatsu, @chitao1234 and @sunpoet
- portability: fixed compilation on ARM with GCC < 8, by @mstorsjo
- portability: fixed C++ compilation on Solaris and illumos, by @luqmana
- portability: AVX-512 implementation no longer requires AVX-512BW, by @NexusXe
- doc  : expanded `xxhsum` documentation and clarified the algorithm specification files
- doc  : document non-cryptographic collision properties, notably for XXH3's mid-size path (#1127 by @thomasahle)

v0.8.3
- fix  : variant `XXH3_128bits_withSecretandSeed()` could produce an invalid result in some specific set of conditions, #894 by @hltj
- cli  : vector extension detected at runtime on x86/x64, enabled by default
- cli  : new commands `--filelist` and `--files-from`, by @Ian-Clowes
- cli  : XXH3 64-bits GNU format can now be generated and checked (command `-H3`)
- portability: LoongArch SX SIMD extension, by @lrzlin
- portability: can build on AIX, suggested by @likema
- portability: validated for SPARC cpus

v0.8.2
- fix  : XXH3 S390x vector implementation (@hzhuang1)
- fix  : PowerPC vector compilation with IBM XL compiler (@MaxiBoether)
- perf : improved WASM speed by x2/x3 using SIMD128 (@easyaspi314)
- perf : improved speed (+20%) for XXH3 on ARM NEON (@easyaspi314)
- cli  : Fix filename contain /LF character (@t-mat)
- cli  : Support # comment lines in --check files (@t-mat)
- cli  : Support commands --binary and --ignore-missing (@t-mat)
- build: fix -Og compilation (@easyaspi314, @t-mat)
- build: fix pkgconfig generation with cmake (@ilya-fedin)
- build: fix icc compilation
- build: fix cmake install directories
- build: new build options XXH_NO_XXH3, XXH_SIZE_OPT and XXH_NO_STREAM to reduce binary size (@easyaspi314)
- build: dedicated install targets (@ffontaine)
- build: support DISPATCH mode in cmake (@hzhuang1)
- portability: fix x86dispatch when building with Visual + clang-cl (@t-mat)
- portability: SVE vector implementation of XXH3 (@hzhuang1)
- portability: compatibility with freestanding environments, using XXH_NO_STDLIB
- portability: can build on Haiku (@Begasus)
- portability: validated on m68k and risc-v
- doc  : XXH3 specification (@Adrien1018)
- doc  : improved doxygen documentation (@easyaspi314, @t-mat)
- misc : dedicated sanity test binary (@t-mat)

v0.8.1
- perf : much improved performance for XXH3 streaming variants, notably on gcc and msvc
- perf : improved XXH64 speed and latency on small inputs
- perf : small XXH32 speed and latency improvement on small inputs of random size
- perf : minor stack usage improvement for XXH32 and XXH64
- api  : new experimental variants XXH3_*_withSecretandSeed()
- api  : update XXH3_generateSecret(), can no generate secret of any size (>= XXH3_SECRET_SIZE_MIN)
- cli  : xxhsum can now generate and check XXH3 checksums, using command `-H3`
- build: can build xxhash without XXH3, with new build macro XXH_NO_XXH3
- build: fix xxh_x86dispatch build with MSVC, by @apankrat
- build: XXH_INLINE_ALL can always be used safely, even after XXH_NAMESPACE or a previous XXH_INLINE_ALL
- build: improved PPC64LE vector support, by @mpe
- install: fix pkgconfig, by @ellert
- install: compatibility with Haiku, by @Begasus
- doc  : code comments made compatible with doxygen, by @easyaspi314
- misc : XXH_ACCEPT_NULL_INPUT_POINTER is no longer necessary, all functions can accept NULL input pointers, as long as size == 0
- misc : complete refactor of CI tests on Github Actions, offering much larger coverage, by @t-mat
- misc : xxhsum code base split into multiple specialized units, within directory cli/, by @easyaspi314

v0.8.0
- api : stabilize XXH3
- cli : xxhsum can parse BSD-style --check lines, by @WayneD
- cli : `xxhsum -` accepts console input, requested by @jaki
- cli : xxhsum accepts -- separator, by @jaki
- cli : fix : print correct default algo for symlinked helpers, by @martinetd
- install: improved pkgconfig script, allowing custom install locations, requested by @ellert

v0.7.4
- perf: automatic vector detection and selection at runtime (`xxh_x86dispatch.h`), initiated by @easyaspi314
- perf: added AVX512 support, by @gzm55
- api : new: secret generator `XXH_generateSecret()`, suggested by @koraa
- api : fix: XXH3_state_t is movable, identified by @koraa
- api : fix: state is correctly aligned in AVX mode (unlike `malloc()`), by @easyaspi314
- api : fix: streaming generated wrong values in some combination of random ingestion lengths, reported by @WayneD
- cli : fix unicode print on Windows, by @easyaspi314
- cli : can `-c` check file generated by sfv
- build: `make DISPATCH=1` generates `xxhsum` and `libxxhash` with runtime vector detection (x86/x64 only)
- install: cygwin installation support
- doc : Cryptol specification of XXH32 and XXH64, by @weaversa

v0.7.3
- perf: improved speed for large inputs (~+20%)
- perf: improved latency for small inputs (~10%)
- perf: s390x Vectorial code, by @easyaspi314
- cli: improved support for Unicode filenames on Windows, thanks to @easyaspi314 and @t-mat
- api: `xxhash.h` can now be included in any order, with and without `XXH_STATIC_LINKING_ONLY` and `XXH_INLINE_ALL`
- build: xxHash's implementation transferred into `xxhash.h`. No more need to have `xxhash.c` in the `/include` directory for `XXH_INLINE_ALL` to work
- install: created pkg-config file, by @bket
- install: VCpkg installation instructions, by @LilyWangL
- doc: Highly improved code documentation, by @easyaspi314
- misc: New test tool in `/tests/collisions`: brute force collision tester for 64-bit hashes

v0.7.2
- Fixed collision ratio of `XXH128` for some specific input lengths, reported by @svpv
- Improved `VSX` and `NEON` variants, by @easyaspi314
- Improved performance of scalar code path (`XXH_VECTOR=0`), by @easyaspi314
- `xxhsum`: can generate 128-bit hashes with the `-H2` option (note: for experimental purposes only! `XXH128` is not yet frozen)
- `xxhsum`: option `-q` removes status notifications

v0.7.1
- Secret first: the algorithm computation can be altered by providing a "secret", which is any blob of bytes, of size >= `XXH3_SECRET_SIZE_MIN`.
- `seed` is still available, and acts as a secret generator
- updated `ARM NEON` variant by @easyaspi314
- Streaming implementation is available
- Improve compatibility and performance with Visual Studio, with help from @aras-p
- Better integration when using `XXH_INLINE_ALL`: do not pollute host namespace, use its own macros, such as `XXH_ASSERT()`, `XXH_ALIGN`, etc.
- 128-bit variant provides helper functions for comparison of hashes.
- Better `clang` generation of `rotl` instruction, thanks to @easyaspi314
- `XXH_REROLL` build macro to reduce binary size, by @easyaspi314
- Improved `cmake` script, by @Mezozoysky
- Full benchmark program provided in `/tests/bench`


## Source and notices

No documentation-specific license statement was found in the recorded checks. Under the user-approved operating policy, the software component’s BSD-2-Clause license is applied to this documentation with this annotation. This is an operational decision, not a newly obtained permission.

Fixed software version: **0.8.4**. Source commit: `c87183a77d67f7d37e3d2d1b7eaac5e7c695e4f0`. This is an unofficial presentation; formatting, internal links and clearly marked editorial notes are Libx changes. The Japanese translation is provided separately when completed.

[library-root](/docs/xxhash/v0-8-4/en/03-notices/library-root/)

[Fixed original source](https://github.com/Cyan4973/xxHash/blob/c87183a77d67f7d37e3d2d1b7eaac5e7c695e4f0/CHANGELOG) · [Original text download](/docs/xxhash/source/v0-8-4/CHANGELOG.txt)

