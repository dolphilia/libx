---
title: "rapidjson::GenericValue< Encoding, Allocator >::Number::U Struct Reference"
documentId: "rapidjson:structrapidjson_1_1_generic_value_1_1_number_1_1_u.html"
order: 186
licenseSource: "rapidjson-fixed"
documentContext: [{"kind": "source", "html": "<p>RapidJSON 1.1.0; fixed commit f54b0e47a08782a6131cc3d60f94d038fa6e0a51. Copyright (C) 2015 THL A29 Limited and Milo Yip. <a href=\"/docs/rapidjson-trial/notices/LICENSE.txt\">Full original licence and component notices</a>. Unpublished Libx presentation trial; translation and full semantic review incomplete.</p><p>文書専用ライセンスの表記が確認できないため、ソフトウェア本体のMIT Licenseを文書にも適用する運用判断で掲載しています。</p>"}]
---

<div class="contents rapidjson-document">&#10;<table class="memberdecls">&#10;<tbody><tr class="heading"><td colspan="2"><h2 id="header-pub-attribs" class="groupheader"><a id="pub-attribs" name="pub-attribs"></a>&#10;Public Attributes</h2></td></tr>&#10;<tr class="memitem:aa624c2fe538411dd515dcfb0d72472b1" id="r_aa624c2fe538411dd515dcfb0d72472b1"><td class="memItemLeft"><a id="aa624c2fe538411dd515dcfb0d72472b1" name="aa624c2fe538411dd515dcfb0d72472b1"></a>&#10;unsigned&nbsp;</td><td class="memItemRight"><b>u</b></td></tr>&#10;<tr class="memitem:a5e882e180f56ea6cc4fd1e1d508e5a63" id="r_a5e882e180f56ea6cc4fd1e1d508e5a63"><td class="memItemLeft"><a id="a5e882e180f56ea6cc4fd1e1d508e5a63" name="a5e882e180f56ea6cc4fd1e1d508e5a63"></a>&#10;char&nbsp;</td><td class="memItemRight"><b>padding2</b> [4]</td></tr>&#10;</tbody></table>&#10;<hr>The documentation for this struct was generated from the following file:<ul>&#10;<li>include/rapidjson/<a class="el" href="/docs/rapidjson-trial/v1-1-0/en/01-docs/066-document_8h_source/">document.h</a></li>&#10;</ul>&#10;</div>
