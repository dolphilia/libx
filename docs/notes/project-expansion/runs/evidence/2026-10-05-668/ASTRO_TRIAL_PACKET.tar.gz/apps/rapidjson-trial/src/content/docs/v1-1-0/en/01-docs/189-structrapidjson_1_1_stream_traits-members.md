---
title: "Member List"
documentId: "rapidjson:structrapidjson_1_1_stream_traits-members.html"
order: 189
licenseSource: "rapidjson-fixed"
documentContext: [{"kind": "source", "html": "<p>RapidJSON 1.1.0; fixed commit f54b0e47a08782a6131cc3d60f94d038fa6e0a51. Copyright (C) 2015 THL A29 Limited and Milo Yip. <a href=\"/docs/rapidjson-trial/notices/LICENSE.txt\">Full original licence and component notices</a>. Unpublished Libx presentation trial; translation and full semantic review incomplete.</p><p>文書専用ライセンスの表記が確認できないため、ソフトウェア本体のMIT Licenseを文書にも適用する運用判断で掲載しています。</p>"}]
---

<div class="contents rapidjson-document">&#10;&#10;<p>This is the complete list of members for <a class="el" href="/docs/rapidjson-trial/v1-1-0/en/01-docs/190-structrapidjson_1_1_stream_traits/">rapidjson::StreamTraits&lt; Stream &gt;</a>, including all inherited members.</p>&#10;<table class="directory">&#10;  <tbody><tr bgcolor="#f0f0f0" class="even"><td class="entry"><b>copyOptimization</b> enum value (defined in <a class="el" href="/docs/rapidjson-trial/v1-1-0/en/01-docs/190-structrapidjson_1_1_stream_traits/">rapidjson::StreamTraits&lt; Stream &gt;</a>)</td><td class="entry"><a class="el" href="/docs/rapidjson-trial/v1-1-0/en/01-docs/190-structrapidjson_1_1_stream_traits/">rapidjson::StreamTraits&lt; Stream &gt;</a></td><td class="entry"></td></tr>&#10;</tbody></table></div>
