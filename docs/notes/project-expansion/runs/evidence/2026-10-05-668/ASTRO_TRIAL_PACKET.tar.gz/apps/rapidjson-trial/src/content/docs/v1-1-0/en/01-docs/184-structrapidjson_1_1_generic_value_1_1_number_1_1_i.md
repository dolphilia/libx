---
title: "rapidjson::GenericValue< Encoding, Allocator >::Number::I Struct Reference"
documentId: "rapidjson:structrapidjson_1_1_generic_value_1_1_number_1_1_i.html"
order: 184
licenseSource: "rapidjson-fixed"
documentContext: [{"kind": "source", "html": "<p>RapidJSON 1.1.0; fixed commit f54b0e47a08782a6131cc3d60f94d038fa6e0a51. Copyright (C) 2015 THL A29 Limited and Milo Yip. <a href=\"/docs/rapidjson-trial/notices/LICENSE.txt\">Full original licence and component notices</a>. Unpublished Libx presentation trial; translation and full semantic review incomplete.</p><p>文書専用ライセンスの表記が確認できないため、ソフトウェア本体のMIT Licenseを文書にも適用する運用判断で掲載しています。</p>"}]
---

<div class="contents rapidjson-document">&#10;<table class="memberdecls">&#10;<tbody><tr class="heading"><td colspan="2"><h2 id="header-pub-attribs" class="groupheader"><a id="pub-attribs" name="pub-attribs"></a>&#10;Public Attributes</h2></td></tr>&#10;<tr class="memitem:aee43f62c5529fb886642fb410ff93a05" id="r_aee43f62c5529fb886642fb410ff93a05"><td class="memItemLeft"><a id="aee43f62c5529fb886642fb410ff93a05" name="aee43f62c5529fb886642fb410ff93a05"></a>&#10;int&nbsp;</td><td class="memItemRight"><b>i</b></td></tr>&#10;<tr class="memitem:ae0b11ea3695bf3abb23d5cef1f1517d2" id="r_ae0b11ea3695bf3abb23d5cef1f1517d2"><td class="memItemLeft"><a id="ae0b11ea3695bf3abb23d5cef1f1517d2" name="ae0b11ea3695bf3abb23d5cef1f1517d2"></a>&#10;char&nbsp;</td><td class="memItemRight"><b>padding</b> [4]</td></tr>&#10;</tbody></table>&#10;<hr>The documentation for this struct was generated from the following file:<ul>&#10;<li>include/rapidjson/<a class="el" href="/docs/rapidjson-trial/v1-1-0/en/01-docs/066-document_8h_source/">document.h</a></li>&#10;</ul>&#10;</div>
