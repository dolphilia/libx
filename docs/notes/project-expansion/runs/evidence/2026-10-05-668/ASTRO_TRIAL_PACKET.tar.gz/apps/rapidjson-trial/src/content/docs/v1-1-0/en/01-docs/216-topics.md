---
title: "Topics"
documentId: "rapidjson:topics.html"
order: 216
licenseSource: "rapidjson-fixed"
documentContext: [{"kind": "source", "html": "<p>RapidJSON 1.1.0; fixed commit f54b0e47a08782a6131cc3d60f94d038fa6e0a51. Copyright (C) 2015 THL A29 Limited and Milo Yip. <a href=\"/docs/rapidjson-trial/notices/LICENSE.txt\">Full original licence and component notices</a>. Unpublished Libx presentation trial; translation and full semantic review incomplete.</p><p>文書専用ライセンスの表記が確認できないため、ソフトウェア本体のMIT Licenseを文書にも適用する運用判断で掲載しています。</p>"}]
---

<div class="contents rapidjson-document">&#10;<div class="textblock">Here is a list of all topics with brief descriptions:</div><div class="directory">&#10;<table class="directory">&#10;<tbody><tr id="row_0_" class="even"><td class="entry"><span style="width:16px;display:inline-block;">&nbsp;</span><a class="el" href="/docs/rapidjson-trial/v1-1-0/en/01-docs/121-group___r_a_p_i_d_j_s_o_n___c_o_n_f_i_g/" target="_self">RapidJSON configuration</a></td><td class="desc">Configuration macros for library features </td></tr>&#10;<tr id="row_1_" class="odd"><td class="entry"><span style="width:16px;display:inline-block;">&nbsp;</span><a class="el" href="/docs/rapidjson-trial/v1-1-0/en/01-docs/122-group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s/" target="_self">RapidJSON error handling</a></td><td class="desc"></td></tr>&#10;</tbody></table>&#10;</div><!-- directory -->&#10;</div>
