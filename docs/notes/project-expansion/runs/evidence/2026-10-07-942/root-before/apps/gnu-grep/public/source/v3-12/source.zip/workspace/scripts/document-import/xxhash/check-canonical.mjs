import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..'),
  require = createRequire(root + '/package.json'),
  { parse, serializeOuter } = require('parse5'),
  sha = (s) => createHash('sha256').update(s).digest('hex'),
  note = root + '/docs/notes/document-import/xxhash/v0-8-4',
  app = root + '/apps/xxhash',
  map = JSON.parse(fs.readFileSync(note + '/CONTENT_MAP.json')),
  gen = JSON.parse(fs.readFileSync(note + '/CANONICAL_GENERATION.json')),
  walk = (n) => [n, ...(n.childNodes ?? []).flatMap(walk)],
  attr = (n, k) => n.attrs?.find((a) => a.name === k)?.value;
const results = [];
for (const item of map.items) {
  const source = fs.readFileSync(root + '/' + item.source.path, 'utf8'),
    md = fs.readFileSync(root + '/' + item.canonical, 'utf8'),
    record = gen.records.find((r) => r.sourcePath === item.sourcePath);
  assert.equal(sha(source), item.source.sha256);
  assert.equal(sha(md), record.canonicalSHA256);
  const body = md.slice(md.indexOf('\n---\n') + 5).replace(/^\n/, '');
  if (item.sourcePath.startsWith('doxygen/')) {
    const sourceNodes = walk(parse(source)),
      nodeText = (n) => n.value ?? (n.childNodes ?? []).map(nodeText).join(''),
      originalTitle = nodeText(
        sourceNodes.find((n) => (attr(n, 'class') ?? '').split(/\s+/).includes('title')) ?? {}
      ),
      expectedTitle = originalTitle.trim()
        ? originalTitle
        : nodeText(sourceNodes.find((n) => n.tagName === 'title') ?? {})
            .replace(/^xxHash:\s*/, '')
            .trim();
    assert(expectedTitle.trim());
    assert.equal(
      JSON.parse(md.match(/^title: (.+)$/m)[1]),
      expectedTitle,
      item.sourcePath + ' original title preservation'
    );
    const raw = walk(parse(source)).find((n) =>
        (attr(n, 'class') ?? '').split(/\s+/).includes('contents')
      ),
      output = walk(parse(md)).find((n) =>
        (attr(n, 'class') ?? '').split(/\s+/).includes('contents')
      );
    assert(raw && output);
    const normalized = walk(output);
    for (const n of normalized) {
      if (n === output)
        n.attrs.find((a) => a.name === 'class').value = n.attrs
          .find((a) => a.name === 'class')
          .value.replace(/\s+xxhash-api$/, '');
      const h = attr(n, 'href'),
        change = record.linkChanges.find((c) => c.to === h);
      if (change) n.attrs.find((a) => a.name === 'href').value = change.from;
      const id = attr(n, 'id'),
        repair = record.indexAliasRepairs.find((r) => r.href === '#' + id);
      if (repair) n.attrs = n.attrs.filter((a) => a.name !== 'id');
    }
    assert.equal(serializeOuter(output), serializeOuter(raw), item.sourcePath);
    results.push({
      sourcePath: item.sourcePath,
      kind: 'api-whole-original-DOM',
      originalExactAfterEnumeratedUrlAndAliasReversal: true,
    });
  } else if (item.role === 'whole-original-notice') {
    assert(body.includes('```text\n' + source + '\n```'), item.sourcePath);
    results.push({ sourcePath: item.sourcePath, kind: 'whole-original-notice', verbatim: true });
  } else {
    let expected = source;
    for (const c of [...record.linkChanges].sort((a, b) => b.start - a.start)) {
      assert.equal(expected.slice(c.start, c.end), c.from);
      expected = expected.slice(0, c.start) + c.to + expected.slice(c.end);
    }
    for (const r of record.syntaxRepairs ?? []) {
      assert(expected.includes(r.from));
      expected = expected.replace(r.from, r.to);
    }
    assert(body.startsWith(expected + '\n\n## Source and notices'), item.sourcePath);
    results.push({
      sourcePath: item.sourcePath,
      kind: 'whole-original-source-text',
      exactAfterEnumeratedUrlRewrites: true,
    });
  }
}
const files = [];
function collect(d) {
  for (const e of fs.readdirSync(d, { withFileTypes: true })) {
    if (e.isDirectory()) collect(d + '/' + e.name);
    else if (e.name.endsWith('.md')) files.push(path.relative(root, d + '/' + e.name));
  }
}
collect(app + '/src/content/docs/v0-8-4/en');
assert.deepEqual([...files].sort(), map.items.map((i) => i.canonical).sort());
const headings = JSON.parse(fs.readFileSync(app + '/src/data/xxhash-api-headings.json'));
assert.equal(Object.keys(headings).length, 33);
assert.equal(Object.values(headings).flat().length, 250);
console.log(
  JSON.stringify(
    {
      status: 'passed-for-canonical-machine-preservation-not-content-review',
      canonicalPages: files.length,
      bodyPages: 44,
      originalCodePages: 1,
      originalNoticePages: 11,
      rawApiHeadings: 250,
      apiTitlesMatchedToOriginal: 33,
      results,
    },
    null,
    2
  )
);
