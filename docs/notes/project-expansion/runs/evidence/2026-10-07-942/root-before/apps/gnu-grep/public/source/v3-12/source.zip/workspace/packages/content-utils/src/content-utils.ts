import fs from 'node:fs/promises';
import path from 'node:path';
import type { LocaleKey } from '@docs/i18n/locales';
import { getCollection, type CollectionEntry } from 'astro:content';
import { resolveProjectDir } from '@docs/project-config';
import { buildDocumentPath as buildPath } from './path-utils';

export interface ContentFile {
  slug: string;
  lang: LocaleKey;
  version: string;
  section: string;
  title?: string;
  fullPath: string;
  url: string;
}

export interface ContentOptions {
  projectDir?: string;
  pathPattern?: 'version-first' | 'locale-first';
}

export function buildDocumentPath(
  version: string,
  lang: LocaleKey,
  relativePath: string | string[] | undefined,
  options?: ContentOptions
): string {
  return buildPath(version, lang, relativePath, options?.pathPattern);
}

/**
 * ディレクトリ構造を再帰的にスキャンしてMarkdownファイルを探す
 */
async function scanDirectory(dirPath: string, basePath = ''): Promise<string[]> {
  const files: string[] = [];

  try {
    const entries = await fs.readdir(dirPath, { withFileTypes: true });

    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry.name);
      const relativePath = basePath ? path.join(basePath, entry.name) : entry.name;

      if (entry.isDirectory()) {
        const subFiles = await scanDirectory(fullPath, relativePath);
        files.push(...subFiles);
      } else if (entry.isFile() && /\.mdx?$/.test(entry.name)) {
        files.push(relativePath);
      }
    }
  } catch {
    // ディレクトリが存在しない場合やアクセス権限がない場合はスキップ
  }

  return files;
}

/**
 * 実際のディレクトリ構造からコンテンツファイルの一覧を取得し、URLを生成する
 */
export async function getAvailableContent(options?: ContentOptions): Promise<ContentFile[]> {
  const projectDir = resolveProjectDir(options?.projectDir);
  const contentDir = path.join(projectDir, 'src', 'content', 'docs');
  const contentFiles: ContentFile[] = [];

  try {
    const markdownFiles = await scanDirectory(contentDir);

    for (const filePath of markdownFiles) {
      const pathParts = filePath.split(path.sep);

      if (pathParts.length >= 4) {
        const [version, lang, section, fileName] = pathParts;
        const restParts = pathParts.slice(2);

        // ファイル名から拡張子を除去（番号プレフィックスは保持）
        const fileSlug = fileName.replace(/\.mdx?$/, '');
        // 表示用のslugは番号プレフィックスを削除
        const displaySlug = fileSlug.replace(/^\d+-/, '');

        const contentFile: ContentFile = {
          slug: displaySlug,
          lang: lang as LocaleKey,
          version,
          section,
          fullPath: path.join('src', 'content', 'docs', filePath),
          url: buildDocumentPath(
            version,
            lang as LocaleKey,
            [...restParts.slice(0, -1), fileSlug],
            options
          ),
        };

        contentFiles.push(contentFile);
      }
    }
  } catch (error) {
    console.warn('コンテンツファイルの読み取りに失敗しました:', error);
  }

  return contentFiles;
}

/**
 * 指定された条件に一致する最初のコンテンツファイルを取得
 */
export async function findContent(
  lang: LocaleKey,
  version: string,
  section: string,
  slug?: string,
  options?: ContentOptions
): Promise<ContentFile | undefined> {
  const allContent = await getAvailableContent(options);

  return allContent.find(
    (content) =>
      content.lang === lang &&
      content.version === version &&
      content.section === section &&
      (slug ? content.slug === slug : true)
  );
}

/**
 * 指定された条件に一致するコンテンツファイルを全て取得
 */
export async function findAllContent(
  lang: LocaleKey,
  version: string,
  section?: string,
  options?: ContentOptions
): Promise<ContentFile[]> {
  const allContent = await getAvailableContent(options);

  return allContent.filter(
    (content) =>
      content.lang === lang &&
      content.version === version &&
      (section ? content.section === section : true)
  );
}

/**
 * コレクションから該当するドキュメントエントリを探す
 */
function findDocEntry(
  docs: CollectionEntry<'docs'>[],
  lang: LocaleKey,
  version: string,
  section: string,
  slug: string
): CollectionEntry<'docs'> | undefined {
  return docs.find((doc) => {
    const slugParts = doc.slug.split('/');
    return (
      slugParts[0] === version &&
      slugParts[1] === lang &&
      slugParts[2] === section &&
      slugParts[3]?.replace(/^\d+-/, '') === slug
    );
  });
}

/**
 * カード用のデフォルトコンテンツリンクを生成（存在するファイルのみ）
 */
export async function getDefaultCardLinks(
  lang: LocaleKey,
  version: string,
  baseUrl: string,
  options?: ContentOptions
): Promise<Array<{ title: string; href: string; slug: string }>> {
  const guideContent = await findAllContent(lang, version, 'guide', options);

  // デフォルトのカード項目（優先順位順）
  const defaultCards = [
    { slug: 'getting-started', title: 'docs.getting_started' },
    { slug: 'installation', title: 'docs.installation' },
    { slug: 'sidebar-auto-generation', title: 'docs.sidebar_generation' },
    { slug: 'icons-example', title: 'docs.icons_example' },
    { slug: 'extended-icons-example', title: 'docs.extended_icons_example' },
    { slug: 'tabs-example', title: 'docs.tabs_example' },
  ];

  const cardLinks: Array<{ title: string; href: string; slug: string }> = [];

  // 存在するファイルのみを含める
  for (const card of defaultCards) {
    const content = guideContent.find((c) => c.slug === card.slug);
    if (content) {
      cardLinks.push({
        title: card.title,
        href: `${baseUrl}${content.url}`,
        slug: card.slug,
      });
    }
  }

  return cardLinks;
}

/**
 * 現在のページに対応する他のバージョンのURLを取得
 * バージョン間でファイル構造が異なる場合に対応
 */
export async function getVersionedUrl(
  currentLang: LocaleKey,
  currentVersion: string,
  targetVersion: string,
  currentSlug: string, // guide/01-getting-started の形式
  baseUrl: string,
  options?: ContentOptions
): Promise<string | null> {
  const allContent = await getAvailableContent(options);

  // currentSlugを解析
  const slugParts = currentSlug.split('/');
  if (slugParts.length < 2) {
    return null;
  }

  const section = slugParts[0]; // "guide"
  const fileName = slugParts[1]; // "01-getting-started"
  const displaySlug = fileName.replace(/^\d+-/, ''); // "getting-started"

  // ターゲットバージョンで対応するページを探す
  // 1. 同じ表示用スラッグを持つファイルを探す
  const exactMatch = allContent.find(
    (content) =>
      content.lang === currentLang &&
      content.version === targetVersion &&
      content.section === section &&
      content.slug === displaySlug
  );

  if (exactMatch) {
    return `${baseUrl}${exactMatch.url}`;
  }

  // 2. 同じセクションで最初のファイルを探す（フォールバック）
  const sectionContent = allContent
    .filter(
      (content) =>
        content.lang === currentLang &&
        content.version === targetVersion &&
        content.section === section
    )
    .sort((a, b) => {
      // ファイル名の番号プレフィックスでソート
      const aNumber = parseInt((a.fullPath.match(/\/(\d+)-/) || ['', '999'])[1], 10);
      const bNumber = parseInt((b.fullPath.match(/\/(\d+)-/) || ['', '999'])[1], 10);
      return aNumber - bNumber;
    });

  if (sectionContent.length > 0) {
    return `${baseUrl}${sectionContent[0].url}`;
  }

  // 3. 最後の手段として、ターゲットバージョンの最初の利用可能なページを探す
  const anyContent = allContent
    .filter((content) => content.lang === currentLang && content.version === targetVersion)
    .sort((a, b) => {
      // セクション優先度とファイル番号でソート
      const sectionPriority: Record<string, number> = { guide: 0, api: 1, examples: 2 };
      const aPriority = sectionPriority[a.section] ?? 99;
      const bPriority = sectionPriority[b.section] ?? 99;

      if (aPriority !== bPriority) {
        return aPriority - bPriority;
      }

      const aNumber = parseInt((a.fullPath.match(/\/(\d+)-/) || ['', '999'])[1], 10);
      const bNumber = parseInt((b.fullPath.match(/\/(\d+)-/) || ['', '999'])[1], 10);
      return aNumber - bNumber;
    });

  if (anyContent.length > 0) {
    return `${baseUrl}${anyContent[0].url}`;
  }

  // どのファイルも見つからない場合はnullを返す
  return null;
}

/**
 * 実際のファイル構造に基づいてページネーションを生成
 */
export async function generateFileBasedPagination(
  lang: LocaleKey,
  version: string,
  section: string,
  currentSlug: string, // 例: "getting-started"
  baseUrl: string,
  options?: ContentOptions
): Promise<{ prev?: { title: string; url: string }; next?: { title: string; url: string } }> {
  const allContent = await getAvailableContent(options);

  // 同じ言語、バージョン、セクションのコンテンツを取得
  const sectionContent = allContent
    .filter(
      (content) =>
        content.lang === lang && content.version === version && content.section === section
    )
    .sort((a, b) => {
      // ファイル名の番号プレフィックスでソート
      const aNumber = parseInt((a.fullPath.match(/\/(\d+)-/) || ['', '999'])[1], 10);
      const bNumber = parseInt((b.fullPath.match(/\/(\d+)-/) || ['', '999'])[1], 10);
      return aNumber - bNumber;
    });

  // 現在のページのインデックスを見つける
  const currentIndex = sectionContent.findIndex((content) => content.slug === currentSlug);

  if (currentIndex === -1) {
    return {};
  }

  const result: { prev?: { title: string; url: string }; next?: { title: string; url: string } } =
    {};

  // 前のページ
  if (currentIndex > 0) {
    const prevContent = sectionContent[currentIndex - 1];
    const prevTitle =
      (await getDocumentTitle(lang, version, section, prevContent.slug, options)) ||
      prevContent.slug.replace(/-/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase());
    result.prev = {
      title: prevTitle,
      url: `${baseUrl}${prevContent.url}`,
    };
  }

  // 次のページ
  if (currentIndex < sectionContent.length - 1) {
    const nextContent = sectionContent[currentIndex + 1];
    const nextTitle =
      (await getDocumentTitle(lang, version, section, nextContent.slug, options)) ||
      nextContent.slug.replace(/-/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase());
    result.next = {
      title: nextTitle,
      url: `${baseUrl}${nextContent.url}`,
    };
  }

  return result;
}

/**
 * 指定されたパスのファイルが実際に存在するかチェック
 */
export async function checkFileExists(
  targetPath: string,
  options?: ContentOptions
): Promise<boolean> {
  const allContent = await getAvailableContent(options);
  return allContent.some((content) => targetPath.endsWith(content.url));
}

/**
 * MDXファイルの実際のタイトルを取得する
 */
export async function getDocumentTitle(
  lang: LocaleKey,
  version: string,
  section: string,
  slug: string,
  _options?: ContentOptions
): Promise<string | null> {
  try {
    const docs = await getCollection('docs');
    const targetDoc = findDocEntry(docs, lang, version, section, slug);

    return targetDoc?.data.title || null;
  } catch (error) {
    console.warn('Failed to get document title:', error);
    return null;
  }
}

/**
 * バージョン別のファイル構造を取得
 */
export async function getVersionFileStructure(
  lang: LocaleKey,
  options?: ContentOptions
): Promise<Record<string, ContentFile[]>> {
  const allContent = await getAvailableContent(options);
  const versionStructure: Record<string, ContentFile[]> = {};

  // 言語別にフィルタして、バージョンごとにグループ化
  const langContent = allContent.filter((content) => content.lang === lang);

  for (const content of langContent) {
    if (!versionStructure[content.version]) {
      versionStructure[content.version] = [];
    }
    versionStructure[content.version].push(content);
  }

  // 各バージョン内でソート（優先度順）
  for (const version of Object.keys(versionStructure)) {
    versionStructure[version].sort((a, b) => {
      // セクション優先度
      const sectionPriority: Record<string, number> = { guide: 0, api: 1, examples: 2, faq: 3 };
      const aPriority = sectionPriority[a.section] ?? 99;
      const bPriority = sectionPriority[b.section] ?? 99;

      if (aPriority !== bPriority) {
        return aPriority - bPriority;
      }

      // ファイル番号でソート
      const aNumber = parseInt((a.fullPath.match(/\/(\d+)-/) || ['', '999'])[1], 10);
      const bNumber = parseInt((b.fullPath.match(/\/(\d+)-/) || ['', '999'])[1], 10);
      return aNumber - bNumber;
    });
  }

  return versionStructure;
}

/**
 * バージョン間の対応ファイルを見つける（柔軟なマッチング）
 */
export async function findCorrespondingFile(
  currentLang: LocaleKey,
  currentVersion: string,
  targetVersion: string,
  currentSlug: string,
  baseUrl: string,
  options?: ContentOptions
): Promise<string> {
  const versionStructure = await getVersionFileStructure(currentLang, options);
  const targetFiles = versionStructure[targetVersion] || [];

  if (targetFiles.length === 0) {
    // ターゲットバージョンにファイルがない場合はバージョンのルートページへ
    const basePath = buildDocumentPath(targetVersion, currentLang, undefined, options);
    return `${baseUrl}${basePath}/`;
  }

  // currentSlugを解析
  const slugParts = currentSlug.split('/');
  const section = slugParts[0]; // "guide"
  const fileName = slugParts[1]; // "01-getting-started" など
  const displaySlug = fileName ? fileName.replace(/^\d+-/, '') : ''; // "getting-started"

  // 1. 完全一致：同じセクション・同じスラッグ
  const exactMatch = targetFiles.find(
    (file) => file.section === section && file.slug === displaySlug
  );
  if (exactMatch) {
    return `${baseUrl}${exactMatch.url}`;
  }

  // 2. セクション一致：同じセクション内の最初のファイル
  const sectionMatch = targetFiles.find((file) => file.section === section);
  if (sectionMatch) {
    return `${baseUrl}${sectionMatch.url}`;
  }

  // 3. スラッグ一致：異なるセクションでも同じスラッグ
  const slugMatch = targetFiles.find((file) => file.slug === displaySlug);
  if (slugMatch) {
    return `${baseUrl}${slugMatch.url}`;
  }

  // 4. 最終フォールバック：ターゲットバージョンの最初のファイル
  return `${baseUrl}${targetFiles[0].url}`;
}
