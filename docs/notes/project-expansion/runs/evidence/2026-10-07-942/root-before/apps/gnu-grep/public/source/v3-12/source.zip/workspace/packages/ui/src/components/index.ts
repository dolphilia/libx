// コンポーネントのエクスポート
export { default as Button } from './Button.astro';
export { default as Card } from './Card.astro';
export { default as ProjectCard } from './ProjectCard.astro';
export { default as Navigation } from './Navigation.astro';
export { default as GroupSidebar } from './GroupSidebar.astro';
export { default as Sidebar } from './Sidebar.astro';
export { default as SidebarPersister } from './SidebarPersister.astro';
export { default as SidebarRestorePoint } from './SidebarRestorePoint.astro';
export { default as SidebarResizer } from './SidebarResizer.astro';
export { default as Alert } from './Alert.astro';

// Starlightスタイルの新コンポーネント
export { default as ContentPanel } from './ContentPanel.astro';
export { default as TableOfContents } from './TableOfContents/TableOfContents.astro';
export { default as MobileTableOfContents } from './TableOfContents/MobileTableOfContents.astro';
export { default as TableOfContentsList } from './TableOfContents/TableOfContentsList.astro';
export { default as Pagination } from './Pagination.astro';

// 新しく追加したStarlightスタイルのコンポーネント
export { default as AnchorHeading } from './AnchorHeading.astro';
export { default as Banner } from './Banner.astro';
export { default as ContentNotice } from './ContentNotice.astro';
export { default as Hero } from './Hero.astro';
export { default as ThemeToggle } from './ThemeToggle.astro';
export { default as LanguageSelector } from './LanguageSelector.astro';
export { default as DocsHeaderFrame } from './DocsHeaderFrame.astro';
export { default as TwoColumnContent } from './TwoColumnContent.astro';

// 今回追加したStarlightスタイルのコンポーネント
export { default as LinkCard } from './LinkCard.astro';
export { default as CardGrid } from './CardGrid.astro';
export { Tabs, TabItem } from './Tabs';
export { Icon, Icons, type IconName } from './icons';
export { Dropdown, DropdownItem } from './Dropdown';

// 文書の出典・翻訳状態・ライセンス帰属
export { default as DocumentProvenance } from './DocumentProvenance.astro';
export { default as Search } from './Search.astro';
