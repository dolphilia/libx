---
title: "3.2 Character Classes and Bracket Expressions"
description: "Fixed GNU grep3.12 complete manual chapters1–4, with paired Japanese translation."
documentId: "gnu-grep:3.12:16-character-classes-bracket-expressions"
licenseSource: "gnu-grep-manual"
toc: {"maxLevel": 4}
documentContext: [{"kind": "source", "html": "<section class=\"gnu-grep-notices\"><h3>Libx GNU grep 3.12 Invocation, Regular Expressions and Usage — Chapters 1–4 / Libx GNU grep 3.12 起動・正規表現・使用例 — 第1〜4章</h3><p>Original authors: Alain Magloire et al. Original publisher: Free Software Foundation. Modification author and publisher: Libx.</p><p><code class=\"command\">grep</code> prints lines that contain a match for one or more patterns.\n</p><p>This manual is for version 3.12 of GNU Grep.\n</p><p>This manual is for <code class=\"command\">grep</code>, a pattern matching engine.\n</p><p>Copyright © 1999–2002, 2005, 2008–2025 Free Software Foundation,\nInc.\n</p><blockquote class=\"quotation\">\n<p>Permission is granted to copy, distribute and/or modify this document\nunder the terms of the GNU Free Documentation License, Version 1.3 or\nany later version published by the Free Software Foundation; with no\nInvariant Sections, with no Front-Cover Texts, and with no Back-Cover\nTexts.  A copy of the license is included in the section entitled\n“GNU Free Documentation License”.\n</p></blockquote><p>Copyright © 2026 Libx, for editing and independent Japanese translation. This modified guide is available under GNU Free Documentation License 1.3 or later, with no Invariant Sections, Front-Cover Texts, or Back-Cover Texts. No new cover texts or invariant sections have been added.</p><h3>History / 履歴</h3><p>Original: GNU Grep: Print lines that match patterns; version3.12; updated2January2025; author Alain Magloire et al.; publisher Free Software Foundation. Source: grep-3.12.tar.gz, SHA256 badda546dfc4b9d97e992e2c35f3b5c7f20522ffcbe2f01ba1e9cdcbe7644cdc.</p><p>2026: Libx GNU grep3.12 Invocation, Regular Expressions and Usage — Chapters1–4 / Libx GNU grep3.12 起動・正規表現・使用例 — 第1〜4章. Modification author and publisher: Libx. Static chapter-scoped HTML in editable Markdown and unofficial Japanese translation. Original copyright, permission and whole English license preserved. Modified6October2026.</p></section><details class=\"gnu-grep-license\"><summary>Original English GNU Free Documentation License / 原英語GFDL全文</summary><div class=\"section-level-extent\" id=\"GNU-Free-Documentation-License\">\n<h3 class=\"section\" id=\"GNU-Free-Documentation-License-1\"><span>7.1 GNU Free Documentation License<a class=\"copiable-link\" href=\"#GNU-Free-Documentation-License-1\"> ¶</a></span></h3>\n<div class=\"center\">Version 1.3, 3 November 2008\n</div>\n<div class=\"display\">\n<pre class=\"display-preformatted\">Copyright © 2000–2002, 2007–2008, 2023–2025 Free Software\nFoundation, Inc.\n<a class=\"uref\" href=\"https://fsf.org/\">https://fsf.org/</a>\n\nEveryone is permitted to copy and distribute verbatim copies\nof this license document, but changing it is not allowed.\n</pre></div>\n<ol class=\"enumerate\" start=\"0\">\n<li> PREAMBLE\n\n<p>The purpose of this License is to make a manual, textbook, or other\nfunctional and useful document <em class=\"dfn\">free</em> in the sense of freedom: to\nassure everyone the effective freedom to copy and redistribute it,\nwith or without modifying it, either commercially or noncommercially.\nSecondarily, this License preserves for the author and publisher a way\nto get credit for their work, while not being considered responsible\nfor modifications made by others.\n</p>\n<p>This License is a kind of “copyleft”, which means that derivative\nworks of the document must themselves be free in the same sense.  It\ncomplements the GNU General Public License, which is a copyleft\nlicense designed for free software.\n</p>\n<p>We have designed this License in order to use it for manuals for free\nsoftware, because free software needs free documentation: a free\nprogram should come with manuals providing the same freedoms that the\nsoftware does.  But this License is not limited to software manuals;\nit can be used for any textual work, regardless of subject matter or\nwhether it is published as a printed book.  We recommend this License\nprincipally for works whose purpose is instruction or reference.\n</p>\n</li><li> APPLICABILITY AND DEFINITIONS\n\n<p>This License applies to any manual or other work, in any medium, that\ncontains a notice placed by the copyright holder saying it can be\ndistributed under the terms of this License.  Such a notice grants a\nworld-wide, royalty-free license, unlimited in duration, to use that\nwork under the conditions stated herein.  The “Document”, below,\nrefers to any such manual or work.  Any member of the public is a\nlicensee, and is addressed as “you”.  You accept the license if you\ncopy, modify or distribute the work in a way requiring permission\nunder copyright law.\n</p>\n<p>A “Modified Version” of the Document means any work containing the\nDocument or a portion of it, either copied verbatim, or with\nmodifications and/or translated into another language.\n</p>\n<p>A “Secondary Section” is a named appendix or a front-matter section\nof the Document that deals exclusively with the relationship of the\npublishers or authors of the Document to the Document’s overall\nsubject (or to related matters) and contains nothing that could fall\ndirectly within that overall subject.  (Thus, if the Document is in\npart a textbook of mathematics, a Secondary Section may not explain\nany mathematics.)  The relationship could be a matter of historical\nconnection with the subject or with related matters, or of legal,\ncommercial, philosophical, ethical or political position regarding\nthem.\n</p>\n<p>The “Invariant Sections” are certain Secondary Sections whose titles\nare designated, as being those of Invariant Sections, in the notice\nthat says that the Document is released under this License.  If a\nsection does not fit the above definition of Secondary then it is not\nallowed to be designated as Invariant.  The Document may contain zero\nInvariant Sections.  If the Document does not identify any Invariant\nSections then there are none.\n</p>\n<p>The “Cover Texts” are certain short passages of text that are listed,\nas Front-Cover Texts or Back-Cover Texts, in the notice that says that\nthe Document is released under this License.  A Front-Cover Text may\nbe at most 5 words, and a Back-Cover Text may be at most 25 words.\n</p>\n<p>A “Transparent” copy of the Document means a machine-readable copy,\nrepresented in a format whose specification is available to the\ngeneral public, that is suitable for revising the document\nstraightforwardly with generic text editors or (for images composed of\npixels) generic paint programs or (for drawings) some widely available\ndrawing editor, and that is suitable for input to text formatters or\nfor automatic translation to a variety of formats suitable for input\nto text formatters.  A copy made in an otherwise Transparent file\nformat whose markup, or absence of markup, has been arranged to thwart\nor discourage subsequent modification by readers is not Transparent.\nAn image format is not Transparent if used for any substantial amount\nof text.  A copy that is not “Transparent” is called “Opaque”.\n</p>\n<p>Examples of suitable formats for Transparent copies include plain\nASCII without markup, Texinfo input format, LaTeX input\nformat, SGML or XML using a publicly available\nDTD, and standard-conforming simple HTML,\nPostScript or PDF designed for human modification.  Examples\nof transparent image formats include PNG, XCF and\nJPG.  Opaque formats include proprietary formats that can be\nread and edited only by proprietary word processors, SGML or\nXML for which the DTD and/or processing tools are\nnot generally available, and the machine-generated HTML,\nPostScript or PDF produced by some word processors for\noutput purposes only.\n</p>\n<p>The “Title Page” means, for a printed book, the title page itself,\nplus such following pages as are needed to hold, legibly, the material\nthis License requires to appear in the title page.  For works in\nformats which do not have any title page as such, “Title Page” means\nthe text near the most prominent appearance of the work’s title,\npreceding the beginning of the body of the text.\n</p>\n<p>The “publisher” means any person or entity that distributes copies\nof the Document to the public.\n</p>\n<p>A section “Entitled XYZ” means a named subunit of the Document whose\ntitle either is precisely XYZ or contains XYZ in parentheses following\ntext that translates XYZ in another language.  (Here XYZ stands for a\nspecific section name mentioned below, such as “Acknowledgements”,\n“Dedications”, “Endorsements”, or “History”.)  To “Preserve the Title”\nof such a section when you modify the Document means that it remains a\nsection “Entitled XYZ” according to this definition.\n</p>\n<p>The Document may include Warranty Disclaimers next to the notice which\nstates that this License applies to the Document.  These Warranty\nDisclaimers are considered to be included by reference in this\nLicense, but only as regards disclaiming warranties: any other\nimplication that these Warranty Disclaimers may have is void and has\nno effect on the meaning of this License.\n</p>\n</li><li> VERBATIM COPYING\n\n<p>You may copy and distribute the Document in any medium, either\ncommercially or noncommercially, provided that this License, the\ncopyright notices, and the license notice saying this License applies\nto the Document are reproduced in all copies, and that you add no other\nconditions whatsoever to those of this License.  You may not use\ntechnical measures to obstruct or control the reading or further\ncopying of the copies you make or distribute.  However, you may accept\ncompensation in exchange for copies.  If you distribute a large enough\nnumber of copies you must also follow the conditions in section 3.\n</p>\n<p>You may also lend copies, under the same conditions stated above, and\nyou may publicly display copies.\n</p>\n</li><li> COPYING IN QUANTITY\n\n<p>If you publish printed copies (or copies in media that commonly have\nprinted covers) of the Document, numbering more than 100, and the\nDocument’s license notice requires Cover Texts, you must enclose the\ncopies in covers that carry, clearly and legibly, all these Cover\nTexts: Front-Cover Texts on the front cover, and Back-Cover Texts on\nthe back cover.  Both covers must also clearly and legibly identify\nyou as the publisher of these copies.  The front cover must present\nthe full title with all words of the title equally prominent and\nvisible.  You may add other material on the covers in addition.\nCopying with changes limited to the covers, as long as they preserve\nthe title of the Document and satisfy these conditions, can be treated\nas verbatim copying in other respects.\n</p>\n<p>If the required texts for either cover are too voluminous to fit\nlegibly, you should put the first ones listed (as many as fit\nreasonably) on the actual cover, and continue the rest onto adjacent\npages.\n</p>\n<p>If you publish or distribute Opaque copies of the Document numbering\nmore than 100, you must either include a machine-readable Transparent\ncopy along with each Opaque copy, or state in or with each Opaque copy\na computer-network location from which the general network-using\npublic has access to download using public-standard network protocols\na complete Transparent copy of the Document, free of added material.\nIf you use the latter option, you must take reasonably prudent steps,\nwhen you begin distribution of Opaque copies in quantity, to ensure\nthat this Transparent copy will remain thus accessible at the stated\nlocation until at least one year after the last time you distribute an\nOpaque copy (directly or through your agents or retailers) of that\nedition to the public.\n</p>\n<p>It is requested, but not required, that you contact the authors of the\nDocument well before redistributing any large number of copies, to give\nthem a chance to provide you with an updated version of the Document.\n</p>\n</li><li> MODIFICATIONS\n\n<p>You may copy and distribute a Modified Version of the Document under\nthe conditions of sections 2 and 3 above, provided that you release\nthe Modified Version under precisely this License, with the Modified\nVersion filling the role of the Document, thus licensing distribution\nand modification of the Modified Version to whoever possesses a copy\nof it.  In addition, you must do these things in the Modified Version:\n</p>\n<ol class=\"enumerate\" start=\"1\" type=\"A\">\n<li> Use in the Title Page (and on the covers, if any) a title distinct\nfrom that of the Document, and from those of previous versions\n(which should, if there were any, be listed in the History section\nof the Document).  You may use the same title as a previous version\nif the original publisher of that version gives permission.\n\n</li><li> List on the Title Page, as authors, one or more persons or entities\nresponsible for authorship of the modifications in the Modified\nVersion, together with at least five of the principal authors of the\nDocument (all of its principal authors, if it has fewer than five),\nunless they release you from this requirement.\n\n</li><li> State on the Title page the name of the publisher of the\nModified Version, as the publisher.\n\n</li><li> Preserve all the copyright notices of the Document.\n\n</li><li> Add an appropriate copyright notice for your modifications\nadjacent to the other copyright notices.\n\n</li><li> Include, immediately after the copyright notices, a license notice\ngiving the public permission to use the Modified Version under the\nterms of this License, in the form shown in the Addendum below.\n\n</li><li> Preserve in that license notice the full lists of Invariant Sections\nand required Cover Texts given in the Document’s license notice.\n\n</li><li> Include an unaltered copy of this License.\n\n</li><li> Preserve the section Entitled “History”, Preserve its Title, and add\nto it an item stating at least the title, year, new authors, and\npublisher of the Modified Version as given on the Title Page.  If\nthere is no section Entitled “History” in the Document, create one\nstating the title, year, authors, and publisher of the Document as\ngiven on its Title Page, then add an item describing the Modified\nVersion as stated in the previous sentence.\n\n</li><li> Preserve the network location, if any, given in the Document for\npublic access to a Transparent copy of the Document, and likewise\nthe network locations given in the Document for previous versions\nit was based on.  These may be placed in the “History” section.\nYou may omit a network location for a work that was published at\nleast four years before the Document itself, or if the original\npublisher of the version it refers to gives permission.\n\n</li><li> For any section Entitled “Acknowledgements” or “Dedications”, Preserve\nthe Title of the section, and preserve in the section all the\nsubstance and tone of each of the contributor acknowledgements and/or\ndedications given therein.\n\n</li><li> Preserve all the Invariant Sections of the Document,\nunaltered in their text and in their titles.  Section numbers\nor the equivalent are not considered part of the section titles.\n\n</li><li> Delete any section Entitled “Endorsements”.  Such a section\nmay not be included in the Modified Version.\n\n</li><li> Do not retitle any existing section to be Entitled “Endorsements” or\nto conflict in title with any Invariant Section.\n\n</li><li> Preserve any Warranty Disclaimers.\n</li></ol>\n<p>If the Modified Version includes new front-matter sections or\nappendices that qualify as Secondary Sections and contain no material\ncopied from the Document, you may at your option designate some or all\nof these sections as invariant.  To do this, add their titles to the\nlist of Invariant Sections in the Modified Version’s license notice.\nThese titles must be distinct from any other section titles.\n</p>\n<p>You may add a section Entitled “Endorsements”, provided it contains\nnothing but endorsements of your Modified Version by various\nparties—for example, statements of peer review or that the text has\nbeen approved by an organization as the authoritative definition of a\nstandard.\n</p>\n<p>You may add a passage of up to five words as a Front-Cover Text, and a\npassage of up to 25 words as a Back-Cover Text, to the end of the list\nof Cover Texts in the Modified Version.  Only one passage of\nFront-Cover Text and one of Back-Cover Text may be added by (or\nthrough arrangements made by) any one entity.  If the Document already\nincludes a cover text for the same cover, previously added by you or\nby arrangement made by the same entity you are acting on behalf of,\nyou may not add another; but you may replace the old one, on explicit\npermission from the previous publisher that added the old one.\n</p>\n<p>The author(s) and publisher(s) of the Document do not by this License\ngive permission to use their names for publicity for or to assert or\nimply endorsement of any Modified Version.\n</p>\n</li><li> COMBINING DOCUMENTS\n\n<p>You may combine the Document with other documents released under this\nLicense, under the terms defined in section 4 above for modified\nversions, provided that you include in the combination all of the\nInvariant Sections of all of the original documents, unmodified, and\nlist them all as Invariant Sections of your combined work in its\nlicense notice, and that you preserve all their Warranty Disclaimers.\n</p>\n<p>The combined work need only contain one copy of this License, and\nmultiple identical Invariant Sections may be replaced with a single\ncopy.  If there are multiple Invariant Sections with the same name but\ndifferent contents, make the title of each such section unique by\nadding at the end of it, in parentheses, the name of the original\nauthor or publisher of that section if known, or else a unique number.\nMake the same adjustment to the section titles in the list of\nInvariant Sections in the license notice of the combined work.\n</p>\n<p>In the combination, you must combine any sections Entitled “History”\nin the various original documents, forming one section Entitled\n“History”; likewise combine any sections Entitled “Acknowledgements”,\nand any sections Entitled “Dedications”.  You must delete all\nsections Entitled “Endorsements.”\n</p>\n</li><li> COLLECTIONS OF DOCUMENTS\n\n<p>You may make a collection consisting of the Document and other documents\nreleased under this License, and replace the individual copies of this\nLicense in the various documents with a single copy that is included in\nthe collection, provided that you follow the rules of this License for\nverbatim copying of each of the documents in all other respects.\n</p>\n<p>You may extract a single document from such a collection, and distribute\nit individually under this License, provided you insert a copy of this\nLicense into the extracted document, and follow this License in all\nother respects regarding verbatim copying of that document.\n</p>\n</li><li> AGGREGATION WITH INDEPENDENT WORKS\n\n<p>A compilation of the Document or its derivatives with other separate\nand independent documents or works, in or on a volume of a storage or\ndistribution medium, is called an “aggregate” if the copyright\nresulting from the compilation is not used to limit the legal rights\nof the compilation’s users beyond what the individual works permit.\nWhen the Document is included in an aggregate, this License does not\napply to the other works in the aggregate which are not themselves\nderivative works of the Document.\n</p>\n<p>If the Cover Text requirement of section 3 is applicable to these\ncopies of the Document, then if the Document is less than one half of\nthe entire aggregate, the Document’s Cover Texts may be placed on\ncovers that bracket the Document within the aggregate, or the\nelectronic equivalent of covers if the Document is in electronic form.\nOtherwise they must appear on printed covers that bracket the whole\naggregate.\n</p>\n</li><li> TRANSLATION\n\n<p>Translation is considered a kind of modification, so you may\ndistribute translations of the Document under the terms of section 4.\nReplacing Invariant Sections with translations requires special\npermission from their copyright holders, but you may include\ntranslations of some or all Invariant Sections in addition to the\noriginal versions of these Invariant Sections.  You may include a\ntranslation of this License, and all the license notices in the\nDocument, and any Warranty Disclaimers, provided that you also include\nthe original English version of this License and the original versions\nof those notices and disclaimers.  In case of a disagreement between\nthe translation and the original version of this License or a notice\nor disclaimer, the original version will prevail.\n</p>\n<p>If a section in the Document is Entitled “Acknowledgements”,\n“Dedications”, or “History”, the requirement (section 4) to Preserve\nits Title (section 1) will typically require changing the actual\ntitle.\n</p>\n</li><li> TERMINATION\n\n<p>You may not copy, modify, sublicense, or distribute the Document\nexcept as expressly provided under this License.  Any attempt\notherwise to copy, modify, sublicense, or distribute it is void, and\nwill automatically terminate your rights under this License.\n</p>\n<p>However, if you cease all violation of this License, then your license\nfrom a particular copyright holder is reinstated (a) provisionally,\nunless and until the copyright holder explicitly and finally\nterminates your license, and (b) permanently, if the copyright holder\nfails to notify you of the violation by some reasonable means prior to\n60 days after the cessation.\n</p>\n<p>Moreover, your license from a particular copyright holder is\nreinstated permanently if the copyright holder notifies you of the\nviolation by some reasonable means, this is the first time you have\nreceived notice of violation of this License (for any work) from that\ncopyright holder, and you cure the violation prior to 30 days after\nyour receipt of the notice.\n</p>\n<p>Termination of your rights under this section does not terminate the\nlicenses of parties who have received copies or rights from you under\nthis License.  If your rights have been terminated and not permanently\nreinstated, receipt of a copy of some or all of the same material does\nnot give you any rights to use it.\n</p>\n</li><li> FUTURE REVISIONS OF THIS LICENSE\n\n<p>The Free Software Foundation may publish new, revised versions\nof the GNU Free Documentation License from time to time.  Such new\nversions will be similar in spirit to the present version, but may\ndiffer in detail to address new problems or concerns.  See\n<a class=\"uref\" href=\"https://www.gnu.org/licenses/\">https://www.gnu.org/licenses/</a>.\n</p>\n<p>Each version of the License is given a distinguishing version number.\nIf the Document specifies that a particular numbered version of this\nLicense “or any later version” applies to it, you have the option of\nfollowing the terms and conditions either of that specified version or\nof any later version that has been published (not as a draft) by the\nFree Software Foundation.  If the Document does not specify a version\nnumber of this License, you may choose any version ever published (not\nas a draft) by the Free Software Foundation.  If the Document\nspecifies that a proxy can decide which future versions of this\nLicense can be used, that proxy’s public statement of acceptance of a\nversion permanently authorizes you to choose that version for the\nDocument.\n</p>\n</li><li> RELICENSING\n\n<p>“Massive Multiauthor Collaboration Site” (or “MMC Site”) means any\nWorld Wide Web server that publishes copyrightable works and also\nprovides prominent facilities for anybody to edit those works.  A\npublic wiki that anybody can edit is an example of such a server.  A\n“Massive Multiauthor Collaboration” (or “MMC”) contained in the\nsite means any set of copyrightable works thus published on the MMC\nsite.\n</p>\n<p>“CC-BY-SA” means the Creative Commons Attribution-Share Alike 3.0\nlicense published by Creative Commons Corporation, a not-for-profit\ncorporation with a principal place of business in San Francisco,\nCalifornia, as well as future copyleft versions of that license\npublished by that same organization.\n</p>\n<p>“Incorporate” means to publish or republish a Document, in whole or\nin part, as part of another Document.\n</p>\n<p>An MMC is “eligible for relicensing” if it is licensed under this\nLicense, and if all works that were first published under this License\nsomewhere other than this MMC, and subsequently incorporated in whole\nor in part into the MMC, (1) had no cover texts or invariant sections,\nand (2) were thus incorporated prior to November 1, 2008.\n</p>\n<p>The operator of an MMC Site may republish an MMC contained in the site\nunder CC-BY-SA on the same site at any time before August 1, 2009,\nprovided the MMC is eligible for relicensing.\n</p>\n</li></ol>\n<h3 class=\"heading\" id=\"ADDENDUM_003a-How-to-use-this-License-for-your-documents\"><span>ADDENDUM: How to use this License for your documents<a class=\"copiable-link\" href=\"#ADDENDUM_003a-How-to-use-this-License-for-your-documents\"> ¶</a></span></h3>\n<p>To use this License in a document you have written, include a copy of\nthe License in the document and put the following copyright and\nlicense notices just after the title page:\n</p>\n<div class=\"example smallexample\">\n<div class=\"group\"><pre class=\"example-preformatted\">  Copyright (C)  <var class=\"var\">year</var>  <var class=\"var\">your name</var>.\n  Permission is granted to copy, distribute and/or modify this document\n  under the terms of the GNU Free Documentation License, Version 1.3\n  or any later version published by the Free Software Foundation;\n  with no Invariant Sections, no Front-Cover Texts, and no Back-Cover\n  Texts.  A copy of the license is included in the section entitled ``GNU\n  Free Documentation License''.\n</pre></div></div>\n<p>If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts,\nreplace the “with…Texts.” line with this:\n</p>\n<div class=\"example smallexample\">\n<div class=\"group\"><pre class=\"example-preformatted\">    with the Invariant Sections being <var class=\"var\">list their titles</var>, with\n    the Front-Cover Texts being <var class=\"var\">list</var>, and with the Back-Cover Texts\n    being <var class=\"var\">list</var>.\n</pre></div></div>\n<p>If you have Invariant Sections without Cover Texts, or some other\ncombination of the three, merge those two alternatives to suit the\nsituation.\n</p>\n<p>If your document contains nontrivial examples of program code, we\nrecommend releasing these examples in parallel under your choice of\nfree software license, such as the GNU General Public License,\nto permit their use in free software.\n</p>\n<hr/>\n</div></details>"}]
---

<div class="gnu-grep-original-content" id="Character-Classes-and-Bracket-Expressions">
<h3 class="section" id="Character-Classes-and-Bracket-Expressions-1"><span>3.2 Character Classes and Bracket Expressions</span></h3>
<a class="index-entry-id" id="index-bracket-expression"></a>
<a class="index-entry-id" id="index-character-class"></a>
<p>A <em class="dfn">bracket expression</em> is a list of characters enclosed by ‘<samp class="samp">[</samp>’ and
‘<samp class="samp">]</samp>’.
It matches any single character in that list.
If the first character of the list is the caret ‘<samp class="samp">^</samp>’,
then it matches any character <strong class="strong">not</strong> in the list,
and it is unspecified whether it matches an encoding error.
For example, the regular expression
‘<samp class="samp">[0123456789]</samp>’ matches any single digit,
whereas ‘<samp class="samp">[^()]</samp>’ matches any single character that is not
an opening or closing parenthesis, and might or might not match an
encoding error.
</p>
<a class="index-entry-id" id="index-range-expression"></a>
<p>Within a bracket expression, a <em class="dfn">range expression</em> consists of two
characters separated by a hyphen.
In the default C locale, it matches any single character that appears
between the two characters in ASCII order, inclusive.
For example, ‘<samp class="samp">[a-d]</samp>’ is equivalent to ‘<samp class="samp">[abcd]</samp>’.
In other locales the behavior is unspecified:
‘<samp class="samp">[a-d]</samp>’ might be equivalent to
‘<samp class="samp">[abcd]</samp>’ or ‘<samp class="samp">[aBbCcDd]</samp>’ or some other bracket expression,
or it might fail to match any character, or the set of
characters that it matches might be erratic, or it might be invalid.
To obtain the traditional interpretation
of bracket expressions, you can use the ‘<samp class="samp">C</samp>’ locale by setting the
<code class="env">LC_ALL</code> environment variable to the value ‘<samp class="samp">C</samp>’.
</p>
<p>Finally, certain named classes of characters are predefined within
bracket expressions, as follows.
Their interpretation depends on the <code class="env">LC_CTYPE</code> locale;
for example, ‘<samp class="samp">[[:alnum:]]</samp>’ means the character class of numbers and letters
in the current locale.
</p>
<a class="index-entry-id" id="index-classes-of-characters"></a>
<a class="index-entry-id" id="index-character-classes"></a>
<dl class="table">
<dt><a class="index-entry-id" id="index-alphanumeric-characters"></a>
<a id="index-alnum-character-class"></a><span>‘<samp class="samp">[:alnum:]</samp>’</span></dt>
<dd><p>Alphanumeric characters:
‘<samp class="samp">[:alpha:]</samp>’ and ‘<samp class="samp">[:digit:]</samp>’; in the ‘<samp class="samp">C</samp>’ locale and ASCII
character encoding, this is the same as ‘<samp class="samp">[0-9A-Za-z]</samp>’.
</p>
</dd>
<dt><a class="index-entry-id" id="index-alphabetic-characters"></a>
<a id="index-alpha-character-class"></a><span>‘<samp class="samp">[:alpha:]</samp>’</span></dt>
<dd><p>Alphabetic characters:
‘<samp class="samp">[:lower:]</samp>’ and ‘<samp class="samp">[:upper:]</samp>’; in the ‘<samp class="samp">C</samp>’ locale and ASCII
character encoding, this is the same as ‘<samp class="samp">[A-Za-z]</samp>’.
</p>
</dd>
<dt><a class="index-entry-id" id="index-blank-characters"></a>
<a id="index-blank-character-class"></a><span>‘<samp class="samp">[:blank:]</samp>’</span></dt>
<dd><p>Blank characters:
space and tab.
</p>
</dd>
<dt><a class="index-entry-id" id="index-control-characters"></a>
<a id="index-cntrl-character-class"></a><span>‘<samp class="samp">[:cntrl:]</samp>’</span></dt>
<dd><p>Control characters.
In ASCII, these characters have octal codes 000
through 037, and 177 (DEL).
In other character sets, these are
the equivalent characters, if any.
</p>
</dd>
<dt><a class="index-entry-id" id="index-digit-characters"></a>
<a class="index-entry-id" id="index-numeric-characters"></a>
<a id="index-digit-character-class"></a><span>‘<samp class="samp">[:digit:]</samp>’</span></dt>
<dd><p>Digits: <code class="code">0 1 2 3 4 5 6 7 8 9</code>.
</p>
</dd>
<dt><a class="index-entry-id" id="index-graphic-characters"></a>
<a id="index-graph-character-class"></a><span>‘<samp class="samp">[:graph:]</samp>’</span></dt>
<dd><p>Graphical characters:
‘<samp class="samp">[:alnum:]</samp>’ and ‘<samp class="samp">[:punct:]</samp>’.
</p>
</dd>
<dt><a class="index-entry-id" id="index-lower_002dcase-letters"></a>
<a id="index-lower-character-class"></a><span>‘<samp class="samp">[:lower:]</samp>’</span></dt>
<dd><p>Lower-case letters; in the ‘<samp class="samp">C</samp>’ locale and ASCII character
encoding, this is
<code class="code">a b c d e f g h i j k l m n o p q r s t u v w x y z</code>.
</p>
</dd>
<dt><a class="index-entry-id" id="index-printable-characters"></a>
<a id="index-print-character-class"></a><span>‘<samp class="samp">[:print:]</samp>’</span></dt>
<dd><p>Printable characters:
‘<samp class="samp">[:alnum:]</samp>’, ‘<samp class="samp">[:punct:]</samp>’, and space.
</p>
</dd>
<dt><a class="index-entry-id" id="index-punctuation-characters"></a>
<a id="index-punct-character-class"></a><span>‘<samp class="samp">[:punct:]</samp>’</span></dt>
<dd><p>Punctuation characters; in the ‘<samp class="samp">C</samp>’ locale and ASCII character
encoding, this is
<code class="code">! " # $ % &amp; ' ( ) * + , - . / : ; &lt; = &gt; ? @ [ \ ] ^ _ ` { | } ~</code>.
</p>
</dd>
<dt><a class="index-entry-id" id="index-space-characters"></a>
<a class="index-entry-id" id="index-whitespace-characters"></a>
<a id="index-space-character-class"></a><span>‘<samp class="samp">[:space:]</samp>’</span></dt>
<dd><p>Space characters: in the ‘<samp class="samp">C</samp>’ locale, this is
tab, newline, vertical tab, form feed, carriage return, and space.
See <a class="xref" href="/docs/gnu-grep/v3-12/en/01-guide/24-usage/#Usage">Usage</a>, for more discussion of matching newlines.
</p>
</dd>
<dt><a class="index-entry-id" id="index-upper_002dcase-letters"></a>
<a id="index-upper-character-class"></a><span>‘<samp class="samp">[:upper:]</samp>’</span></dt>
<dd><p>Upper-case letters: in the ‘<samp class="samp">C</samp>’ locale and ASCII character
encoding, this is
<code class="code">A B C D E F G H I J K L M N O P Q R S T U V W X Y Z</code>.
</p>
</dd>
<dt><a class="index-entry-id" id="index-xdigit-class"></a>
<a class="index-entry-id" id="index-hexadecimal-digits"></a>
<a id="index-xdigit-character-class"></a><span>‘<samp class="samp">[:xdigit:]</samp>’</span></dt>
<dd><p>Hexadecimal digits:
<code class="code">0 1 2 3 4 5 6 7 8 9 A B C D E F a b c d e f</code>.
</p>
</dd>
</dl>
<p>Note that the brackets in these class names are
part of the symbolic names, and must be included in addition to
the brackets delimiting the bracket expression.
</p>
<p>If you mistakenly omit the outer brackets, and search for say, ‘<samp class="samp">[:upper:]</samp>’,
GNU <code class="command">grep</code> prints a diagnostic and exits with status 2, on
the assumption that you did not intend to search for the
regular expression ‘<samp class="samp">[:epru]</samp>’.
</p>
<p>Special characters lose their special meaning inside bracket expressions.
</p>
<dl class="table">
<dt>‘<samp class="samp">]</samp>’</dt>
<dd><p>ends the bracket expression if it’s not the first list item.
So, if you want to make the ‘<samp class="samp">]</samp>’ character a list item,
you must put it first.
</p>
</dd>
<dt>‘<samp class="samp">[.</samp>’</dt>
<dd><p>represents the open collating symbol.
</p>
</dd>
<dt>‘<samp class="samp">.]</samp>’</dt>
<dd><p>represents the close collating symbol.
</p>
</dd>
<dt>‘<samp class="samp">[=</samp>’</dt>
<dd><p>represents the open equivalence class.
</p>
</dd>
<dt>‘<samp class="samp">=]</samp>’</dt>
<dd><p>represents the close equivalence class.
</p>
</dd>
<dt>‘<samp class="samp">[:</samp>’</dt>
<dd><p>represents the open character class symbol, and should be followed by a
valid character class name.
</p>
</dd>
<dt>‘<samp class="samp">:]</samp>’</dt>
<dd><p>represents the close character class symbol.
</p>
</dd>
<dt>‘<samp class="samp">-</samp>’</dt>
<dd><p>represents the range if it’s not first or last in a list or the ending point
of a range.  To make the ‘<samp class="samp">-</samp>’ a list item, it is best to put it last.
</p>
</dd>
<dt>‘<samp class="samp">^</samp>’</dt>
<dd><p>represents the characters not in the list.
If you want to make the ‘<samp class="samp">^</samp>’
character a list item, place it anywhere but first.
</p>
</dd>
</dl>
<hr/>
</div>
