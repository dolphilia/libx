import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const require = createRequire(root + '/package.json');
const { parse, serializeOuter } = require('parse5');
const { unified } = require('unified'),
  remarkParse = require('remark-parse').default,
  remarkGfm = require('remark-gfm').default;
const note = 'docs/notes/document-import/xxhash/v0-8-4',
  app = 'apps/xxhash',
  abs = (p) => path.join(root, p),
  sha = (s) => createHash('sha256').update(s).digest('hex');
const read = (p) => JSON.parse(fs.readFileSync(abs(p))),
  map = read(note + '/CONTENT_MAP.json'),
  manifest = read(note + '/SOURCE_MANIFEST.json'),
  design = read(note + '/LICENSE_APPLICATION_DESIGN.json'),
  editorial = read(note + '/EDITORIAL_NOTES.en.json');
const walk = (n) => [n, ...(n.childNodes ?? []).flatMap(walk)],
  attr = (n, k) => n.attrs?.find((a) => a.name === k)?.value,
  text = (n) => n.value ?? (n.childNodes ?? []).map(text).join('');
const astWalk = (n) => [n, ...(n.children ?? []).flatMap(astWalk)];
const base = '/docs/xxhash/v0-8-4/en/',
  sourceBase = '/docs/xxhash/source/v0-8-4/',
  fixed = 'https://github.com/Cyan4973/xxHash/blob/' + manifest.commit + '/';
const bySource = new Map(map.items.map((i) => [i.sourcePath, i])),
  apiByFile = new Map(
    map.items
      .filter((i) => i.sourcePath.startsWith('doxygen/'))
      .map((i) => [path.posix.basename(i.sourcePath), i])
  );
function local(url, doc) {
  if (!url || url.startsWith('#') || url.startsWith('/') || /^[a-z]+:/i.test(url)) return url;
  const [p, fragment] = url.split('#'),
    resolved = path.posix.normalize(path.posix.join(path.posix.dirname(doc), p));
  const mapped =
    resolved === 'xxhash.h' ? bySource.get('doxygen/html/xxhash_8h.html') : bySource.get(resolved);
  const target = mapped
    ? base + mapped.slug + '/'
    : fs.existsSync(abs(note + '/sources/' + resolved)) &&
        fs.statSync(abs(note + '/sources/' + resolved)).isFile()
      ? sourceBase + resolved + '.txt'
      : 'https://github.com/Cyan4973/xxHash/tree/' + manifest.commit + '/' + resolved;
  return target + (fragment ? '#' + fragment : '');
}
function mdLinks(raw, doc) {
  const changes = [];
  for (const n of astWalk(unified().use(remarkParse).use(remarkGfm).parse(raw)).filter(
    (n) => ['link', 'image', 'definition'].includes(n.type) && n.url
  )) {
    const target = local(n.url, doc);
    if (target === n.url) continue;
    const chunk = raw.slice(n.position.start.offset, n.position.end.offset),
      index = chunk.lastIndexOf(n.url);
    assert(index >= 0);
    changes.push({
      start: n.position.start.offset + index,
      end: n.position.start.offset + index + n.url.length,
      from: n.url,
      to: target,
    });
  }
  for (const r of [...changes].sort((a, b) => b.start - a.start))
    raw = raw.slice(0, r.start) + r.to + raw.slice(r.end);
  return { body: raw, changes };
}
function licenseId(doc) {
  if (doc.startsWith('doxygen/')) return 'xxhash-api';
  if (doc.startsWith('cli/')) return 'xxhash-cli';
  if (doc.startsWith('build/make/')) return 'xxhash-make';
  if (doc.startsWith('build/cmake/')) return 'xxhash-cmake';
  if (doc.startsWith('tests/collisions/')) return 'xxhash-collisions';
  if (doc === 'doc/xxhash_spec.md') return 'xxhash-spec';
  return 'xxhash-library';
}
function provenance(item) {
  const def = design.documents.find((d) => d.sourcePath === item.sourcePath);
  let source = item.sourcePath.startsWith('doxygen/') ? 'xxhash.h' : item.sourcePath;
  const notices = def?.notices ?? ['api-header'];
  const annotation =
    def?.decision === 'explicit-document-conditions'
      ? 'Unofficial presentation. The original document explicitly permits translations and compilations subject to its preserved notice.'
      : 'No documentation-specific license statement was found in the recorded checks. Under the user-approved operating policy, the software component’s ' +
        (def?.license ?? 'BSD-2-Clause') +
        ' license is applied to this documentation with this annotation. This is an operational decision, not a newly obtained permission.';
  const sourceLinks = item.sourcePath.startsWith('doxygen/')
    ? 'Generated from the fixed public [Doxyfile](' +
      fixed +
      'Doxyfile) using its `xxhash.h` and `xxh_x86dispatch.c` file patterns.\n\n' +
      ['xxhash.h', 'xxh_x86dispatch.c']
        .map(
          (file) =>
            '[' +
            file +
            ' — fixed source](' +
            fixed +
            file +
            ') · [' +
            file +
            ' — original text download](' +
            sourceBase +
            file +
            '.txt)'
        )
        .join('\n\n')
    : '[Fixed original source](' +
      fixed +
      source +
      ') · [Original text download](' +
      sourceBase +
      source +
      '.txt)';
  return (
    '\n\n## Source and notices\n\n' +
    annotation +
    '\n\nFixed software version: **0.8.4**. Source commit: `' +
    manifest.commit +
    '`. This is an unofficial presentation; formatting, internal links and clearly marked editorial notes are Libx changes. The Japanese translation is provided separately when completed.\n\n' +
    notices.map((id) => '[' + id + '](' + base + '03-notices/' + id + '/)').join(' · ') +
    '\n\n' +
    sourceLinks +
    '\n' +
    (item.sourcePath === 'README.md'
      ? '\nThe original graph and CI/package badges retain their external URLs. Their current display is not fixed to the source snapshot; Libx does not redistribute those image files.\n'
      : '')
  );
}
export function generate({ check = false } = {}) {
  const emit = (file, content) => {
    if (check)
      assert.equal(
        fs.readFileSync(file, 'utf8'),
        content,
        'Canonical regeneration differs: ' + file
      );
    else {
      fs.mkdirSync(path.dirname(file), { recursive: true });
      fs.writeFileSync(file, content);
    }
  };
  for (const f of manifest.files) assert.equal(sha(fs.readFileSync(abs(f.path))), f.sha256, f.path);
  const records = [],
    headingMap = {};
  for (const item of map.items) {
    const raw = fs.readFileSync(abs(item.source.path), 'utf8');
    assert.equal(sha(raw), item.source.sha256);
    let body,
      title = item.sourcePath,
      changes = [],
      repairs = [],
      syntaxRepairs = [];
    const isApi = item.sourcePath.startsWith('doxygen/');
    if (isApi) {
      const ns = walk(parse(raw)),
        content = ns.find((n) => (attr(n, 'class') ?? '').split(/\s+/).includes('contents'));
      assert(content);
      const beforeText = text(content);
      title = text(ns.find((n) => (attr(n, 'class') ?? '').split(/\s+/).includes('title')) ?? {});
      if (!title.trim())
        title = text(ns.find((n) => n.tagName === 'title') ?? {})
          .replace(/^xxHash:\s*/, '')
          .trim();
      assert(title.trim(), item.sourcePath + ' empty title');
      for (const n of walk(content)) {
        const h = attr(n, 'href');
        if (!h || /^(?:https?:|mailto:|javascript:)/.test(h)) continue;
        const [file, anchor] = h.split('#');
        if (file && apiByFile.has(file)) {
          const target = base + apiByFile.get(file).slug + '/' + (anchor ? '#' + anchor : '');
          n.attrs.find((a) => a.name === 'href').value = target;
          changes.push({ from: h, to: target });
        }
      }
      const all = walk(content),
        missing = [
          ...new Set(all.map((n) => attr(n, 'href')).filter((h) => h?.startsWith('#index_'))),
        ].filter(
          (h) => !all.some((n) => attr(n, 'id') === h.slice(1) || attr(n, 'name') === h.slice(1))
        );
      for (const h of missing) {
        const letter = h.slice(-1),
          li = all.find(
            (n) => n.tagName === 'li' && text(n).trim().toLowerCase().startsWith(letter)
          );
        assert(li);
        assert(!attr(li, 'id'));
        li.attrs.push({ name: 'id', value: h.slice(1) });
        repairs.push({ href: h, targetText: text(li) });
      }
      content.attrs.find((a) => a.name === 'class').value += ' xxhash-api';
      assert.equal(text(content), beforeText);
      const ids = new Set(
          walk(content)
            .map((n) => attr(n, 'id'))
            .filter(Boolean)
        ),
        headings = [];
      for (const n of walk(content).filter((n) => /^h[1-6]$/.test(n.tagName ?? ''))) {
        const slug =
          attr(n, 'id') ??
          walk(n)
            .map((x) => attr(x, 'id'))
            .find(Boolean) ??
          walk(n)
            .map((x) => attr(x, 'href'))
            .find((h) => h?.startsWith('#'))
            ?.slice(1);
        assert(slug && ids.has(slug));
        headings.push({
          depth: Number(n.tagName.slice(1)),
          slug,
          text: text(n)
            .replace(/^\s*◆\s*/, '')
            .replace(/\s+/g, ' ')
            .trim(),
        });
      }
      assert.equal(new Set(headings.map((h) => h.slug)).size, headings.length);
      headingMap['v0-8-4/en/' + item.slug] = headings;
      body =
        (editorial[item.slug] ?? '') +
        serializeOuter(content).replaceAll('\n', '&#10;') +
        provenance(item);
    } else if (item.role === 'whole-original-notice') {
      const def = design.originalNotices.find((n) => 'original-notice/' + n.id === item.sourcePath);
      assert(def);
      title = def.id + ' — original notice';
      const source = def.source.path.split('/sources/')[1];
      body =
        '# ' +
        def.id +
        '\n\nOriginal notice retained verbatim.\n\n```text\n' +
        raw +
        '\n```\n\n[Fixed original source](' +
        fixed +
        source +
        ')\n' +
        (def.id === 'cmake-header'
          ? '\n[CC0 1.0 original conditions](https://creativecommons.org/publicdomain/zero/1.0/legalcode.en)\n'
          : '');
    } else {
      const converted = mdLinks(raw, item.sourcePath);
      body = converted.body;
      changes = converted.changes;
      if (item.sourcePath === 'cli/xxhsum.1.md') {
        assert(body.includes('  <ITERATIONS> specifies'));
        body = body.replace('  <ITERATIONS> specifies', '  &lt;ITERATIONS&gt; specifies');
        syntaxRepairs.push({
          from: '  <ITERATIONS> specifies',
          to: '  &lt;ITERATIONS&gt; specifies',
          reason: 'Original angle-bracket argument placeholder is text, not an HTML element.',
        });
      }
      body += provenance(item);
    }
    const out =
      '---\ntitle: ' +
      JSON.stringify(title) +
      '\nlicenseSource: ' +
      JSON.stringify(
        licenseId(
          item.role === 'whole-original-notice'
            ? (design.originalNotices
                .find((n) => 'original-notice/' + n.id === item.sourcePath)
                ?.source.path.split('/sources/')[1] ?? 'LICENSE')
            : item.sourcePath
        )
      ) +
      '\n---\n\n' +
      body +
      '\n';
    emit(abs(item.canonical), out);
    records.push({
      sourcePath: item.sourcePath,
      sourceSHA256: item.source.sha256,
      canonical: item.canonical,
      canonicalSHA256: sha(out),
      role: item.role,
      linkChanges: changes,
      indexAliasRepairs: repairs,
      syntaxRepairs,
    });
  }
  for (const f of manifest.files.filter((f) => f.path.startsWith(note + '/sources/'))) {
    const rel = f.path.slice((note + '/sources/').length),
      dest = abs(app + '/public/source/v0-8-4/' + rel + '.txt');
    if (!check) {
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.copyFileSync(abs(f.path), dest);
    }
    assert.equal(sha(fs.readFileSync(dest)), f.sha256);
  }
  emit(abs(app + '/src/data/xxhash-api-headings.json'), JSON.stringify(headingMap, null, 2) + '\n');
  emit(
    abs(note + '/CANONICAL_GENERATION.json'),
    JSON.stringify(
      {
        version: '0.8.4',
        commit: manifest.commit,
        method:
          'Fixed whole-source conversion; original bodies preserved, links and index aliases explicit; editorial additions separate. Not a full content review.',
        records,
        apiPages: Object.keys(headingMap).length,
        headingCount: Object.values(headingMap).flat().length,
      },
      null,
      2
    ) + '\n'
  );
  return records;
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href)
  console.log({ canonicalPages: generate({ check: process.argv.includes('--check') }).length });
