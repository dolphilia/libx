import fs from 'node:fs';
import assert from 'node:assert/strict';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
const w = path.resolve(fileURLToPath(new URL('../../../', import.meta.url))),
  app = w + '/apps/gperf',
  req = createRequire(w + '/package.json'),
  parse = req('parse5'),
  note = w + '/docs/notes/document-import/gperf/3.3',
  outArg = process.argv.find((x) => x.startsWith('--output='));
const walk = (n) => [n, ...(n.childNodes || []).flatMap(walk)],
  text = (n) => n.value ?? (n.childNodes || []).map(text).join(''),
  attr = (n, k) => n.attrs?.find((a) => a.name === k)?.value,
  sha = (s) => crypto.createHash('sha256').update(s).digest('hex'),
  norm = (s) => s.replace(/\s+/g, ' ').trim(),
  allFiles = (p) =>
    fs
      .readdirSync(p, { withFileTypes: true })
      .flatMap((x) => (x.isDirectory() ? allFiles(path.join(p, x.name)) : [path.join(p, x.name)])),
  source = fs.readFileSync(note + '/sources/gperf-3.3/doc/gperf.html', 'utf8'),
  gplStart = source.indexOf('<H1><A NAME="SEC1"'),
  gplEnd = source.indexOf('<H1><A NAME="SEC2"'),
  gpl = source.slice(gplStart, gplEnd),
  body = source.slice(source.indexOf('<BODY>') + 6, source.indexOf('</BODY>')),
  pos = body.indexOf(gpl),
  notice = body.slice(body.indexOf('<P>\nCopyright (C) 1989-2024'), pos),
  fix = (s) => s.replace(/HREF="gperf\.html#/g, 'HREF="#'),
  expectedEN = fix(body.slice(0, pos)) + gpl + fix(body.slice(pos + gpl.length)),
  pages = [];
for (const p of allFiles(app + '/src/content/docs/v3-3').filter((x) => x.endsWith('.md'))) {
  const md = fs.readFileSync(p, 'utf8'),
    rel = p.slice((app + '/src/content/docs/').length).replace(/\.md$/, ''),
    dst = app + '/dist/' + rel + '/index.html',
    html = fs.readFileSync(dst, 'utf8'),
    nodes = walk(parse.parse(html)),
    out = nodes.find((n) => (attr(n, 'class') || '').split(/\s+/).includes('gperf-original'));
  assert(out, rel);
  const a = md.indexOf('<div class="gperf-original">') + '<div class="gperf-original">'.length,
    b = md.lastIndexOf('</div>'),
    raw = md.slice(a, b).replace(/^\n/, '').replace(/\n$/, ''),
    original = walk(parse.parseFragment(raw)),
    actual = walk(out);
  assert.equal(norm(text(out)), norm(text(original[0])), rel + ' complete rendered text');
  for (const tag of ['pre', 'code', 'dt', 'dd'])
    assert.deepEqual(
      actual.filter((x) => x.tagName === tag).map((x) => (tag === 'pre' ? text(x) : norm(text(x)))),
      original
        .filter((x) => x.tagName === tag)
        .map((x) => (tag === 'pre' ? text(x) : norm(text(x)))),
      rel + ' ' + tag
    );
  assert.deepEqual(
    actual.filter((x) => /^h[1-6]$/.test(x.tagName || '')).map((x) => [x.tagName, norm(text(x))]),
    original.filter((x) => /^h[1-6]$/.test(x.tagName || '')).map((x) => [x.tagName, norm(text(x))]),
    rel + ' headings'
  );
  let local = 0;
  for (const n of actual.filter((x) => x.tagName === 'a' && attr(x, 'href'))) {
    const h = attr(n, 'href'),
      url = new URL(h, 'http://audit/docs/gperf/' + rel + '/');
    if (url.origin !== 'http://audit') continue;
    local++;
    const q = url.pathname.replace(/^\/docs\/gperf\//, ''),
      dest = app + '/dist/' + q + (q.endsWith('/') ? 'index.html' : '');
    assert(fs.existsSync(dest), rel + ' missing ' + dest);
    const targetNodes = walk(parse.parse(fs.readFileSync(dest, 'utf8')));
    if (url.hash)
      assert(
        targetNodes.some(
          (x) =>
            attr(x, 'id') === decodeURIComponent(url.hash.slice(1)) ||
            attr(x, 'name') === decodeURIComponent(url.hash.slice(1))
        ),
        rel + ' missing target ' + h
      );
  }
  if (rel.endsWith('/01-user-guide')) {
    assert(md.includes(gpl) && md.includes(notice), rel + ' protected fragments');
    assert.equal(sha(fs.readFileSync(app + '/dist/' + rel + '/gperf.html')), sha(source));
    if (rel.includes('/en/'))
      assert.equal(raw, expectedEN, 'entire original English body except enumerated links');
    assert.equal(actual.filter((x) => x.tagName === 'pre').length, 11);
    assert.equal(local, 126);
  } else {
    assert.equal(actual.filter((x) => x.tagName === 'dt').length, 35);
    assert.equal(actual.filter((x) => x.tagName === 'dd').length, 35);
    assert.equal(
      text(actual.find((x) => x.tagName === 'pre')),
      fs.readFileSync(note + '/sources/gperf-3.3/COPYING', 'utf8')
    );
  }
  pages.push({
    relative: rel,
    sourceSHA256: sha(md),
    renderedSHA256: sha(html),
    wholeRenderedTextExact: true,
    pre: actual.filter((x) => x.tagName === 'pre').length,
    definitions: actual.filter((x) => x.tagName === 'dt').length,
    headings: actual.filter((x) => /^h[1-6]$/.test(x.tagName || '')).length,
    localLinks: local,
  });
}
assert.equal(pages.length, 4);
const output = {
  at: new Date().toISOString(),
  status: 'passed-mechanical-rendered-fidelity-not-content-review',
  workspace: w,
  scopePages: 2,
  languages: ['en', 'ja'],
  pages,
  protectedFragments:
    'Markdown GPL and permission exact source HTML bytes. Rendered text/code/headings exact relative to Markdown body; serializer HTML raw bytes are not asserted equal. Full original compatibility file byte-identical.',
  notEvaluatedByThisCheck: [
    'independent whole content review (operation reviewManifest is authoritative)',
    'native accessibility/code copy controls',
    'corresponding source download delivery',
    'integration and publication checks',
  ],
};
if (outArg)
  fs.writeFileSync(outArg.slice(9), JSON.stringify(output, null, 2) + '\n', { flag: 'wx' });
console.log({ pages: 4, localLinks: pages.reduce((s, x) => s + x.localLinks, 0), errors: 0 });
