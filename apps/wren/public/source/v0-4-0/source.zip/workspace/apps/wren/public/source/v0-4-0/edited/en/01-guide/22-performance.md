---
title: "Performance"
documentId: "wren:performance.html"
order: 22
licenseSource: "wren-fixed"
toc: { maxLevel: 6 }
documentContext: [{"kind": "source", "html": "<p>Wren 0.4.0; fixed commit 4a18fc489f9ea3d253b20dd40f4cdad0d6bb40eb. By Robert Nystrom and Wren contributors. Unofficial Libx edition: complete English originals (41 articles and MIT licence), Japanese translation of 24 language/VM/use guides, 17 API originals untranslated. <a href=\"/docs/wren/notices/LICENSE.txt\">Original MIT notice</a>.</p><p>Wren 0.4.0の固定原文を静的に提供します。言語・VM・利用ガイド24ページが日本語訳の対象で、API 17ページは未翻訳の英語参照です。Libxの運用方針に基づき、見出し・内部リンク・静的な図表を調整しています。CLI・ブログ・実行デモ等は原典へのリンクで案内します。版の日付は0.4.0の公開記録です。</p>"}, {"kind": "editorial", "html": "<p>原著に残る未執筆・説明不足も保持しています。ClassesのTODOと不完全な例、組み込み/モジュールの説明や設定例の不整合は、固定版の原典と<a href=\"/docs/wren/notices/wren.h.txt\">公開ヘッダー原文</a>を参照してください。Metaモジュールの原API 2ページはTODOで未執筆です。Libxは欠けた説明を補作せず、元の例の実行や原著全体の技術的正しさを保証していません。</p><p>Original TODOs/incomplete examples remain in Classes and Meta API. Embedding/module prose and configuration examples have known inconsistencies; consult the fixed original and public header. The unresolved performance script is omitted while its fixed tables and bars are retained. Example programs are not executed by this edition.</p>"}, {"kind": "source", "html": "<p><a href=\"/docs/wren/source/v0-4-0/source.zip\">Libx編集用ソース一式（ZIP） / Editable Libx source</a>：固定原文45ファイル、英語42ページ・非公式日本語訳24ガイドの編集原稿、再生成入力、原通知、共有ビルドコードと再構築手順を含みます。API 17ページは未翻訳の英語原文です。各ファイルの原条件を参照してください。</p>"}]
---
<div class="wren-document">
<h1 id="page-title">Performance</h1>
<p>Even though most benchmarks aren&rsquo;t worth the pixels they&rsquo;re printed on, people
seem to like them, so here&rsquo;s a few:</p>
<h3>Method Call</h3>
<div class="wren-table-scroll"><table class="chart">
  <tr>
    <th>wren</th><td><div class="chart-bar wren" style="width: 14%;">0.12s&nbsp;</div></td>
  </tr>
  <tr>
    <th>luajit (-joff)</th><td><div class="chart-bar" style="width: 18%;">0.16s&nbsp;</div></td>
  </tr>
  <tr>
    <th>ruby</th><td><div class="chart-bar" style="width: 23%;">0.20s&nbsp;</div></td>
  </tr>
  <tr>
    <th>lua</th><td><div class="chart-bar" style="width: 41%;">0.35s&nbsp;</div></td>
  </tr>
  <tr>
    <th>python3</th><td><div class="chart-bar" style="width: 91%;">0.78s&nbsp;</div></td>
  </tr>
  <tr>
    <th>python</th><td><div class="chart-bar" style="width: 100%;">0.85s&nbsp;</div></td>
  </tr>
</table></div>
<h3>DeltaBlue</h3>
<div class="wren-table-scroll"><table class="chart">
  <tr>
    <th>wren</th><td><div class="chart-bar wren" style="width: 22%;">0.13s&nbsp;</div></td>
  </tr>
  <tr>
    <th>python3</th><td><div class="chart-bar" style="width: 83%;">0.48s&nbsp;</div></td>
  </tr>
  <tr>
    <th>python</th><td><div class="chart-bar" style="width: 100%;">0.57s&nbsp;</div></td>
  </tr>
</table></div>
<h3>Binary Trees</h3>
<div class="wren-table-scroll"><table class="chart">
  <tr>
    <th>luajit (-joff)</th><td><div class="chart-bar" style="width: 20%;">0.11s&nbsp;</div></td>
  </tr>
  <tr>
    <th>wren</th><td><div class="chart-bar wren" style="width: 41%;">0.22s&nbsp;</div></td>
  </tr>
  <tr>
    <th>ruby</th><td><div class="chart-bar" style="width: 46%;">0.24s&nbsp;</div></td>
  </tr>
  <tr>
    <th>python</th><td><div class="chart-bar" style="width: 71%;">0.37s&nbsp;</div></td>
  </tr>
  <tr>
    <th>python3</th><td><div class="chart-bar" style="width: 73%;">0.38s&nbsp;</div></td>
  </tr>
  <tr>
    <th>lua</th><td><div class="chart-bar" style="width: 100%;">0.52s&nbsp;</div></td>
  </tr>
</table></div>
<h3>Recursive Fibonacci</h3>
<div class="wren-table-scroll"><table class="chart">
  <tr>
    <th>luajit (-joff)</th><td><div class="chart-bar" style="width: 17%;">0.10s&nbsp;</div></td>
  </tr>
  <tr>
    <th>wren</th><td><div class="chart-bar wren" style="width: 35%;">0.20s&nbsp;</div></td>
  </tr>
  <tr>
    <th>ruby</th><td><div class="chart-bar" style="width: 39%;">0.22s&nbsp;</div></td>
  </tr>
  <tr>
    <th>lua</th><td><div class="chart-bar" style="width: 49%;">0.28s&nbsp;</div></td>
  </tr>
  <tr>
    <th>python</th><td><div class="chart-bar" style="width: 90%;">0.51s&nbsp;</div></td>
  </tr>
  <tr>
    <th>python3</th><td><div class="chart-bar" style="width: 100%;">0.57s&nbsp;</div></td>
  </tr>
</table></div>

<p><strong>Shorter bars are better.</strong> Each benchmark is run ten times and the best time
is kept. It only measures the time taken to execute the benchmarked code
itself, not interpreter startup.</p>
<p>These were run on my MacBook Pro 2.3 GHz Intel Core i7 with 16 GB of 1,600 MHz
DDR3 RAM. Tested against Lua 5.2.3, LuaJIT 2.0.2, Python 2.7.5, Python 3.3.4,
ruby 2.0.0p247. LuaJIT is run with the JIT <em>disabled</em> (i.e. in bytecode
interpreter mode) since I want to support platforms where JIT-compilation is
disallowed. LuaJIT with the JIT enabled is <em>much</em> faster than all of the other
languages benchmarked, including Wren, because Mike Pall is a robot from the
future.</p>
<p>The benchmark harness and programs are
<a href="https://github.com/wren-lang/wren/tree/main/test/benchmark">here</a>.</p>
<h2>Why is Wren fast? <a href="#why-is-wren-fast" name="why-is-wren-fast" class="header-anchor">#</a></h2>
<p>Languages come in four rough performance buckets, from slowest to fastest:</p>
<ol>
<li>
<p>Tree-walk interpreters: Ruby 1.8.7 and earlier, Io, that
    interpreter you wrote for a class in college.</p>
</li>
<li>
<p>Bytecode interpreters: CPython,
    Ruby 1.9 and later, Lua, early JavaScript VMs.</p>
</li>
<li>
<p>JIT compiled dynamically typed languages: Modern JavaScript VMs,
    LuaJIT, PyPy, some Lisp/Scheme implementations.</p>
</li>
<li>
<p>Statically typed languages: C, C++, Java, C#, Haskell, etc.</p>
</li>
</ol>
<p>Most languages in the first bucket aren&rsquo;t suitable for production use. (Servers
are one exception, because you can throw more hardware at a slow language
there.) Languages in the second bucket are fast enough for many use cases, even
on client hardware, as the success of the listed languages shows. Languages in
the third bucket are quite fast, but their implementations are breathtakingly
complex, often rivaling that of compilers for statically-typed languages.</p>
<p>Wren is in the second bucket. If you want a simple implementation that&rsquo;s fast
enough for real use, this is the sweet spot. In addition, Wren has a few tricks
up its sleeve:</p>
<h3>A compact value representation <a href="#a-compact-value-representation" name="a-compact-value-representation" class="header-anchor">#</a></h3>
<p>A core piece of a dynamic language implementation is the data structure used
for variables. It needs to be able to store (or reference) a value of any type,
while also being as compact as possible. Wren uses a technique called <em><a href="http://wingolog.org/archives/2011/05/18/value-representation-in-javascript-implementations">NaN
tagging</a></em> for this.</p>
<p>All values are stored internally in Wren as small, eight-byte double-precision
floats. Since that is also Wren&rsquo;s number type, in order to do arithmetic, no
conversion is needed before the &ldquo;raw&rdquo; number can be accessed: a value holding a
number <em>is</em> a valid double. This keeps arithmetic fast.</p>
<p>To store values of other types, it turns out there&rsquo;s a ton of unused bits in a
NaN double. You can stuff a pointer for heap-allocated objects, with room left
over for special values like <code>true</code>, <code>false</code>, and <code>null</code>. This means numbers,
bools, and null are unboxed. It also means an entire value is only eight bytes,
the native word size on 64-bit machines. Smaller = faster when you take into
account CPU caching and the cost of passing values around.</p>
<h3>Fixed object layout <a href="#fixed-object-layout" name="fixed-object-layout" class="header-anchor">#</a></h3>
<p>Most dynamic languages treat objects as loose bags of named properties. You can
freely add and remove properties from an object after you&rsquo;ve created it.
Languages like Lua and JavaScript don&rsquo;t even have a well-defined concept of a
&ldquo;type&rdquo; of object.</p>
<p>Wren is strictly class-based. Every object is an instance of a class. Classes
in turn have a well-defined declarative syntax, and cannot be imperatively
modified. In addition, fields in Wren are private to the class&mdash;they can
only be accessed from methods defined directly on that class.</p>
<p>Put all of that together and it means you can determine at <em>compile</em> time
exactly how many fields an object has and what they are. In other languages,
when you create an object, you allocate some initial memory for it, but that
may have to be reallocated multiple times as fields are added and the object
grows. Wren just does a single allocation up front for exactly the right number
of fields.</p>
<p>Likewise, when you access a field in other languages, the interpreter has to
look it up by name in a hash table in the object, and then maybe walk its
inheritance chain if it can&rsquo;t find it. It must do this every time since fields
may be added freely. In Wren, field access is just accessing a slot in the
instance by an offset known at compile time: it&rsquo;s just adding a few pointers.</p>
<h3>Copy-down inheritance <a href="#copy-down-inheritance" name="copy-down-inheritance" class="header-anchor">#</a></h3>
<p>When you call a method on an object, the method must be located. It could be
defined directly on the object&rsquo;s class, or it may be inheriting it from some
superclass. This means that in the worst case, you may have to walk the
inheritance chain to find it.</p>
<p>Advanced implementations do very smart things to optimize this, but it&rsquo;s made
more difficult by the mutable nature of the underlying language: if you can add
new methods to existing classes freely or change the inheritance hierarchy, the
lookup for a given method may actually change over time. You have to check for
that which costs CPU cycles.</p>
<p>Wren&rsquo;s inheritance hierarchy is static and fixed at class definition time. This
means that we can copy down all inherited methods in the subclass when it&rsquo;s
created since we know those will never change. Method dispatch then just
requires locating the method in the class of the receiver.</p>
<h3>Method signatures <a href="#method-signatures" name="method-signatures" class="header-anchor">#</a></h3>
<p>Wren supports overloading by arity using its concept of <a href="/docs/wren/v0-4-0/en/01-guide/07-method-calls/#signature">signatures</a>. This makes
the language more expressive, but also faster. When a method is called, we look
it up on the receiver&rsquo;s class. If we succeed in finding it, we also know it has
the right number of parameters.</p>
<p>This lets Wren avoid the extra checking most languages need to do at runtime to
handle too few or too many arguments being passed to a method. In Wren, it&rsquo;s not
<em>syntactically</em> possible to call a method with the wrong number of arguments.</p>
<h3>Computed gotos <a href="#computed-gotos" name="computed-gotos" class="header-anchor">#</a></h3>
<p>On compilers that support it, Wren&rsquo;s core bytecode interpreter loop uses
something called <a href="http://eli.thegreenplace.net/2012/07/12/computed-goto-for-efficient-dispatch-tables/"><em>computed gotos</em></a>. The hot core of a bytecode
interpreter is effectively a giant <code>switch</code> on the instruction being executed.</p>
<p>Doing that using an actual <code>switch</code> confounds the CPU&rsquo;s <a href="http://en.wikipedia.org/wiki/Branch_predictor">branch
predictor</a>&mdash;there is basically a single branch point for the entire
interpreter. That quickly saturates the predictor and it just gets confused and
fails to predict anything, which leads to more CPU stalls and pipeline flushes.</p>
<p>Using computed gotos gives you a separate branch point at the end of each
instruction. Each gets its own branch prediction, which often succeeds since
some instruction pairs are more common than others. In my rough testing, this
makes a 5-10% performance difference.</p>
<h3>A single-pass compiler <a href="#a-single-pass-compiler" name="a-single-pass-compiler" class="header-anchor">#</a></h3>
<p>Compile time is a relatively small component of a language&rsquo;s performance: code
only has to be compiled once but a given line of code may be run many times.
However, fast compilation helps with <em>startup</em> speed&mdash;the time it takes to
get anything up and running. For that, Wren&rsquo;s compiler is quite fast.</p>
<p>It&rsquo;s modeled after Lua&rsquo;s compiler. Instead of tokenizing and then parsing to
create a bunch of AST structures which are then consumed and deallocated by
later phases, it emits code directly during parsing. This means it does minimal
memory allocation during a parse and has very little overhead.</p>
<h2>Why don&rsquo;t other languages do this? <a href="#why-don't-other-languages-do-this" name="why-don't-other-languages-do-this" class="header-anchor">#</a></h2>
<p>Most of Wren&rsquo;s performance comes from language design decisions. While it&rsquo;s
dynamically <em>typed</em> and <em>dispatched</em>, classes are relatively statically
<em>defined</em>. That makes a lot of things much easier. Other languages have a much
more mutable object model, and cannot change that without breaking lots of
existing code.</p>
<p>Wren&rsquo;s closest sibling, by far, is Lua. Lua is more dynamic than Wren which
makes its job harder. Lua also tries very hard to be compatible across a wide
range of hardware and compilers. If you have a C89 compiler for it, odds are
very good that you can run Lua on it.</p>
<p>Wren cares about compatibility, but it requires C99 or C++98 and IEEE double
precision floats. That may exclude some edge case hardware, but makes things
like NaN tagging, computed gotos, and some other tricks possible.</p>

</div>
