---
title: "Getting Started"
documentId: "wren:getting-started.html"
order: 2
licenseSource: "wren-fixed"
toc: { maxLevel: 6 }
documentContext: [{"kind": "source", "html": "<p>Wren 0.4.0; fixed commit 4a18fc489f9ea3d253b20dd40f4cdad0d6bb40eb. By Robert Nystrom and Wren contributors. Unofficial Libx edition: complete English originals (41 articles and MIT licence), Japanese translation of 24 language/VM/use guides, 17 API originals untranslated. <a href=\"/docs/wren/notices/LICENSE.txt\">Original MIT notice</a>.</p><p>Wren 0.4.0の固定原文を静的に提供します。言語・VM・利用ガイド24ページが日本語訳の対象で、API 17ページは未翻訳の英語参照です。Libxの運用方針に基づき、見出し・内部リンク・静的な図表を調整しています。CLI・ブログ・実行デモ等は原典へのリンクで案内します。版の日付は0.4.0の公開記録です。</p>"}, {"kind": "editorial", "html": "<p>原著に残る未執筆・説明不足も保持しています。ClassesのTODOと不完全な例、組み込み/モジュールの説明や設定例の不整合は、固定版の原典と<a href=\"/docs/wren/notices/wren.h.txt\">公開ヘッダー原文</a>を参照してください。Metaモジュールの原API 2ページはTODOで未執筆です。Libxは欠けた説明を補作せず、元の例の実行や原著全体の技術的正しさを保証していません。</p><p>Original TODOs/incomplete examples remain in Classes and Meta API. Embedding/module prose and configuration examples have known inconsistencies; consult the fixed original and public header. The unresolved performance script is omitted while its fixed tables and bars are retained. Example programs are not executed by this edition.</p>"}, {"kind": "source", "html": "<p><a href=\"/docs/wren/source/v0-4-0/source.zip\">Libx編集用ソース一式（ZIP） / Editable Libx source</a>：固定原文45ファイル、英語42ページ・非公式日本語訳24ガイドの編集原稿、再生成入力、原通知、共有ビルドコードと再構築手順を含みます。API 17ページは未翻訳の英語原文です。各ファイルの原条件を参照してください。</p>"}]
---
<div class="wren-document">
<h1 id="page-title">Getting Started</h1>
<h2>Trying out the language <a href="#trying-out-the-language" name="trying-out-the-language" class="header-anchor">#</a></h2>
<p>If you&rsquo;d like to try Wren, you have a few options.</p>
<ul>
<li><strong>In your browser.</strong> You can try Wren <strong><a href="https://wren.io/try">right here</a></strong>!</li>
<li><strong>On your computer.</strong> The <a href="https://wren.io/cli">Wren CLI</a> project is a downloadable executable
      to run scripts with access to file io and more. See the <a href="https://wren.io/cli">Wren CLI docs</a>.</li>
<li><strong>Embedded in your code.</strong> See how to <a href="#embed-the-vm">build and embed Wren</a> below. <br />
    And then read the <a href="/docs/wren/v0-4-0/en/01-guide/16-embedding/">embedding guide</a>!</li>
</ul>
<p>Once you have somewhere to explore, it&rsquo;s time to <a href="/docs/wren/v0-4-0/en/01-guide/03-syntax/">learn the
language</a>.</p>
<hr />
<h2>Embed the VM <a href="#embed-the-vm" name="embed-the-vm" class="header-anchor">#</a></h2>
<p><strong>The Wren Virtual Machine</strong> is the core of the language that executes Wren
    source code. It is just a library, not a standalone application. It&rsquo;s
    designed to be <a href="/docs/wren/v0-4-0/en/01-guide/16-embedding/">embedded</a> in a larger host application.</p>
<p>It has no dependencies beyond the C standard library.
You can use it as a static library, shared library, or simply compile the source into your app.</p>
<h3>Building Wren <a href="#building-wren" name="building-wren" class="header-anchor">#</a></h3>
<p>To build the Wren library, we look inside the <code>projects/</code> folder.
In here you&rsquo;ll find ready to go projects for <code>Visual Studio</code>, <code>XCode</code> and tools like <code>make</code>.</p>
<ul>
<li><strong>Windows</strong> Open <code>wren.sln</code> inside <code>projects/vs2019/</code> (or <code>vs2017</code>), hit build.</li>
<li><strong>Mac</strong> Open <code>wren.xcworkspace</code> inside <code>projects/xcode/</code>, hit build.</li>
<li><strong>Linux</strong> Run <code>make</code> inside of <code>projects/make/</code>.</li>
</ul>
<p>In each case, <strong>there will be library files generated into the root <code>lib/</code> folder</strong>. <br />
These are what you&rsquo;ll link into your project, based on your needs.</p>
<ul>
<li><strong>Static Linking</strong> <code>wren.lib</code> on Windows, <code>libwren.a</code> elsewhere.</li>
<li><strong>Dynamic Linking</strong> <code>wren.dll</code> on Windows, <code>libwren.so</code> on Linux, and <code>libwren.dylib</code> on Mac.</li>
</ul>
<p><small>
  Note that the default build will also generate <code>wren_test</code> inside of <code>bin/</code>, <br />
  a binary that is used to run the language tests. It can execute simple scripts.
</small></p>
<p><strong>Other platforms</strong> <br />
If your platform isn&rsquo;t explicitly supported,
it is recommended that you include the Wren source
in your project for a portable experience.</p>
<h3>Including the code in your project <a href="#including-the-code-in-your-project" name="including-the-code-in-your-project" class="header-anchor">#</a></h3>
<p><strong>all source files</strong> <br />
The alternative to building via the provided projects is to include the wren source code in your project.
Since it has no dependencies this is simple, all the code in <code>src/</code> comes along. There&rsquo;s a readme in <code>src/</code> for details.</p>
<p><strong>&lsquo;amalgamated&rsquo; build</strong> <br />
If you want an even simpler way, there&rsquo;s an &lsquo;amalgamated&rsquo; build (often called <code>blob</code>, or <code>unity</code> builds.).
This is <em>all of the wren source code in one file</em>.</p>
<p>This file can be generated by running <code>python3 util/generate_amalgamation.py &gt; build/wren.c</code>, 
which saves the generated output in <code>build/wren.c</code>.</p>
<p>Include <code>build/wren.c</code> and <code>src/include/wren.h</code> in your project code and you&rsquo;re good to go.
<small>Ideally later we can automate generating this and include it in the repo.</small></p>
<hr />
<p>If you run into bugs, or have ideas or questions, any of
the following work:</p>
<ul>
<li>Join the <a href="https://discord.gg/Kx6PxSX">discord community</a>.</li>
<li>Ask on the <a href="https://groups.google.com/forum/#!forum/wren-lang">Wren mailing list</a> (which is pretty quiet).</li>
<li>Tell us on twitter at <a href="https://twitter.com/intent/user?screen_name=munificentbob">@munificentbob</a> or <a href="https://twitter.com/intent/user?screen_name=ruby0x1">@ruby0x1</a>.</li>
<li><a href="https://github.com/wren-lang/wren/issues">File a ticket</a> at <a href="https://github.com/wren-lang/wren">the GitHub repo</a>.</li>
<li>The CLI also has <a href="https://github.com/wren-lang/wren-cli/issues">tickets</a> and a <a href="https://github.com/wren-lang/wren-cli">GitHub repo</a> too.</li>
<li>Pull requests are welcome.</li>
</ul>
</div>
