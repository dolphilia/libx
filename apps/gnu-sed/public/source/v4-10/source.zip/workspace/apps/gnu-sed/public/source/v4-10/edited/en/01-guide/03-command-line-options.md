---
title: "Command-Line Options"
description: "Fixed GNU sed4.10 complete manual chapters1–3, with paired Japanese translation."
documentId: "gnu-sed:4.10:03-command-line-options"
licenseSource: "gnu-sed-manual"
toc: {"maxLevel": 4}
documentContext: [{"kind": "source", "html": "<section class=\"gnu-sed-notices\"><h3>Libx GNU sed 4.10 Getting Started and Scripts — Chapters 1–3 / Libx GNU sed 4.10 入門とスクリプト — 第1〜3章</h3><p>Original authors: Ken Pizzini, Paolo Bonzini, Jim Meyering, Assaf Gordon. Original publisher: Free Software Foundation. Modification author and publisher: Libx.</p><p>This file documents version 4.10 of\nGNU <code class=\"command\">sed</code>, a stream editor.\n</p><p>Copyright © 1998–2026 Free Software Foundation, Inc.\n</p><blockquote class=\"quotation\">\n<p>Permission is granted to copy, distribute and/or modify this document\nunder the terms of the GNU Free Documentation License, Version 1.3\nor any later version published by the Free Software Foundation;\nwith no Invariant Sections, no Front-Cover Texts, and no\nBack-Cover Texts.  A copy of the license is included in the\nsection entitled “GNU Free Documentation License”.\n</p></blockquote><p>Copyright © 2026 Libx, for editing and independent Japanese translation. This modified guide is available under GNU Free Documentation License1.3 or later, with no Invariant Sections, Front-Cover Texts, or Back-Cover Texts. No new cover texts or invariant sections have been added.</p><h3>History / 履歴</h3><p>Original: GNU sed, a stream editor; version4.10; updated20April2026; authors listed above; publisher Free Software Foundation. Source: sed-4.10.tar.gz, SHA256 4d179ffaf92ec4dcec541f7c032be1c3b9a1856f4970adb95a505221702f5277.</p><p>2026: Libx GNU sed4.10 Getting Started and Scripts — Chapters1–3 / Libx GNU sed4.10 入門とスクリプト — 第1〜3章. Modification author and publisher: Libx. Static chapter-scoped HTML in editable Markdown and unofficial Japanese translation. Original copyright, permission and whole English license preserved. Modified6October2026.</p></section><details class=\"gnu-sed-license\"><summary>Original English GNU Free Documentation License / 原英語GFDL全文</summary><div class=\"appendix-level-extent\" id=\"GNU-Free-Documentation-License\">\n<h2 class=\"appendix\" id=\"GNU-Free-Documentation-License-1\"><span>Appendix A GNU Free Documentation License<a class=\"copiable-link\" href=\"#GNU-Free-Documentation-License-1\"> ¶</a></span></h2>\n<div class=\"center\">Version 1.3, 3 November 2008\n</div>\n<div class=\"display\">\n<pre class=\"display-preformatted\">Copyright © 2000–2026 Free Software Foundation, Inc.\n<a class=\"uref\" href=\"https://fsf.org/\">https://fsf.org/</a>\n\nEveryone is permitted to copy and distribute verbatim copies\nof this license document, but changing it is not allowed.\n</pre></div>\n<ol class=\"enumerate\" start=\"0\">\n<li> PREAMBLE\n\n<p>The purpose of this License is to make a manual, textbook, or other\nfunctional and useful document <em class=\"dfn\">free</em> in the sense of freedom: to\nassure everyone the effective freedom to copy and redistribute it,\nwith or without modifying it, either commercially or noncommercially.\nSecondarily, this License preserves for the author and publisher a way\nto get credit for their work, while not being considered responsible\nfor modifications made by others.\n</p>\n<p>This License is a kind of “copyleft”, which means that derivative\nworks of the document must themselves be free in the same sense.  It\ncomplements the GNU General Public License, which is a copyleft\nlicense designed for free software.\n</p>\n<p>We have designed this License in order to use it for manuals for free\nsoftware, because free software needs free documentation: a free\nprogram should come with manuals providing the same freedoms that the\nsoftware does.  But this License is not limited to software manuals;\nit can be used for any textual work, regardless of subject matter or\nwhether it is published as a printed book.  We recommend this License\nprincipally for works whose purpose is instruction or reference.\n</p>\n</li><li> APPLICABILITY AND DEFINITIONS\n\n<p>This License applies to any manual or other work, in any medium, that\ncontains a notice placed by the copyright holder saying it can be\ndistributed under the terms of this License.  Such a notice grants a\nworld-wide, royalty-free license, unlimited in duration, to use that\nwork under the conditions stated herein.  The “Document”, below,\nrefers to any such manual or work.  Any member of the public is a\nlicensee, and is addressed as “you”.  You accept the license if you\ncopy, modify or distribute the work in a way requiring permission\nunder copyright law.\n</p>\n<p>A “Modified Version” of the Document means any work containing the\nDocument or a portion of it, either copied verbatim, or with\nmodifications and/or translated into another language.\n</p>\n<p>A “Secondary Section” is a named appendix or a front-matter section\nof the Document that deals exclusively with the relationship of the\npublishers or authors of the Document to the Document’s overall\nsubject (or to related matters) and contains nothing that could fall\ndirectly within that overall subject.  (Thus, if the Document is in\npart a textbook of mathematics, a Secondary Section may not explain\nany mathematics.)  The relationship could be a matter of historical\nconnection with the subject or with related matters, or of legal,\ncommercial, philosophical, ethical or political position regarding\nthem.\n</p>\n<p>The “Invariant Sections” are certain Secondary Sections whose titles\nare designated, as being those of Invariant Sections, in the notice\nthat says that the Document is released under this License.  If a\nsection does not fit the above definition of Secondary then it is not\nallowed to be designated as Invariant.  The Document may contain zero\nInvariant Sections.  If the Document does not identify any Invariant\nSections then there are none.\n</p>\n<p>The “Cover Texts” are certain short passages of text that are listed,\nas Front-Cover Texts or Back-Cover Texts, in the notice that says that\nthe Document is released under this License.  A Front-Cover Text may\nbe at most 5 words, and a Back-Cover Text may be at most 25 words.\n</p>\n<p>A “Transparent” copy of the Document means a machine-readable copy,\nrepresented in a format whose specification is available to the\ngeneral public, that is suitable for revising the document\nstraightforwardly with generic text editors or (for images composed of\npixels) generic paint programs or (for drawings) some widely available\ndrawing editor, and that is suitable for input to text formatters or\nfor automatic translation to a variety of formats suitable for input\nto text formatters.  A copy made in an otherwise Transparent file\nformat whose markup, or absence of markup, has been arranged to thwart\nor discourage subsequent modification by readers is not Transparent.\nAn image format is not Transparent if used for any substantial amount\nof text.  A copy that is not “Transparent” is called “Opaque”.\n</p>\n<p>Examples of suitable formats for Transparent copies include plain\nASCII without markup, Texinfo input format, LaTeX input\nformat, SGML or XML using a publicly available\nDTD, and standard-conforming simple HTML,\nPostScript or PDF designed for human modification.  Examples\nof transparent image formats include PNG, XCF and\nJPG.  Opaque formats include proprietary formats that can be\nread and edited only by proprietary word processors, SGML or\nXML for which the DTD and/or processing tools are\nnot generally available, and the machine-generated HTML,\nPostScript or PDF produced by some word processors for\noutput purposes only.\n</p>\n<p>The “Title Page” means, for a printed book, the title page itself,\nplus such following pages as are needed to hold, legibly, the material\nthis License requires to appear in the title page.  For works in\nformats which do not have any title page as such, “Title Page” means\nthe text near the most prominent appearance of the work’s title,\npreceding the beginning of the body of the text.\n</p>\n<p>The “publisher” means any person or entity that distributes copies\nof the Document to the public.\n</p>\n<p>A section “Entitled XYZ” means a named subunit of the Document whose\ntitle either is precisely XYZ or contains XYZ in parentheses following\ntext that translates XYZ in another language.  (Here XYZ stands for a\nspecific section name mentioned below, such as “Acknowledgements”,\n“Dedications”, “Endorsements”, or “History”.)  To “Preserve the Title”\nof such a section when you modify the Document means that it remains a\nsection “Entitled XYZ” according to this definition.\n</p>\n<p>The Document may include Warranty Disclaimers next to the notice which\nstates that this License applies to the Document.  These Warranty\nDisclaimers are considered to be included by reference in this\nLicense, but only as regards disclaiming warranties: any other\nimplication that these Warranty Disclaimers may have is void and has\nno effect on the meaning of this License.\n</p>\n</li><li> VERBATIM COPYING\n\n<p>You may copy and distribute the Document in any medium, either\ncommercially or noncommercially, provided that this License, the\ncopyright notices, and the license notice saying this License applies\nto the Document are reproduced in all copies, and that you add no other\nconditions whatsoever to those of this License.  You may not use\ntechnical measures to obstruct or control the reading or further\ncopying of the copies you make or distribute.  However, you may accept\ncompensation in exchange for copies.  If you distribute a large enough\nnumber of copies you must also follow the conditions in section 3.\n</p>\n<p>You may also lend copies, under the same conditions stated above, and\nyou may publicly display copies.\n</p>\n</li><li> COPYING IN QUANTITY\n\n<p>If you publish printed copies (or copies in media that commonly have\nprinted covers) of the Document, numbering more than 100, and the\nDocument’s license notice requires Cover Texts, you must enclose the\ncopies in covers that carry, clearly and legibly, all these Cover\nTexts: Front-Cover Texts on the front cover, and Back-Cover Texts on\nthe back cover.  Both covers must also clearly and legibly identify\nyou as the publisher of these copies.  The front cover must present\nthe full title with all words of the title equally prominent and\nvisible.  You may add other material on the covers in addition.\nCopying with changes limited to the covers, as long as they preserve\nthe title of the Document and satisfy these conditions, can be treated\nas verbatim copying in other respects.\n</p>\n<p>If the required texts for either cover are too voluminous to fit\nlegibly, you should put the first ones listed (as many as fit\nreasonably) on the actual cover, and continue the rest onto adjacent\npages.\n</p>\n<p>If you publish or distribute Opaque copies of the Document numbering\nmore than 100, you must either include a machine-readable Transparent\ncopy along with each Opaque copy, or state in or with each Opaque copy\na computer-network location from which the general network-using\npublic has access to download using public-standard network protocols\na complete Transparent copy of the Document, free of added material.\nIf you use the latter option, you must take reasonably prudent steps,\nwhen you begin distribution of Opaque copies in quantity, to ensure\nthat this Transparent copy will remain thus accessible at the stated\nlocation until at least one year after the last time you distribute an\nOpaque copy (directly or through your agents or retailers) of that\nedition to the public.\n</p>\n<p>It is requested, but not required, that you contact the authors of the\nDocument well before redistributing any large number of copies, to give\nthem a chance to provide you with an updated version of the Document.\n</p>\n</li><li> MODIFICATIONS\n\n<p>You may copy and distribute a Modified Version of the Document under\nthe conditions of sections 2 and 3 above, provided that you release\nthe Modified Version under precisely this License, with the Modified\nVersion filling the role of the Document, thus licensing distribution\nand modification of the Modified Version to whoever possesses a copy\nof it.  In addition, you must do these things in the Modified Version:\n</p>\n<ol class=\"enumerate\" start=\"1\" type=\"A\">\n<li> Use in the Title Page (and on the covers, if any) a title distinct\nfrom that of the Document, and from those of previous versions\n(which should, if there were any, be listed in the History section\nof the Document).  You may use the same title as a previous version\nif the original publisher of that version gives permission.\n\n</li><li> List on the Title Page, as authors, one or more persons or entities\nresponsible for authorship of the modifications in the Modified\nVersion, together with at least five of the principal authors of the\nDocument (all of its principal authors, if it has fewer than five),\nunless they release you from this requirement.\n\n</li><li> State on the Title page the name of the publisher of the\nModified Version, as the publisher.\n\n</li><li> Preserve all the copyright notices of the Document.\n\n</li><li> Add an appropriate copyright notice for your modifications\nadjacent to the other copyright notices.\n\n</li><li> Include, immediately after the copyright notices, a license notice\ngiving the public permission to use the Modified Version under the\nterms of this License, in the form shown in the Addendum below.\n\n</li><li> Preserve in that license notice the full lists of Invariant Sections\nand required Cover Texts given in the Document’s license notice.\n\n</li><li> Include an unaltered copy of this License.\n\n</li><li> Preserve the section Entitled “History”, Preserve its Title, and add\nto it an item stating at least the title, year, new authors, and\npublisher of the Modified Version as given on the Title Page.  If\nthere is no section Entitled “History” in the Document, create one\nstating the title, year, authors, and publisher of the Document as\ngiven on its Title Page, then add an item describing the Modified\nVersion as stated in the previous sentence.\n\n</li><li> Preserve the network location, if any, given in the Document for\npublic access to a Transparent copy of the Document, and likewise\nthe network locations given in the Document for previous versions\nit was based on.  These may be placed in the “History” section.\nYou may omit a network location for a work that was published at\nleast four years before the Document itself, or if the original\npublisher of the version it refers to gives permission.\n\n</li><li> For any section Entitled “Acknowledgements” or “Dedications”, Preserve\nthe Title of the section, and preserve in the section all the\nsubstance and tone of each of the contributor acknowledgements and/or\ndedications given therein.\n\n</li><li> Preserve all the Invariant Sections of the Document,\nunaltered in their text and in their titles.  Section numbers\nor the equivalent are not considered part of the section titles.\n\n</li><li> Delete any section Entitled “Endorsements”.  Such a section\nmay not be included in the Modified Version.\n\n</li><li> Do not retitle any existing section to be Entitled “Endorsements” or\nto conflict in title with any Invariant Section.\n\n</li><li> Preserve any Warranty Disclaimers.\n</li></ol>\n<p>If the Modified Version includes new front-matter sections or\nappendices that qualify as Secondary Sections and contain no material\ncopied from the Document, you may at your option designate some or all\nof these sections as invariant.  To do this, add their titles to the\nlist of Invariant Sections in the Modified Version’s license notice.\nThese titles must be distinct from any other section titles.\n</p>\n<p>You may add a section Entitled “Endorsements”, provided it contains\nnothing but endorsements of your Modified Version by various\nparties—for example, statements of peer review or that the text has\nbeen approved by an organization as the authoritative definition of a\nstandard.\n</p>\n<p>You may add a passage of up to five words as a Front-Cover Text, and a\npassage of up to 25 words as a Back-Cover Text, to the end of the list\nof Cover Texts in the Modified Version.  Only one passage of\nFront-Cover Text and one of Back-Cover Text may be added by (or\nthrough arrangements made by) any one entity.  If the Document already\nincludes a cover text for the same cover, previously added by you or\nby arrangement made by the same entity you are acting on behalf of,\nyou may not add another; but you may replace the old one, on explicit\npermission from the previous publisher that added the old one.\n</p>\n<p>The author(s) and publisher(s) of the Document do not by this License\ngive permission to use their names for publicity for or to assert or\nimply endorsement of any Modified Version.\n</p>\n</li><li> COMBINING DOCUMENTS\n\n<p>You may combine the Document with other documents released under this\nLicense, under the terms defined in section 4 above for modified\nversions, provided that you include in the combination all of the\nInvariant Sections of all of the original documents, unmodified, and\nlist them all as Invariant Sections of your combined work in its\nlicense notice, and that you preserve all their Warranty Disclaimers.\n</p>\n<p>The combined work need only contain one copy of this License, and\nmultiple identical Invariant Sections may be replaced with a single\ncopy.  If there are multiple Invariant Sections with the same name but\ndifferent contents, make the title of each such section unique by\nadding at the end of it, in parentheses, the name of the original\nauthor or publisher of that section if known, or else a unique number.\nMake the same adjustment to the section titles in the list of\nInvariant Sections in the license notice of the combined work.\n</p>\n<p>In the combination, you must combine any sections Entitled “History”\nin the various original documents, forming one section Entitled\n“History”; likewise combine any sections Entitled “Acknowledgements”,\nand any sections Entitled “Dedications”.  You must delete all\nsections Entitled “Endorsements.”\n</p>\n</li><li> COLLECTIONS OF DOCUMENTS\n\n<p>You may make a collection consisting of the Document and other documents\nreleased under this License, and replace the individual copies of this\nLicense in the various documents with a single copy that is included in\nthe collection, provided that you follow the rules of this License for\nverbatim copying of each of the documents in all other respects.\n</p>\n<p>You may extract a single document from such a collection, and distribute\nit individually under this License, provided you insert a copy of this\nLicense into the extracted document, and follow this License in all\nother respects regarding verbatim copying of that document.\n</p>\n</li><li> AGGREGATION WITH INDEPENDENT WORKS\n\n<p>A compilation of the Document or its derivatives with other separate\nand independent documents or works, in or on a volume of a storage or\ndistribution medium, is called an “aggregate” if the copyright\nresulting from the compilation is not used to limit the legal rights\nof the compilation’s users beyond what the individual works permit.\nWhen the Document is included in an aggregate, this License does not\napply to the other works in the aggregate which are not themselves\nderivative works of the Document.\n</p>\n<p>If the Cover Text requirement of section 3 is applicable to these\ncopies of the Document, then if the Document is less than one half of\nthe entire aggregate, the Document’s Cover Texts may be placed on\ncovers that bracket the Document within the aggregate, or the\nelectronic equivalent of covers if the Document is in electronic form.\nOtherwise they must appear on printed covers that bracket the whole\naggregate.\n</p>\n</li><li> TRANSLATION\n\n<p>Translation is considered a kind of modification, so you may\ndistribute translations of the Document under the terms of section 4.\nReplacing Invariant Sections with translations requires special\npermission from their copyright holders, but you may include\ntranslations of some or all Invariant Sections in addition to the\noriginal versions of these Invariant Sections.  You may include a\ntranslation of this License, and all the license notices in the\nDocument, and any Warranty Disclaimers, provided that you also include\nthe original English version of this License and the original versions\nof those notices and disclaimers.  In case of a disagreement between\nthe translation and the original version of this License or a notice\nor disclaimer, the original version will prevail.\n</p>\n<p>If a section in the Document is Entitled “Acknowledgements”,\n“Dedications”, or “History”, the requirement (section 4) to Preserve\nits Title (section 1) will typically require changing the actual\ntitle.\n</p>\n</li><li> TERMINATION\n\n<p>You may not copy, modify, sublicense, or distribute the Document\nexcept as expressly provided under this License.  Any attempt\notherwise to copy, modify, sublicense, or distribute it is void, and\nwill automatically terminate your rights under this License.\n</p>\n<p>However, if you cease all violation of this License, then your license\nfrom a particular copyright holder is reinstated (a) provisionally,\nunless and until the copyright holder explicitly and finally\nterminates your license, and (b) permanently, if the copyright holder\nfails to notify you of the violation by some reasonable means prior to\n60 days after the cessation.\n</p>\n<p>Moreover, your license from a particular copyright holder is\nreinstated permanently if the copyright holder notifies you of the\nviolation by some reasonable means, this is the first time you have\nreceived notice of violation of this License (for any work) from that\ncopyright holder, and you cure the violation prior to 30 days after\nyour receipt of the notice.\n</p>\n<p>Termination of your rights under this section does not terminate the\nlicenses of parties who have received copies or rights from you under\nthis License.  If your rights have been terminated and not permanently\nreinstated, receipt of a copy of some or all of the same material does\nnot give you any rights to use it.\n</p>\n</li><li> FUTURE REVISIONS OF THIS LICENSE\n\n<p>The Free Software Foundation may publish new, revised versions\nof the GNU Free Documentation License from time to time.  Such new\nversions will be similar in spirit to the present version, but may\ndiffer in detail to address new problems or concerns.  See\n<a class=\"uref\" href=\"https://www.gnu.org/licenses/\">https://www.gnu.org/licenses/</a>.\n</p>\n<p>Each version of the License is given a distinguishing version number.\nIf the Document specifies that a particular numbered version of this\nLicense “or any later version” applies to it, you have the option of\nfollowing the terms and conditions either of that specified version or\nof any later version that has been published (not as a draft) by the\nFree Software Foundation.  If the Document does not specify a version\nnumber of this License, you may choose any version ever published (not\nas a draft) by the Free Software Foundation.  If the Document\nspecifies that a proxy can decide which future versions of this\nLicense can be used, that proxy’s public statement of acceptance of a\nversion permanently authorizes you to choose that version for the\nDocument.\n</p>\n</li><li> RELICENSING\n\n<p>“Massive Multiauthor Collaboration Site” (or “MMC Site”) means any\nWorld Wide Web server that publishes copyrightable works and also\nprovides prominent facilities for anybody to edit those works.  A\npublic wiki that anybody can edit is an example of such a server.  A\n“Massive Multiauthor Collaboration” (or “MMC”) contained in the\nsite means any set of copyrightable works thus published on the MMC\nsite.\n</p>\n<p>“CC-BY-SA” means the Creative Commons Attribution-Share Alike 3.0\nlicense published by Creative Commons Corporation, a not-for-profit\ncorporation with a principal place of business in San Francisco,\nCalifornia, as well as future copyleft versions of that license\npublished by that same organization.\n</p>\n<p>“Incorporate” means to publish or republish a Document, in whole or\nin part, as part of another Document.\n</p>\n<p>An MMC is “eligible for relicensing” if it is licensed under this\nLicense, and if all works that were first published under this License\nsomewhere other than this MMC, and subsequently incorporated in whole\nor in part into the MMC, (1) had no cover texts or invariant sections,\nand (2) were thus incorporated prior to November 1, 2008.\n</p>\n<p>The operator of an MMC Site may republish an MMC contained in the site\nunder CC-BY-SA on the same site at any time before August 1, 2009,\nprovided the MMC is eligible for relicensing.\n</p>\n</li></ol>\n<h3 class=\"heading\" id=\"ADDENDUM_003a-How-to-use-this-License-for-your-documents\"><span>ADDENDUM: How to use this License for your documents<a class=\"copiable-link\" href=\"#ADDENDUM_003a-How-to-use-this-License-for-your-documents\"> ¶</a></span></h3>\n<p>To use this License in a document you have written, include a copy of\nthe License in the document and put the following copyright and\nlicense notices just after the title page:\n</p>\n<div class=\"example smallexample\">\n<div class=\"group\"><pre class=\"example-preformatted\">  Copyright (C)  <var class=\"var\">year</var>  <var class=\"var\">your name</var>.\n  Permission is granted to copy, distribute and/or modify this document\n  under the terms of the GNU Free Documentation License, Version 1.3\n  or any later version published by the Free Software Foundation;\n  with no Invariant Sections, no Front-Cover Texts, and no Back-Cover\n  Texts.  A copy of the license is included in the section entitled ``GNU\n  Free Documentation License''.\n</pre></div></div>\n<p>If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts,\nreplace the “with…Texts.” line with this:\n</p>\n<div class=\"example smallexample\">\n<div class=\"group\"><pre class=\"example-preformatted\">    with the Invariant Sections being <var class=\"var\">list their titles</var>, with\n    the Front-Cover Texts being <var class=\"var\">list</var>, and with the Back-Cover Texts\n    being <var class=\"var\">list</var>.\n</pre></div></div>\n<p>If you have Invariant Sections without Cover Texts, or some other\ncombination of the three, merge those two alternatives to suit the\nsituation.\n</p>\n<p>If your document contains nontrivial examples of program code, we\nrecommend releasing these examples in parallel under your choice of\nfree software license, such as the GNU General Public License,\nto permit their use in free software.\n</p>\n<hr/>\n</div></details>"}]
---

<div class="gnu-sed-original-content"><div class="section-level-extent" id="Command_002dLine-Options">
<h3 class="section" id="Command_002dLine-Options-1"><span>2.2 Command-Line Options</span></h3>
<p>The full format for invoking <code class="command">sed</code> is:
</p>
<div class="example">
<pre class="gnu-sed-literal">sed OPTIONS... [SCRIPT] [INPUTFILE...]&#10;</pre></div>
<p><code class="command">sed</code> may be invoked with the following command-line options:
</p>
<dl class="table">
<dt><a class="index-entry-id" id="index-Version_002c-printing"></a>
<a id="index-_002d_002dversion"></a><span><code class="code">--version</code></span></dt>
<dd><p>Print out the version of <code class="command">sed</code> that is being run and a copyright notice,
then exit.
</p>
</dd>
<dt><a class="index-entry-id" id="index-Usage-summary_002c-printing"></a>
<a id="index-_002d_002dhelp"></a><span><code class="code">--help</code></span></dt>
<dd><p>Print a usage message briefly summarizing these command-line options
and the bug-reporting address,
then exit.
</p>
</dd>
<dt><a class="index-entry-id" id="index-_002d_002dquiet"></a>
<a class="index-entry-id" id="index-_002d_002dsilent"></a>
<a class="index-entry-id" id="index-Disabling-autoprint_002c-from-command-line"></a>
<a id="index-_002dn"></a><span><code class="code">-n</code></span></dt>
<dt><code class="code">--quiet</code></dt>
<dt><code class="code">--silent</code></dt>
<dd><p>By default, <code class="command">sed</code> prints out the pattern space
at the end of each cycle through the script (see <a class="pxref" href="/docs/gnu-sed/source/v4-10/manual.html#Execution-Cycle">How <code class="code">sed</code> works</a>).
These options disable this automatic printing,
and <code class="command">sed</code> only produces output when explicitly told to
via the <code class="code">p</code> command.
</p>
</dd>
<dt><a class="index-entry-id" id="index-GNU-extensions_002c-debug"></a>
<a id="index-_002d_002ddebug"></a><span><code class="code">--debug</code></span></dt>
<dd><p>Print the input sed program in canonical form,
and annotate program execution.
</p><div class="example">
<pre class="gnu-sed-literal">$ echo 1 | sed '\%1%s21232'&#10;3&#10;&#10;$ echo 1 | sed --debug '\%1%s21232'&#10;SED PROGRAM:&#10;  /1/ s/1/3/&#10;INPUT:   'STDIN' line 1&#10;PATTERN: 1&#10;COMMAND: /1/ s/1/3/&#10;PATTERN: 3&#10;END-OF-CYCLE:&#10;3&#10;</pre></div>
</dd>
<dt><a class="index-entry-id" id="index-_002d_002dexpression"></a>
<a class="index-entry-id" id="index-Script_002c-from-command-line"></a>
<a id="index-_002de"></a><span><code class="code">-e <var class="var">script</var></code></span></dt>
<dt><code class="code">--expression=<var class="var">script</var></code></dt>
<dd><p>Add the commands in <var class="var">script</var> to the set of commands to be
run while processing the input.
</p>
</dd>
<dt><a class="index-entry-id" id="index-_002d_002dfile"></a>
<a class="index-entry-id" id="index-Script_002c-from-a-file"></a>
<a id="index-_002df"></a><span><code class="code">-f <var class="var">script-file</var></code></span></dt>
<dt><code class="code">--file=<var class="var">script-file</var></code></dt>
<dd><p>Add the commands contained in the file <var class="var">script-file</var>
to the set of commands to be run while processing the input.
</p>
</dd>
<dt><a class="index-entry-id" id="index-_002d_002din_002dplace"></a>
<a class="index-entry-id" id="index-In_002dplace-editing_002c-activating"></a>
<a class="index-entry-id" id="index-GNU-extensions_002c-in_002dplace-editing"></a>
<a id="index-_002di"></a><span><code class="code">-i[<var class="var">SUFFIX</var>]</code></span></dt>
<dt><code class="code">--in-place[=<var class="var">SUFFIX</var>]</code></dt>
<dd><p>This option specifies that files are to be edited in-place.
GNU <code class="command">sed</code> does this by creating a temporary file and
sending output to this file rather than to the standard
output.<a class="footnote" href="/docs/gnu-sed/v4-10/en/01-guide/03-command-line-options/#FOOT1" id="DOCF1"><sup>1</sup></a>.
</p>
<p>This option implies <samp class="option">-s</samp>.
</p>
<p>When the end of the file is reached, the temporary file is
renamed to the output file’s original name.  The extension,
if supplied, is used to modify the name of the old file
before renaming the temporary file, thereby making a backup
copy<a class="footnote" href="/docs/gnu-sed/v4-10/en/01-guide/03-command-line-options/#FOOT2" id="DOCF2"><sup>2</sup></a>).
</p>
<a class="index-entry-id" id="index-In_002dplace-editing_002c-Perl_002dstyle-backup-file-names"></a>
<p>This rule is followed: if the extension doesn’t contain a <code class="code">*</code>,
then it is appended to the end of the current filename as a
suffix; if the extension does contain one or more <code class="code">*</code>
characters, then <em class="emph">each</em> asterisk is replaced with the
current filename.  This allows you to add a prefix to the
backup file, instead of (or in addition to) a suffix, or
even to place backup copies of the original files into another
directory (provided the directory already exists).
</p>
<p>If no extension is supplied, the original file is
overwritten without making a backup.
</p>
<p>Because <samp class="option">-i</samp> takes an optional argument, it should
not be followed by other short options:
</p><dl class="table">
<dt><code class="code">sed -Ei '...' FILE</code></dt>
<dd><p>Same as <samp class="option">-E -i</samp> with no backup suffix - <samp class="file">FILE</samp> will be
edited in-place without creating a backup.
</p>
</dd>
<dt><code class="code">sed -iE '...' FILE</code></dt>
<dd><p>This is equivalent to <samp class="option">--in-place=E</samp>, creating <samp class="file">FILEE</samp> as backup
of <samp class="file">FILE</samp>
</p></dd>
</dl>
<p>Be cautious of using <samp class="option">-n</samp> with <samp class="option">-i</samp>: the former disables
automatic printing of lines and the latter changes the file in-place
without a backup. Used carelessly (and without an explicit <code class="code">p</code> command),
the output file will be empty:
</p><div class="example">
<pre class="gnu-sed-literal"># WRONG USAGE: 'FILE' will be truncated.&#10;sed -ni 's/foo/bar/' FILE&#10;</pre></div>
</dd>
<dt><a class="index-entry-id" id="index-_002d_002dline_002dlength"></a>
<a class="index-entry-id" id="index-Line-length_002c-setting"></a>
<a id="index-_002dl"></a><span><code class="code">-l <var class="var">N</var></code></span></dt>
<dt><code class="code">--line-length=<var class="var">N</var></code></dt>
<dd><p>Specify the default line-wrap length for the <code class="code">l</code> command.
A length of 0 (zero) means to never wrap long lines.  If
not specified, it is taken to be 70.
</p>
</dd>
<dt><a class="index-entry-id" id="index-GNU-extensions_002c-disabling"></a>
<a id="index-_002d_002dposix"></a><span><code class="code">--posix</code></span></dt>
<dd><p>GNU <code class="command">sed</code> includes several extensions to POSIX
sed.  In order to simplify writing portable scripts, this
option disables all the extensions that this manual documents,
including additional commands.
<a class="index-entry-id" id="index-POSIXLY_005fCORRECT-behavior_002c-enabling"></a>
Most of the extensions accept <code class="command">sed</code> programs that
are outside the syntax mandated by POSIX, but some
of them (such as the behavior of the <code class="command">N</code> command
described in <a class="ref" href="/docs/gnu-sed/source/v4-10/manual.html#Reporting-Bugs">Reporting Bugs</a>) actually violate the
standard.  If you want to disable only the latter kind of
extension, you can set the <code class="code">POSIXLY_CORRECT</code> variable
to a non-empty value.
</p>
</dd>
<dt><a class="index-entry-id" id="index-_002d_002dbinary"></a>
<a id="index-_002db"></a><span><code class="code">-b</code></span></dt>
<dt><code class="code">--binary</code></dt>
<dd><p>This option is available on every platform, but is only effective where the
operating system makes a distinction between text files and binary files.
When such a distinction is made—as is the case for MS-DOS, Windows,
Cygwin—text files are composed of lines separated by a carriage return
<em class="emph">and</em> a line feed character, and <code class="command">sed</code> does not see the
ending CR.  When this option is specified, <code class="command">sed</code> will open
input files in binary mode, thus not requesting this special processing
and considering lines to end at a line feed.
</p>
</dd>
<dt><a id="index-_002d_002dfollow_002dsymlinks"></a><span><code class="code">--follow-symlinks</code></span></dt>
<dd><p>This option is available only on platforms that support
symbolic links and has an effect only if option <samp class="option">-i</samp>
is specified.  In this case, if the file that is specified
on the command line is a symbolic link, <code class="command">sed</code> will
follow the link and edit the ultimate destination of the
link.  The default behavior is to break the symbolic link,
so that the link destination will not be modified.
</p>
</dd>
<dt><a class="index-entry-id" id="index-_002dr"></a>
<a class="index-entry-id" id="index-_002d_002dregexp_002dextended"></a>
<a class="index-entry-id" id="index-Extended-regular-expressions_002c-choosing"></a>
<a class="index-entry-id" id="index-GNU-extensions_002c-extended-regular-expressions"></a>
<a id="index-_002dE"></a><span><code class="code">-E</code></span></dt>
<dt><code class="code">-r</code></dt>
<dt><code class="code">--regexp-extended</code></dt>
<dd><p>Use extended regular expressions rather than basic
regular expressions.  Extended regexps are those that
<code class="command">egrep</code> accepts; they can be clearer because they
usually have fewer backslashes.
Historically this was a GNU extension,
but the <samp class="option">-E</samp>
extension has since been added to the POSIX standard
(http://austingroupbugs.net/view.php?id=528),
so use <samp class="option">-E</samp> for portability.
GNU sed has accepted <samp class="option">-E</samp> as an undocumented option for years,
and *BSD seds have accepted <samp class="option">-E</samp> for years as well,
but scripts that use <samp class="option">-E</samp> might not port to other older systems.
See <a class="xref" href="/docs/gnu-sed/source/v4-10/manual.html#ERE-syntax">Extended regular expressions</a>.
</p>
</dd>
<dt><a class="index-entry-id" id="index-_002d_002dseparate"></a>
<a class="index-entry-id" id="index-Working-on-separate-files"></a>
<a id="index-_002ds"></a><span><code class="code">-s</code></span></dt>
<dt><code class="code">--separate</code></dt>
<dd><p>By default, <code class="command">sed</code> will consider the files specified on the
command line as a single continuous long stream.  This GNU <code class="command">sed</code>
extension allows the user to consider them as separate files:
range addresses (such as ‘<samp class="samp">/abc/,/def/</samp>’) are not allowed
to span several files, line numbers are relative to the start
of each file, <code class="code">$</code> refers to the last line of each file,
and files invoked from the <code class="code">R</code> commands are rewound at the
start of each file.
</p>
</dd>
<dt><a class="index-entry-id" id="index-Sandbox-mode"></a>
<a id="index-_002d_002dsandbox"></a><span><code class="code">--sandbox</code></span></dt>
<dd><p>In sandbox mode,  <code class="code">e/w/r</code> commands are rejected - programs containing
them will be aborted without being run. Sandbox mode ensures <code class="command">sed</code>
operates only on the input files designated on the command line, and
cannot run external programs.
</p>
</dd>
<dt><a class="index-entry-id" id="index-_002d_002dunbuffered"></a>
<a class="index-entry-id" id="index-Unbuffered-I_002fO_002c-choosing"></a>
<a id="index-_002du"></a><span><code class="code">-u</code></span></dt>
<dt><code class="code">--unbuffered</code></dt>
<dd><p>Buffer both input and output as minimally as practical.
(This is particularly useful if the input is coming from
the likes of ‘<samp class="samp">tail -f</samp>’, and you wish to see the transformed
output as soon as possible.)
</p>
</dd>
<dt><a class="index-entry-id" id="index-_002d_002dnull_002ddata"></a>
<a class="index-entry-id" id="index-_002d_002dzero_002dterminated"></a>
<a id="index-_002dz"></a><span><code class="code">-z</code></span></dt>
<dt><code class="code">--null-data</code></dt>
<dt><code class="code">--zero-terminated</code></dt>
<dd><p>Treat the input as a set of lines, each terminated by a zero byte
(the ASCII ‘<samp class="samp">NUL</samp>’ character) instead of a newline.  This option can
be used with commands like ‘<samp class="samp">sort -z</samp>’ and ‘<samp class="samp">find -print0</samp>’
to process arbitrary file names.
</p></dd>
</dl>
<p>If no <samp class="option">-e</samp>, <samp class="option">-f</samp>, <samp class="option">--expression</samp>, or <samp class="option">--file</samp>
options are given on the command-line,
then the first non-option argument on the command line is
taken to be the <var class="var">script</var> to be executed.
</p>
<a class="index-entry-id" id="index-Files-to-be-processed-as-input"></a>
<p>If any command-line parameters remain after processing the above,
these parameters are interpreted as the names of input files to
be processed.
<a class="index-entry-id" id="index-Standard-input_002c-processing-as-input"></a>
A file name of ‘<samp class="samp">-</samp>’ refers to the standard input stream.
The standard input will be processed if no file names are specified.
</p>
<hr/>
</div><div class="gnu-source-footnote"><h5 class="footnote-body-heading"><a href="/docs/gnu-sed/v4-10/en/01-guide/03-command-line-options/#DOCF1" id="FOOT1">(1)</a></h5><p>This applies to commands such as <code class="code">=</code>,
<code class="code">a</code>, <code class="code">c</code>, <code class="code">i</code>, <code class="code">l</code>, <code class="code">p</code>.  You can
still write to the standard output by using the <code class="code">w</code>
<a class="index-entry-id" id="index-GNU-extensions_002c-_002fdev_002fstdout-file"></a>
or <code class="code">W</code> commands together with the <samp class="file">/dev/stdout</samp>
special file</p></div><div class="gnu-source-footnote"><h5 class="footnote-body-heading"><a href="/docs/gnu-sed/v4-10/en/01-guide/03-command-line-options/#DOCF2" id="FOOT2">(2)</a></h5><p>Note that GNU <code class="command">sed</code> creates the backup
file whether or not any output is actually changed.</p></div></div>
