---
title: "Theme"
documentId: "mdbook:guide/src/format/theme/README.md"
order: 20
licenseSource: "mdbook-guide"
documentContext: [{"kind": "source", "html": "<p>mdBook 0.5.4 fixed documentation, MPL-2.0. <a href=\"https://github.com/rust-lang/mdBook/blob/2ea30c00f00647d2b3f4c0f79b3e0e1eabc0b66d/guide/src/format/theme/README.md\">Original chapter</a> · <a href=\"/docs/mdbook/source/v0-5-4/original/guide/src/format/theme/README.md\">Original Markdown</a> · <a href=\"/docs/mdbook/source/v0-5-4/edited/en/24-format-theme-index.md\">Editable Libx document</a> · <a href=\"/docs/mdbook/source/v0-5-4/mdbook-original.tar.gz\">Complete fixed upstream source</a>. · <a href=\"/docs/mdbook/source/v0-5-4/source.zip\">Editable source and build context</a>.</p>"}, {"kind": "editorial", "html": "<p>Static Libx presentation: examples show their complete code, including lines hidden in the original demo. Editing, code execution and MathJax rendering are provided by the <a href=\"https://github.com/rust-lang/mdBook/blob/2ea30c00f00647d2b3f4c0f79b3e0e1eabc0b66d/guide/src/format/theme/README.md\">original project</a>; formula examples retain their original TeX notation here. The document text and expanded examples are retained. This is an unofficial Libx static edition. Original text and examples are preserved; translated pages are identified separately.</p>"}]
prev: {"text": "Environment variables", "link": "/v0-5-4/en/01-guide/16-format-configuration-environment-variables"}
next: {"text": "index.hbs", "link": "/v0-5-4/en/01-guide/26-format-theme-index-hbs"}
---


<div class="mdbook-guide">
<h1 id="theme"><a class="header" href="#theme">Theme</a></h1>
<p>The default renderer uses a <a href="https://handlebarsjs.com">handlebars</a> template to
render your markdown files and comes with a default theme included in the mdBook
binary.</p>
<p>The theme is totally customizable, you can selectively replace every file from
the theme by your own by adding a <code>theme</code> directory next to <code>src</code> folder in your
project root. Create a new file with the name of the file you want to override
and now that file will be used instead of the default file.</p>
<p>Here are the files you can override:</p>
<ul>
<li><strong><em>index.hbs</em></strong> is the handlebars template.</li>
<li><strong><em>head.hbs</em></strong> is appended to the HTML <code>&#x3C;head></code> section.</li>
<li><strong><em>header.hbs</em></strong> content is appended on top of every book page.</li>
<li><strong><em>css/</em></strong> contains the CSS files for styling the book.
<ul>
<li><strong><em>css/chrome.css</em></strong> is for UI elements.</li>
<li><strong><em>css/general.css</em></strong> is the base styles.</li>
<li><strong><em>css/print.css</em></strong> is the style for printer output.</li>
<li><strong><em>css/variables.css</em></strong> contains variables used in other CSS files.</li>
</ul>
</li>
<li><strong><em>book.js</em></strong> is mostly used to add client side functionality, like hiding /
un-hiding the sidebar, changing the theme, …</li>
<li><strong><em>highlight.js</em></strong> is the JavaScript that is used to highlight code snippets,
you should not need to modify this.</li>
<li><strong><em>highlight.css</em></strong> is the theme used for the code highlighting.</li>
<li><strong><em>favicon.svg</em></strong> and <strong><em>favicon.png</em></strong> the favicon that will be used. The SVG
version is used by <a href="https://caniuse.com/#feat=link-icon-svg">newer browsers</a>.</li>
<li><strong>fonts/fonts.css</strong> contains the definition of which fonts to load.
Custom fonts can be included in the <code>fonts</code> directory.</li>
</ul>
<p>Generally, when you want to tweak the theme, you don’t need to override all the
files. If you only need changes in the stylesheet, there is no point in
overriding all the other files. Because custom files take precedence over
built-in ones, they will not get updated with new fixes / features.</p>
<p><strong>Note:</strong> When you override a file, it is possible that you break some
functionality. Therefore I recommend to use the file from the default theme as
template and only add / modify what you need. You can copy the default theme
into your source directory automatically by using <code>mdbook init --theme</code> and just
remove the files you don’t want to override.</p>
<p><code>mdbook init --theme</code> will not create every file listed above.
Some files, such as <code>head.hbs</code>, do not have built-in equivalents.
Just create the file if you need it.</p>
<p>If you completely replace all built-in themes, be sure to also set
<a href="/docs/mdbook/v0-5-4/en/01-guide/19-format-configuration-renderers/#html-renderer-options"><code>output.html.preferred-dark-theme</code></a> in the config, which defaults to the
built-in <code>navy</code> theme.</p>
</div>
