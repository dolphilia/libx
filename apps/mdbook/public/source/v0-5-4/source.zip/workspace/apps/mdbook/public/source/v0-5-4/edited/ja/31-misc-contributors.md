---
title: "mdBook：貢献者"
documentId: "mdbook:guide/src/misc/contributors.md"
order: 31
licenseSource: "mdbook-guide"
documentContext: [{"kind": "source", "html": "<p>mdBook 0.5.4公式文書の非公式日本語訳。文書とその翻訳はMPL-2.0。<a href=\"https://github.com/rust-lang/mdBook/blob/2ea30c00f00647d2b3f4c0f79b3e0e1eabc0b66d/guide/src/misc/contributors.md\">固定した原典</a> · <a href=\"/docs/mdbook/source/v0-5-4/edited/ja/31-misc-contributors.md\">編集可能な日本語文書</a> · <a href=\"/docs/mdbook/source/v0-5-4/mdbook-original.tar.gz\">固定原資料一式</a>。 · <a href=\"/docs/mdbook/source/v0-5-4/source.zip\">編集可能な英日原稿とビルド資料</a>.</p>"}, {"kind": "editorial", "html": "<p>Libxでは全文・コード・図・原目次を静的に提供します。原著の編集・実行機能は原典を参照してください。コードの非表示行は全表示し、数式は原TeX表記を保持します。章の操作説明はmdBookが生成した元の本を対象とします。</p>"}]
prev: {"text": "代替バックエンド", "link": "/v0-5-4/ja/01-guide/12-for_developers-backends"}
---


<div class="mdbook-guide">
<h1 id="contributors"><a class="header" href="#contributors">貢献者</a></h1>
<p>mdBookの改善に協力した貢献者の一覧です。皆さんに大きな感謝を！</p>
<ul>
<li><a href="https://github.com/mdinger">mdinger</a></li>
<li>Kevin (<a href="https://github.com/kbknapp">kbknapp</a>)</li>
<li>Steve Klabnik (<a href="https://github.com/steveklabnik">steveklabnik</a>)</li>
<li>Adam Solove (<a href="https://github.com/asolove">asolove</a>)</li>
<li>Wayne Nilsen (<a href="https://github.com/waynenilsen">waynenilsen</a>)</li>
<li><a href="https://github.com/funkill">funnkill</a></li>
<li>Fu Gangqiang (<a href="https://github.com/FuGangqiang">FuGangqiang</a>)</li>
<li><a href="https://github.com/Michael-F-Bryan">Michael-F-Bryan</a></li>
<li>Chris Spiegel (<a href="https://github.com/cspiegel">cspiegel</a>)</li>
<li><a href="https://github.com/projektir">projektir</a></li>
<li><a href="https://github.com/Phaiax">Phaiax</a></li>
<li>Matt Ickstadt (<a href="https://github.com/mattico">mattico</a>)</li>
<li>Weihang Lo (<a href="https://github.com/weihanglo">weihanglo</a>)</li>
<li>Avision Ho (<a href="https://github.com/avisionh">avisionh</a>)</li>
<li>Vivek Akupatni (<a href="https://github.com/apatniv">apatniv</a>)</li>
<li>Eric Huss (<a href="https://github.com/ehuss">ehuss</a>)</li>
<li>Josh Rotenberg (<a href="https://github.com/joshrotenberg">joshrotenberg</a>)</li>
</ul>
<p>この一覧に自分が載っていないと思った場合は、プルリクエストで追加してください。</p>
</div>
