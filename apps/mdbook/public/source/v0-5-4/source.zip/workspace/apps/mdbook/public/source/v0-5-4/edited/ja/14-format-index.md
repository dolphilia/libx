---
title: "mdBook：形式"
documentId: "mdbook:guide/src/format/README.md"
order: 13
licenseSource: "mdbook-guide"
documentContext: [{"kind": "source", "html": "<p>mdBook 0.5.4公式文書の非公式日本語訳。文書とその翻訳はMPL-2.0。<a href=\"https://github.com/rust-lang/mdBook/blob/2ea30c00f00647d2b3f4c0f79b3e0e1eabc0b66d/guide/src/format/README.md\">固定した原典</a> · <a href=\"/docs/mdbook/source/v0-5-4/edited/ja/14-format-index.md\">編集可能な日本語文書</a> · <a href=\"/docs/mdbook/source/v0-5-4/mdbook-original.tar.gz\">固定原資料一式</a>。 · <a href=\"/docs/mdbook/source/v0-5-4/source.zip\">編集可能な英日原稿とビルド資料</a>.</p>"}, {"kind": "editorial", "html": "<p>Libxでは全文・コード・図・原目次を静的に提供します。原著の編集・実行機能は原典を参照してください。コードの非表示行は全表示し、数式は原TeX表記を保持します。章の操作説明はmdBookが生成した元の本を対象とします。</p>"}]
prev: {"text": "completions", "link": "/v0-5-4/ja/01-guide/05-cli-completions"}
next: {"text": "SUMMARY.md", "link": "/v0-5-4/ja/01-guide/23-format-summary"}
---


<div class="mdbook-guide">
<h1 id="format"><a class="header" href="#format">形式</a></h1>
<p>この節では、次の方法を説明します。</p>
<ul>
<li>本を正しく構成する</li>
<li><code>SUMMARY.md</code>ファイルの書式を指定する</li>
<li><code>book.toml</code>で本を設定する</li>
<li>テーマをカスタマイズする</li>
</ul>
</div>
