#!/bin/sh
# Test 'time' with a trailing backslash in the format string.

# Copyright (C) 2026 Free Software Foundation, Inc.

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

. "${srcdir=.}/tests/init.sh"; path_prepend_ ./src

# In all versions before 1.10, this would append the program name to the
# expected output.  I.e. "abc?\true".
env time -o out -f 'abc\' true || fail=1
echo 'abc?\' > exp || framework_failure_
compare exp out || fail=1

Exit $fail
