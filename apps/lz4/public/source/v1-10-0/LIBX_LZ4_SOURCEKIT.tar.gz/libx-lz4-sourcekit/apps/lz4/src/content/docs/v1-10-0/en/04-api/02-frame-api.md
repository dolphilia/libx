---
title: "LZ4: doc/lz4frame_manual.html"
licenseSource: "lz4-1-10-0-doc-lz4frame-manual-html"
documentContext:
  - kind: source
    html: "<p>Unofficial Libx presentation of the fixed LZ4 1.10.0 English original. Formatting and link mapping: 2026-10-05. Original commit: <code>ebb370ca83af193212df4dcbadcc5d87bc0de2f0</code>; SHA-256: <code>16d83fc4920d1df5e26c3de9e1c6c24fe0233033fb1c8c52c0ef689cb20a11d3</code>. <a href=\"https://github.com/lz4/lz4/blob/ebb370ca83af193212df4dcbadcc5d87bc0de2f0/doc/lz4frame_manual.html\">Fixed upstream source</a>; <a href=\"/docs/lz4/source/v1-10-0/originals/doc/lz4frame_manual.html.txt\">Unmodified original and its notices</a>; <a href=\"/docs/lz4/source/v1-10-0/LZ4_FIXED.tar.gz\">Complete fixed upstream archive</a>; <a href=\"/docs/lz4/source/v1-10-0/licenses/UPSTREAM_LICENSE.txt\">Upstream license allocation notice</a>. Original copyright, permission, and warranty notices are retained. Japanese translations are unofficial.</p><p>Under Libx’s operating policy, where no documentation-specific license statement was found, the software license identified for this material is applied to this documentation. Applicable terms: GPL-2.0-or-later（本掲載はversion2条件を履行）. This is an operational decision, not a newly obtained permission.</p><p>Presentation changes: remove outer HTML/head/style/body wrappers; escape literal angle text outside fixed generator grammar; protect literal backticks; separate block headings; retain named anchors and additionally set identical id. No technical prose has been silently corrected or summarized.</p>"
  - kind: editorial
    html: "<p>This generated manual omits LZ4F_getVersion, LZ4F_getErrorCode, LZ4F_createCompressionContext_advanced, LZ4F_createDecompressionContext_advanced, and LZ4F_createCDict_advanced. The complete fixed lz4frame.h is included as a separate page. The original prose also uses LZ4_flush and LZ4_createCDict/LZ4_CDict where declarations use LZ4F names; these original spellings are retained. Literal &lt;stdlib.h&gt; is displayed as text rather than interpreted as an HTML tag.</p>"
---


<h1>1.10.0 Manual</h1>

<hr>
<a name="Contents" id="Contents"></a><h2>Contents</h2>

<ol>
<li><a href="#Chapter1">Introduction</a></li>
<li><a href="#Chapter2">Compiler specifics</a></li>
<li><a href="#Chapter3">Error management</a></li>
<li><a href="#Chapter4">Frame compression types</a></li>
<li><a href="#Chapter5">Simple compression function</a></li>
<li><a href="#Chapter6">Advanced compression functions</a></li>
<li><a href="#Chapter7">Resource Management</a></li>
<li><a href="#Chapter8">Compression</a></li>
<li><a href="#Chapter9">Decompression functions</a></li>
<li><a href="#Chapter10">Streaming decompression functions</a></li>
<li><a href="#Chapter11">Dictionary compression API</a></li>
<li><a href="#Chapter12">Bulk processing dictionary compression</a></li>
<li><a href="#Chapter13">Advanced compression operations</a></li>
<li><a href="#Chapter14">Custom memory allocation</a></li>
</ol>
<hr>
<a name="Chapter1" id="Chapter1"></a><h2>Introduction</h2>
<pre>
 lz4frame.h implements LZ4 frame specification: see doc/lz4_Frame_format.md .
 LZ4 Frames are compatible with &#96;lz4&#96; CLI,
 and designed to be interoperable with any system.
<BR></pre>

<a name="Chapter2" id="Chapter2"></a><h2>Compiler specifics</h2>
<pre></pre>

<a name="Chapter3" id="Chapter3"></a><h2>Error management</h2>
<pre></pre>

<pre><b>unsigned    LZ4F_isError(LZ4F_errorCode_t code);   </b>/**&lt; tells when a function result is an error code */<b>
</b></pre><BR>
<pre><b>const char* LZ4F_getErrorName(LZ4F_errorCode_t code);   </b>/**&lt; return error code string; for debugging */<b>
</b></pre><BR>
<a name="Chapter4" id="Chapter4"></a><h2>Frame compression types</h2>
<pre> 
<BR></pre>

<pre><b>typedef enum {
    LZ4F_default=0,
    LZ4F_max64KB=4,
    LZ4F_max256KB=5,
    LZ4F_max1MB=6,
    LZ4F_max4MB=7
    LZ4F_OBSOLETE_ENUM(max64KB)
    LZ4F_OBSOLETE_ENUM(max256KB)
    LZ4F_OBSOLETE_ENUM(max1MB)
    LZ4F_OBSOLETE_ENUM(max4MB)
} LZ4F_blockSizeID_t;
</b></pre><BR>
<pre><b>typedef enum {
    LZ4F_blockLinked=0,
    LZ4F_blockIndependent
    LZ4F_OBSOLETE_ENUM(blockLinked)
    LZ4F_OBSOLETE_ENUM(blockIndependent)
} LZ4F_blockMode_t;
</b></pre><BR>
<pre><b>typedef enum {
    LZ4F_noContentChecksum=0,
    LZ4F_contentChecksumEnabled
    LZ4F_OBSOLETE_ENUM(noContentChecksum)
    LZ4F_OBSOLETE_ENUM(contentChecksumEnabled)
} LZ4F_contentChecksum_t;
</b></pre><BR>
<pre><b>typedef enum {
    LZ4F_noBlockChecksum=0,
    LZ4F_blockChecksumEnabled
} LZ4F_blockChecksum_t;
</b></pre><BR>
<pre><b>typedef enum {
    LZ4F_frame=0,
    LZ4F_skippableFrame
    LZ4F_OBSOLETE_ENUM(skippableFrame)
} LZ4F_frameType_t;
</b></pre><BR>
<pre><b>typedef struct {
  LZ4F_blockSizeID_t     blockSizeID;         </b>/* max64KB, max256KB, max1MB, max4MB; 0 == default (LZ4F_max64KB) */<b>
  LZ4F_blockMode_t       blockMode;           </b>/* LZ4F_blockLinked, LZ4F_blockIndependent; 0 == default (LZ4F_blockLinked) */<b>
  LZ4F_contentChecksum_t contentChecksumFlag; </b>/* 1: add a 32-bit checksum of frame's decompressed data; 0 == default (disabled) */<b>
  LZ4F_frameType_t       frameType;           </b>/* read-only field : LZ4F_frame or LZ4F_skippableFrame */<b>
  unsigned long long     contentSize;         </b>/* Size of uncompressed content ; 0 == unknown */<b>
  unsigned               dictID;              </b>/* Dictionary ID, sent by compressor to help decoder select correct dictionary; 0 == no dictID provided */<b>
  LZ4F_blockChecksum_t   blockChecksumFlag;   </b>/* 1: each block followed by a checksum of block's compressed data; 0 == default (disabled) */<b>
} LZ4F_frameInfo_t;
</b><p>  makes it possible to set or read frame parameters.
  Structure must be first init to 0, using memset() or LZ4F_INIT_FRAMEINFO,
  setting all parameters to default.
  It's then possible to update selectively some parameters 
</p></pre><BR>

<pre><b>typedef struct {
  LZ4F_frameInfo_t frameInfo;
  int      compressionLevel;    </b>/* 0: default (fast mode); values > LZ4HC_CLEVEL_MAX count as LZ4HC_CLEVEL_MAX; values &lt; 0 trigger "fast acceleration" */<b>
  unsigned autoFlush;           </b>/* 1: always flush; reduces usage of internal buffers */<b>
  unsigned favorDecSpeed;       </b>/* 1: parser favors decompression speed vs compression ratio. Only works for high compression modes (>= LZ4HC_CLEVEL_OPT_MIN) */  /* v1.8.2+ */<b>
  unsigned reserved[3];         </b>/* must be zero for forward compatibility */<b>
} LZ4F_preferences_t;
</b><p>  makes it possible to supply advanced compression instructions to streaming interface.
  Structure must be first init to 0, using memset() or LZ4F_INIT_PREFERENCES,
  setting all parameters to default.
  All reserved fields must be set to zero. 
</p></pre><BR>

<a name="Chapter5" id="Chapter5"></a><h2>Simple compression function</h2>
<pre></pre>

<pre><b>size_t LZ4F_compressFrame(void* dstBuffer, size_t dstCapacity,
                                const void* srcBuffer, size_t srcSize,
                                const LZ4F_preferences_t* preferencesPtr);
</b><p>  Compress srcBuffer content into an LZ4-compressed frame.
  It's a one shot operation, all input content is consumed, and all output is generated.

  Note : it's a stateless operation (no LZ4F_cctx state needed).
  In order to reduce load on the allocator, LZ4F_compressFrame(), by default,
  uses the stack to allocate space for the compression state and some table.
  If this usage of the stack is too much for your application,
  consider compiling &#96;lz4frame.c&#96; with compile-time macro LZ4F_HEAPMODE set to 1 instead.
  All state allocations will use the Heap.
  It also means each invocation of LZ4F_compressFrame() will trigger several internal alloc/free invocations.

 @dstCapacity MUST be >= LZ4F_compressFrameBound(srcSize, preferencesPtr).
 @preferencesPtr is optional : one can provide NULL, in which case all preferences are set to default.
 @return : number of bytes written into dstBuffer.
           or an error code if it fails (can be tested using LZ4F_isError())
 
</p></pre><BR>

<pre><b>size_t LZ4F_compressFrameBound(size_t srcSize, const LZ4F_preferences_t* preferencesPtr);
</b><p>  Returns the maximum possible compressed size with LZ4F_compressFrame() given srcSize and preferences.
 &#96;preferencesPtr&#96; is optional. It can be replaced by NULL, in which case, the function will assume default preferences.
  Note : this result is only usable with LZ4F_compressFrame().
         It may also be relevant to LZ4F_compressUpdate() _only if_ no flush() operation is ever performed.
 
</p></pre><BR>

<pre><b>int LZ4F_compressionLevel_max(void);   </b>/* v1.8.0+ */<b>
</b><p> @return maximum allowed compression level (currently: 12)
 
</p></pre><BR>

<a name="Chapter6" id="Chapter6"></a><h2>Advanced compression functions</h2>
<pre></pre>

<pre><b>typedef struct {
  unsigned stableSrc;    </b>/* 1 == src content will remain present on future calls to LZ4F_compress(); skip copying src content within tmp buffer */<b>
  unsigned reserved[3];
} LZ4F_compressOptions_t;
</b></pre><BR>
<a name="Chapter7" id="Chapter7"></a><h2>Resource Management</h2>
<pre></pre>

<pre><b>LZ4F_errorCode_t LZ4F_createCompressionContext(LZ4F_cctx** cctxPtr, unsigned version);
LZ4F_errorCode_t LZ4F_freeCompressionContext(LZ4F_cctx* cctx);
</b><p>  The first thing to do is to create a compressionContext object,
  which will keep track of operation state during streaming compression.
  This is achieved using LZ4F_createCompressionContext(), which takes as argument a version,
  and a pointer to LZ4F_cctx*, to write the resulting pointer into.
  @version provided MUST be LZ4F_VERSION. It is intended to track potential version mismatch, notably when using DLL.
  The function provides a pointer to a fully allocated LZ4F_cctx object.
  @cctxPtr MUST be != NULL.
  If @return != zero, context creation failed.
  A created compression context can be employed multiple times for consecutive streaming operations.
  Once all streaming compression jobs are completed,
  the state object can be released using LZ4F_freeCompressionContext().
  Note1 : LZ4F_freeCompressionContext() is always successful. Its return value can be ignored.
  Note2 : LZ4F_freeCompressionContext() works fine with NULL input pointers (do nothing).
</p></pre><BR>

<a name="Chapter8" id="Chapter8"></a><h2>Compression</h2>
<pre></pre>

<pre><b>size_t LZ4F_compressBegin(LZ4F_cctx* cctx,
                                      void* dstBuffer, size_t dstCapacity,
                                      const LZ4F_preferences_t* prefsPtr);
</b><p>  will write the frame header into dstBuffer.
  dstCapacity must be >= LZ4F_HEADER_SIZE_MAX bytes.
 &#96;prefsPtr&#96; is optional : NULL can be provided to set all preferences to default.
 @return : number of bytes written into dstBuffer for the header
           or an error code (which can be tested using LZ4F_isError())
 
</p></pre><BR>

<pre><b>size_t LZ4F_compressBound(size_t srcSize, const LZ4F_preferences_t* prefsPtr);
</b><p>  Provides minimum dstCapacity required to guarantee success of
  LZ4F_compressUpdate(), given a srcSize and preferences, for a worst case scenario.
  When srcSize==0, LZ4F_compressBound() provides an upper bound for LZ4F_flush() and LZ4F_compressEnd() instead.
  Note that the result is only valid for a single invocation of LZ4F_compressUpdate().
  When invoking LZ4F_compressUpdate() multiple times,
  if the output buffer is gradually filled up instead of emptied and re-used from its start,
  one must check if there is enough remaining capacity before each invocation, using LZ4F_compressBound().
 @return is always the same for a srcSize and prefsPtr.
  prefsPtr is optional : when NULL is provided, preferences will be set to cover worst case scenario.
  tech details :
 @return if automatic flushing is not enabled, includes the possibility that internal buffer might already be filled by up to (blockSize-1) bytes.
  It also includes frame footer (ending + checksum), since it might be generated by LZ4F_compressEnd().
 @return doesn't include frame header, as it was already generated by LZ4F_compressBegin().
 
</p></pre><BR>

<pre><b>size_t LZ4F_compressUpdate(LZ4F_cctx* cctx,
                                       void* dstBuffer, size_t dstCapacity,
                                 const void* srcBuffer, size_t srcSize,
                                 const LZ4F_compressOptions_t* cOptPtr);
</b><p>  LZ4F_compressUpdate() can be called repetitively to compress as much data as necessary.
  Important rule: dstCapacity MUST be large enough to ensure operation success even in worst case situations.
  This value is provided by LZ4F_compressBound().
  If this condition is not respected, LZ4F_compress() will fail (result is an errorCode).
  After an error, the state is left in a UB state, and must be re-initialized or freed.
  If previously an uncompressed block was written, buffered data is flushed
  before appending compressed data is continued.
 &#96;cOptPtr&#96; is optional : NULL can be provided, in which case all options are set to default.
 @return : number of bytes written into &#96;dstBuffer&#96; (it can be zero, meaning input data was just buffered).
           or an error code if it fails (which can be tested using LZ4F_isError())
 
</p></pre><BR>

<pre><b>size_t LZ4F_flush(LZ4F_cctx* cctx,
                              void* dstBuffer, size_t dstCapacity,
                        const LZ4F_compressOptions_t* cOptPtr);
</b><p>  When data must be generated and sent immediately, without waiting for a block to be completely filled,
  it's possible to call LZ4_flush(). It will immediately compress any data buffered within cctx.
 &#96;dstCapacity&#96; must be large enough to ensure the operation will be successful.
 &#96;cOptPtr&#96; is optional : it's possible to provide NULL, all options will be set to default.
 @return : nb of bytes written into dstBuffer (can be zero, when there is no data stored within cctx)
           or an error code if it fails (which can be tested using LZ4F_isError())
  Note : LZ4F_flush() is guaranteed to be successful when dstCapacity >= LZ4F_compressBound(0, prefsPtr).
 
</p></pre><BR>

<pre><b>size_t LZ4F_compressEnd(LZ4F_cctx* cctx,
                                    void* dstBuffer, size_t dstCapacity,
                              const LZ4F_compressOptions_t* cOptPtr);
</b><p>  To properly finish an LZ4 frame, invoke LZ4F_compressEnd().
  It will flush whatever data remained within &#96;cctx&#96; (like LZ4_flush())
  and properly finalize the frame, with an endMark and a checksum.
 &#96;cOptPtr&#96; is optional : NULL can be provided, in which case all options will be set to default.
 @return : nb of bytes written into dstBuffer, necessarily >= 4 (endMark),
           or an error code if it fails (which can be tested using LZ4F_isError())
  Note : LZ4F_compressEnd() is guaranteed to be successful when dstCapacity >= LZ4F_compressBound(0, prefsPtr).
  A successful call to LZ4F_compressEnd() makes &#96;cctx&#96; available again for another compression task.
 
</p></pre><BR>

<a name="Chapter9" id="Chapter9"></a><h2>Decompression functions</h2>
<pre></pre>

<pre><b>typedef struct {
  unsigned stableDst;     /* pledges that last 64KB decompressed data is present right before @dstBuffer pointer.
                           * This optimization skips internal storage operations.
                           * Once set, this pledge must remain valid up to the end of current frame. */
  unsigned skipChecksums; /* disable checksum calculation and verification, even when one is present in frame, to save CPU time.
                           * Setting this option to 1 once disables all checksums for the rest of the frame. */
  unsigned reserved1;     </b>/* must be set to zero for forward compatibility */<b>
  unsigned reserved0;     </b>/* idem */<b>
} LZ4F_decompressOptions_t;
</b></pre><BR>
<pre><b>LZ4F_errorCode_t LZ4F_createDecompressionContext(LZ4F_dctx** dctxPtr, unsigned version);
LZ4F_errorCode_t LZ4F_freeDecompressionContext(LZ4F_dctx* dctx);
</b><p>  Create an LZ4F_dctx object, to track all decompression operations.
  @version provided MUST be LZ4F_VERSION.
  @dctxPtr MUST be valid.
  The function fills @dctxPtr with the value of a pointer to an allocated and initialized LZ4F_dctx object.
  The @return is an errorCode, which can be tested using LZ4F_isError().
  dctx memory can be released using LZ4F_freeDecompressionContext();
  Result of LZ4F_freeDecompressionContext() indicates current state of decompressionContext when being released.
  That is, it should be == 0 if decompression has been completed fully and correctly.
 
</p></pre><BR>

<a name="Chapter10" id="Chapter10"></a><h2>Streaming decompression functions</h2>
<pre></pre>

<pre><b>size_t LZ4F_headerSize(const void* src, size_t srcSize);
</b><p>  Provide the header size of a frame starting at &#96;src&#96;.
 &#96;srcSize&#96; must be >= LZ4F_MIN_SIZE_TO_KNOW_HEADER_LENGTH,
  which is enough to decode the header length.
 @return : size of frame header
           or an error code, which can be tested using LZ4F_isError()
  note : Frame header size is variable, but is guaranteed to be
         >= LZ4F_HEADER_SIZE_MIN bytes, and &lt;= LZ4F_HEADER_SIZE_MAX bytes.
 
</p></pre><BR>

<pre><b>size_t
LZ4F_getFrameInfo(LZ4F_dctx* dctx,
                  LZ4F_frameInfo_t* frameInfoPtr,
            const void* srcBuffer, size_t* srcSizePtr);
</b><p>  This function extracts frame parameters (max blockSize, dictID, etc.).
  Its usage is optional: user can also invoke LZ4F_decompress() directly.

  Extracted information will fill an existing LZ4F_frameInfo_t structure.
  This can be useful for allocation and dictionary identification purposes.

  LZ4F_getFrameInfo() can work in the following situations :

  1) At the beginning of a new frame, before any invocation of LZ4F_decompress().
     It will decode header from &#96;srcBuffer&#96;,
     consuming the header and starting the decoding process.

     Input size must be large enough to contain the full frame header.
     Frame header size can be known beforehand by LZ4F_headerSize().
     Frame header size is variable, but is guaranteed to be >= LZ4F_HEADER_SIZE_MIN bytes,
     and not more than &lt;= LZ4F_HEADER_SIZE_MAX bytes.
     Hence, blindly providing LZ4F_HEADER_SIZE_MAX bytes or more will always work.
     It's allowed to provide more input data than the header size,
     LZ4F_getFrameInfo() will only consume the header.

     If input size is not large enough,
     aka if it's smaller than header size,
     function will fail and return an error code.

  2) After decoding has been started,
     it's possible to invoke LZ4F_getFrameInfo() anytime
     to extract already decoded frame parameters stored within dctx.

     Note that, if decoding has barely started,
     and not yet read enough information to decode the header,
     LZ4F_getFrameInfo() will fail.

  The number of bytes consumed from srcBuffer will be updated in *srcSizePtr (necessarily &lt;= original value).
  LZ4F_getFrameInfo() only consumes bytes when decoding has not yet started,
  and when decoding the header has been successful.
  Decompression must then resume from (srcBuffer + *srcSizePtr).

 @return : a hint about how many srcSize bytes LZ4F_decompress() expects for next call,
           or an error code which can be tested using LZ4F_isError().
  note 1 : in case of error, dctx is not modified. Decoding operation can resume from beginning safely.
  note 2 : frame parameters are *copied into* an already allocated LZ4F_frameInfo_t structure.
 
</p></pre><BR>

<pre><b>size_t
LZ4F_decompress(LZ4F_dctx* dctx,
                void* dstBuffer, size_t* dstSizePtr,
          const void* srcBuffer, size_t* srcSizePtr,
          const LZ4F_decompressOptions_t* dOptPtr);
</b><p>  Call this function repetitively to regenerate data compressed in &#96;srcBuffer&#96;.

  The function requires a valid dctx state.
  It will read up to *srcSizePtr bytes from srcBuffer,
  and decompress data into dstBuffer, of capacity *dstSizePtr.

  The nb of bytes consumed from srcBuffer will be written into *srcSizePtr (necessarily &lt;= original value).
  The nb of bytes decompressed into dstBuffer will be written into *dstSizePtr (necessarily &lt;= original value).

  The function does not necessarily read all input bytes, so always check value in *srcSizePtr.
  Unconsumed source data must be presented again in subsequent invocations.

 &#96;dstBuffer&#96; can freely change between each consecutive function invocation.
 &#96;dstBuffer&#96; content will be overwritten.

  Note: if &#96;LZ4F_getFrameInfo()&#96; is called before &#96;LZ4F_decompress()&#96;, srcBuffer must be updated to reflect
  the number of bytes consumed after reading the frame header. Failure to update srcBuffer before calling
  &#96;LZ4F_decompress()&#96; will cause decompression failure or, even worse, successful but incorrect decompression.
  See the &#96;LZ4F_getFrameInfo()&#96; docs for details.

 @return : an hint of how many &#96;srcSize&#96; bytes LZ4F_decompress() expects for next call.
  Schematically, it's the size of the current (or remaining) compressed block + header of next block.
  Respecting the hint provides some small speed benefit, because it skips intermediate buffers.
  This is just a hint though, it's always possible to provide any srcSize.

  When a frame is fully decoded, @return will be 0 (no more data expected).
  When provided with more bytes than necessary to decode a frame,
  LZ4F_decompress() will stop reading exactly at end of current frame, and @return 0.

  If decompression failed, @return is an error code, which can be tested using LZ4F_isError().
  After a decompression error, the &#96;dctx&#96; context is not resumable.
  Use LZ4F_resetDecompressionContext() to return to clean state.

  After a frame is fully decoded, dctx can be used again to decompress another frame.
 
</p></pre><BR>

<pre><b>void LZ4F_resetDecompressionContext(LZ4F_dctx* dctx);   </b>/* always successful */<b>
</b><p>  In case of an error, the context is left in "undefined" state.
  In which case, it's necessary to reset it, before re-using it.
  This method can also be used to abruptly stop any unfinished decompression,
  and start a new one using same context resources. 
</p></pre><BR>

<a name="Chapter11" id="Chapter11"></a><h2>Dictionary compression API</h2>
<pre></pre>

<pre><b>size_t
LZ4F_compressBegin_usingDict(LZ4F_cctx* cctx,
                            void* dstBuffer, size_t dstCapacity,
                      const void* dictBuffer, size_t dictSize,
                      const LZ4F_preferences_t* prefsPtr);
</b><p>  Inits dictionary compression streaming, and writes the frame header into dstBuffer.
 @dstCapacity must be >= LZ4F_HEADER_SIZE_MAX bytes.
 @prefsPtr is optional : one may provide NULL as argument,
  however, it's the only way to provide dictID in the frame header.
 @dictBuffer must outlive the compression session.
 @return : number of bytes written into dstBuffer for the header,
           or an error code (which can be tested using LZ4F_isError())
  NOTE: The LZ4Frame spec allows each independent block to be compressed with the dictionary,
        but this entry supports a more limited scenario, where only the first block uses the dictionary.
        This is still useful for small data, which only need one block anyway.
        For larger inputs, one may be more interested in LZ4F_compressFrame_usingCDict() below.
 
</p></pre><BR>

<pre><b>size_t
LZ4F_decompress_usingDict(LZ4F_dctx* dctxPtr,
                          void* dstBuffer, size_t* dstSizePtr,
                    const void* srcBuffer, size_t* srcSizePtr,
                    const void* dict, size_t dictSize,
                    const LZ4F_decompressOptions_t* decompressOptionsPtr);
</b><p>  Same as LZ4F_decompress(), using a predefined dictionary.
  Dictionary is used "in place", without any preprocessing.
  It must remain accessible throughout the entire frame decoding. 
</p></pre><BR>

<a name="Chapter12" id="Chapter12"></a><h2>Bulk processing dictionary compression</h2>
<pre></pre>

<pre><b>LZ4F_CDict* LZ4F_createCDict(const void* dictBuffer, size_t dictSize);
void        LZ4F_freeCDict(LZ4F_CDict* CDict);
</b><p>  When compressing multiple messages / blocks using the same dictionary, it's recommended to initialize it just once.
  LZ4_createCDict() will create a digested dictionary, ready to start future compression operations without startup delay.
  LZ4_CDict can be created once and shared by multiple threads concurrently, since its usage is read-only.
 @dictBuffer can be released after LZ4_CDict creation, since its content is copied within CDict. 
</p></pre><BR>

<pre><b>size_t
LZ4F_compressFrame_usingCDict(LZ4F_cctx* cctx,
                              void* dst, size_t dstCapacity,
                        const void* src, size_t srcSize,
                        const LZ4F_CDict* cdict,
                        const LZ4F_preferences_t* preferencesPtr);
</b><p>  Compress an entire srcBuffer into a valid LZ4 frame using a digested Dictionary.
 @cctx must point to a context created by LZ4F_createCompressionContext().
  If @cdict==NULL, compress without a dictionary.
 @dstBuffer MUST be >= LZ4F_compressFrameBound(srcSize, preferencesPtr).
  If this condition is not respected, function will fail (@return an errorCode).
  The LZ4F_preferences_t structure is optional : one may provide NULL as argument,
  but it's not recommended, as it's the only way to provide @dictID in the frame header.
 @return : number of bytes written into dstBuffer.
           or an error code if it fails (can be tested using LZ4F_isError())
  Note: for larger inputs generating multiple independent blocks,
        this entry point uses the dictionary for each block. 
</p></pre><BR>

<pre><b>size_t
LZ4F_compressBegin_usingCDict(LZ4F_cctx* cctx,
                              void* dstBuffer, size_t dstCapacity,
                        const LZ4F_CDict* cdict,
                        const LZ4F_preferences_t* prefsPtr);
</b><p>  Inits streaming dictionary compression, and writes the frame header into dstBuffer.
 @dstCapacity must be >= LZ4F_HEADER_SIZE_MAX bytes.
 @prefsPtr is optional : one may provide NULL as argument,
  note however that it's the only way to insert a @dictID in the frame header.
 @cdict must outlive the compression session.
 @return : number of bytes written into dstBuffer for the header,
           or an error code, which can be tested using LZ4F_isError(). 
</p></pre><BR>

<pre><b>typedef enum { LZ4F_LIST_ERRORS(LZ4F_GENERATE_ENUM)
              _LZ4F_dummy_error_enum_for_c89_never_used } LZ4F_errorCodes;
</b></pre><BR>
<a name="Chapter13" id="Chapter13"></a><h2>Advanced compression operations</h2>
<pre></pre>

<pre><b>LZ4FLIB_STATIC_API size_t LZ4F_getBlockSize(LZ4F_blockSizeID_t blockSizeID);
</b><p> @return, in scalar format (size_t),
          the maximum block size associated with @blockSizeID,
          or an error code (can be tested using LZ4F_isError()) if @blockSizeID is invalid.
</p></pre><BR>

<pre><b>LZ4FLIB_STATIC_API size_t
LZ4F_uncompressedUpdate(LZ4F_cctx* cctx,
                        void* dstBuffer, size_t dstCapacity,
                  const void* srcBuffer, size_t srcSize,
                  const LZ4F_compressOptions_t* cOptPtr);
</b><p>  LZ4F_uncompressedUpdate() can be called repetitively to add data stored as uncompressed blocks.
  Important rule: dstCapacity MUST be large enough to store the entire source buffer as
  no compression is done for this operation
  If this condition is not respected, LZ4F_uncompressedUpdate() will fail (result is an errorCode).
  After an error, the state is left in a UB state, and must be re-initialized or freed.
  If previously a compressed block was written, buffered data is flushed first,
  before appending uncompressed data is continued.
  This operation is only supported when LZ4F_blockIndependent is used.
 &#96;cOptPtr&#96; is optional : NULL can be provided, in which case all options are set to default.
 @return : number of bytes written into &#96;dstBuffer&#96; (it can be zero, meaning input data was just buffered).
           or an error code if it fails (which can be tested using LZ4F_isError())
 
</p></pre><BR>

<a name="Chapter14" id="Chapter14"></a><h2>Custom memory allocation</h2>
<pre></pre>

<pre><b>typedef void* (*LZ4F_AllocFunction) (void* opaqueState, size_t size);
typedef void* (*LZ4F_CallocFunction) (void* opaqueState, size_t size);
typedef void  (*LZ4F_FreeFunction) (void* opaqueState, void* address);
typedef struct {
    LZ4F_AllocFunction customAlloc;
    LZ4F_CallocFunction customCalloc; </b>/* optional; when not defined, uses customAlloc + memset */<b>
    LZ4F_FreeFunction customFree;
    void* opaqueState;
} LZ4F_CustomMem;
static
#ifdef __GNUC__
__attribute__((__unused__))
#endif
LZ4F_CustomMem const LZ4F_defaultCMem = { NULL, NULL, NULL, NULL };  </b>/**&lt; this constant defers to stdlib's functions */<b>
</b><p>  These prototypes make it possible to pass custom allocation/free functions.
  LZ4F_customMem is provided at state creation time, using LZ4F_create*_advanced() listed below.
  All allocation/free operations will be completed using these custom variants instead of regular &lt;stdlib.h> ones.
 
</p></pre><BR>



