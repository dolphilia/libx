from pathlib import Path
import gzip,tarfile,json,hashlib,io,os
root=Path(__file__).resolve().parents[1];out=root/'apps/lz4/public/source/v1-10-0/LIBX_LZ4_SOURCEKIT.tar.gz'
skip={'node_modules','dist','.astro','.tmp','.git','__pycache__','.DS_Store'}
files=[]
for directory,dirs,names in os.walk(root):
 dirs[:]=sorted(d for d in dirs if d not in skip)
 for name in sorted(names):
  p=Path(directory)/name
  if p!=out and name!='SOURCEKIT_MANIFEST.json' and not name.endswith('.tsbuildinfo'):files.append(p)
files.sort()
assert all(not p.is_symlink() for p in files)
manifest={'format':1,'scope':'LZ4 1.10.0 Libx complete preferred modification source; original fixed source/translated documents/build scripts/shared implementation/lock/notices','files':[{'path':p.relative_to(root).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in files]}
m=root/'SOURCEKIT_MANIFEST.json';m.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');files.append(m);out.parent.mkdir(parents=True,exist_ok=True)
with out.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as t:
 for p in sorted(files):
  name='libx-lz4-sourcekit/'+p.relative_to(root).as_posix();i=tarfile.TarInfo(name);data=p.read_bytes();i.size=len(data);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(data))
print('Sourcekit archive',out.stat().st_size,'bytes',hashlib.sha256(out.read_bytes()).hexdigest())
