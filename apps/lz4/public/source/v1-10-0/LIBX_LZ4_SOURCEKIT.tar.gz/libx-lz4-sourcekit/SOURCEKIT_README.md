# LZ4 1.10.0 Libx対応ソース

固定原文208ファイル、英語定本27・日本語訳27、原通知、変換器、共有UIとテーマ、ビルド補助、固定依存lock、原ライセンス通知を収録します。node_modules、生成dist、他アプリ・Awesomeの本文は含めません。原文と翻訳のライセンスは各ページとpublic/sourceの通知が優先します。Libx自身の共有コードとビルド補助は所有者指示に基づきMITライセンスで提供します。適用範囲はSOURCEKIT_LICENSES.md、全文はLIBX_CODE_LICENSE.txtを参照してください。LZ4文書と第三者コードの既存条件を保持します。

## 再現手順

Node.js20以上、pnpm10.10.0、Python3を使います。外部Python依存は不要です。

```sh
python3 scripts/package-lz4-sourcekit.py
pnpm install --frozen-lockfile
pnpm --filter apps-lz4 build
pnpm --filter apps-lz4 check:content
pnpm --filter apps-lz4 preview --host 127.0.0.1 --port 4330
```

最初のコマンドはキット自身の圧縮アーカイブを再作成します。再帰的に自分を同梱せず、同梱ソースから再現できます。表示先はhttp://127.0.0.1:4330/docs/lz4です。Astro5.7.12の固定版プレビュー補助がgzipアーカイブを元バイトで返します。別版では再検証を要求します。Cloudflare Workersを起動しません。

このキットはLZ4の部分リポジトリです。保存済み全文レビューは同梱していますが、履歴の他アプリまで収録しないため全体の運用台帳検査は実行対象外です。本文と定本は変更しません。全文レビューの新規実施や履歴のローカルworkspace値の正規化は行っていません。

THIRD_PARTY_NOTICESは導入パッケージの原通知を保持する参考在庫です。すべての導入パッケージが配信されるという意味ではありません。依存コードは同梱せず、lockで固定した各原配布元から取得します。
