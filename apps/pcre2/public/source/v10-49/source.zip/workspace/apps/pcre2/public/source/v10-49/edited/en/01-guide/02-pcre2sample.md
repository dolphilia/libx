---
title: "Sample Program"
description: "Fixed PCRE2 10.49 original manual, with a paired Japanese translation."
documentId: "pcre2:10.49:pcre2sample"
licenseSource: pcre2-manual
---

<div class="pcre2-original-content">



<h2 id="SEC1">
PCRE2 SAMPLE PROGRAM
</h2>
<p>
A simple, complete demonstration program to get you started with using PCRE2 is
supplied in the file <i>pcre2demo.c</i> in the <b>src</b> directory in the PCRE2
distribution. A listing of this program is given in the
<a href="/docs/pcre2/source/v10-49/html/pcre2demo.html"><b>pcre2demo</b></a>
documentation. If you do not have a copy of the PCRE2 distribution, you can
save this listing to recreate the contents of <i>pcre2demo.c</i>.
</p>
<p>
The demonstration program compiles the regular expression that is its
first argument, and matches it against the subject string in its second
argument. No PCRE2 options are set, and default character tables are used. If
matching succeeds, the program outputs the portion of the subject that matched,
together with the contents of any captured substrings.
</p>
<p>
If the -g option is given on the command line, the program then goes on to
check for further matches of the same regular expression in the same subject
string. The logic is a little bit tricky because of the possibility of matching
an empty string. Comments in the code explain what is going on.
</p>
<p>
The code in <b>pcre2demo.c</b> is an 8-bit program that uses the PCRE2 8-bit
library. It handles strings and characters that are stored in 8-bit code units.
By default, one character corresponds to one code unit, but if the pattern
starts with "(*UTF)", both it and the subject are treated as UTF-8 strings,
where characters may occupy multiple code units.
</p>
<p>
If PCRE2 is installed in the standard include and library directories for your
operating system, you should be able to compile the demonstration program using
a command like this:
</p><pre><code>  cc -o pcre2demo pcre2demo.c -lpcre2-8&#10;</code></pre><p>
If PCRE2 is installed elsewhere, you may need to add additional options to the
command line. For example, on a Unix-like system that has PCRE2 installed in
<i>/usr/local</i>, you can compile the demonstration program using a command
like this:
</p><pre><code>  cc -o pcre2demo -I/usr/local/include pcre2demo.c -L/usr/local/lib -lpcre2-8&#10;</code></pre><p>
Once you have built the demonstration program, you can run simple tests like
this:
</p><pre><code>  ./pcre2demo 'cat|dog' 'the cat sat on the mat'&#10;  ./pcre2demo -g 'cat|dog' 'the dog sat on the cat'&#10;  ./pcre2demo -i 'cat' 'the dog sat on the CAT'&#10;</code></pre><p>
Note that there is a much more comprehensive test program, called
<a href="/docs/pcre2/source/v10-49/html/pcre2test.html"><b>pcre2test</b>,</a>
which supports many more facilities for testing regular expressions using all
three PCRE2 libraries (8-bit, 16-bit, and 32-bit, though not all three need be
installed). The
<a href="/docs/pcre2/source/v10-49/html/pcre2demo.html"><b>pcre2demo</b></a>
program is provided as a relatively simple coding example.
</p><p></p>
<p>
If you try to run
<a href="/docs/pcre2/source/v10-49/html/pcre2demo.html"><b>pcre2demo</b></a>
when PCRE2 is not installed in the standard library directory, you may get an
error like this on some operating systems (e.g. Solaris):
</p><pre><code>  ld.so.1: pcre2demo: fatal: libpcre2-8.so.0: open failed: No such file or directory&#10;</code></pre><p>
This is caused by the way shared library support works on those systems. You
need to add
</p><pre><code>  -R/usr/local/lib&#10;</code></pre><p>
(for example) to the compile command to get round this problem.
</p><p></p>
<h2 id="SEC2">
AUTHOR
</h2>
<p>
Philip Hazel
<br/>
Retired from University Computing Service
<br/>
Cambridge, England.
<br/>
</p>
<h2 id="SEC3">
REVISION
</h2>
<p>
Last updated: 28 February 2025
<br/>
Copyright © 1997-2016 University of Cambridge.
<br/>
</p>

</div>
