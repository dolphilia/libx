---
title: "Matching Algorithms"
description: "Fixed PCRE2 10.49 original manual, with a paired Japanese translation."
documentId: "pcre2:10.49:pcre2matching"
licenseSource: pcre2-manual
---

<div class="pcre2-original-content">




<h2 id="SEC1">PCRE2 MATCHING ALGORITHMS</h2>
<p>
This document describes the two different algorithms that are available in
PCRE2 for matching a compiled regular expression against a given subject
string. The "standard" algorithm is the one provided by the <b>pcre2_match()</b>
function. This works in the same way as Perl's matching function, and provides a
Perl-compatible matching operation. The just-in-time (JIT) optimization that is
described in the
<a href="/docs/pcre2/source/v10-49/html/pcre2jit.html"><b>pcre2jit</b></a>
documentation is compatible with this function.
</p>
<p>
An alternative algorithm is provided by the <b>pcre2_dfa_match()</b> function;
it operates in a different way, and is not Perl-compatible. This alternative
has advantages and disadvantages compared with the standard algorithm, and
these are described below.
</p>
<p>
When there is only one possible way in which a given subject string can match a
pattern, the two algorithms give the same answer. A difference arises, however,
when there are multiple possibilities. For example, if the anchored pattern
</p><pre><code>  ^&lt;.*&gt;&#10;</code></pre><p>
is matched against the string
</p><pre><code>  &lt;something&gt; &lt;something else&gt; &lt;something further&gt;&#10;</code></pre><p>
there are three possible answers. The standard algorithm finds only one of
them, whereas the alternative algorithm finds all three.
</p><p></p>
<h2 id="SEC2">REGULAR EXPRESSIONS AS TREES</h2>
<p>
The set of strings that are matched by a regular expression can be represented
as a tree structure. An unlimited repetition in the pattern makes the tree of
infinite size, but it is still a tree. Matching the pattern to a given subject
string (from a given starting point) can be thought of as a search of the tree.
There are two ways to search a tree: depth-first and breadth-first, and these
correspond to the two matching algorithms provided by PCRE2.
</p>
<h2 id="SEC3">THE STANDARD MATCHING ALGORITHM</h2>
<p>
In the terminology of Jeffrey Friedl's book "Mastering Regular Expressions",
the standard algorithm is an "NFA algorithm". It conducts a depth-first search
of the pattern tree. That is, it proceeds along a single path through the tree,
checking that the subject matches what is required. When there is a mismatch,
the algorithm tries any alternatives at the current point, and if they all
fail, it backs up to the previous branch point in the tree, and tries the next
alternative branch at that level. This often involves backing up (moving to the
left) in the subject string as well. The order in which repetition branches are
tried is controlled by the greedy or ungreedy nature of the quantifier.
</p>
<p>
If a leaf node is reached, a matching string has been found, and at that point
the algorithm stops. Thus, if there is more than one possible match, this
algorithm returns the first one that it finds. Whether this is the shortest,
the longest, or some intermediate length depends on the way the alternations
and the greedy or ungreedy repetition quantifiers are specified in the
pattern.
</p>
<p>
Because it ends up with a single path through the tree, it is relatively
straightforward for this algorithm to keep track of the substrings that are
matched by portions of the pattern in parentheses. This provides support for
capturing parentheses and backreferences.
</p>
<h2 id="SEC4">THE ALTERNATIVE MATCHING ALGORITHM</h2>
<p>
This algorithm conducts a breadth-first search of the tree. Starting from the
first matching point in the subject, it scans the subject string from left to
right, once, character by character, and as it does this, it remembers all the
paths through the tree that represent valid matches. In Friedl's terminology,
this is a kind of "DFA algorithm", though it is not implemented as a
traditional finite state machine (it keeps multiple states active
simultaneously).
</p>
<p>
Although the general principle of this matching algorithm is that it scans the
subject string only once, without backtracking, there is one exception: when a
lookaround assertion is encountered, the characters following or preceding the
current point have to be independently inspected.
</p>
<p>
The scan continues until either the end of the subject is reached, or there are
no more unterminated paths. At this point, terminated paths represent the
different matching possibilities (if there are none, the match has failed).
Thus, if there is more than one possible match, this algorithm finds all of
them, and in particular, it finds the longest. The matches are returned in
the output vector in decreasing order of length. There is an option to stop the
algorithm after the first match (which is necessarily the shortest) is found.
</p>
<p>
Note that the size of vector needed to contain all the results depends on the
number of simultaneous matches, not on the number of capturing parentheses in
the pattern. Using <b>pcre2_match_data_create_from_pattern()</b> to create the
match data block is therefore not advisable when doing DFA matching.
</p>
<p>
Note also that all the matches that are found start at the same point in the
subject. If the pattern
</p><pre><code>  cat(er(pillar)?)?&#10;</code></pre><p>
is matched against the string "the caterpillar catchment", the result is the
three strings "caterpillar", "cater", and "cat" that start at the fifth
character of the subject. The algorithm does not automatically move on to find
matches that start at later positions.
</p><p></p>
<p>
PCRE2's "auto-possessification" optimization usually applies to character
repeats at the end of a pattern (as well as internally). For example, the
pattern "a\d+" is compiled as if it were "a\d++" because there is no point
even considering the possibility of backtracking into the repeated digits. For
DFA matching, this means that only one possible match is found. If you really
do want multiple matches in such cases, either use an ungreedy repeat
("a\d+?") or set the PCRE2_NO_AUTO_POSSESS option when compiling.
</p>
<p>
There are a number of features of PCRE2 regular expressions that are not
supported or behave differently in the alternative matching function. Those
that are not supported cause an error if encountered.
</p>
<p>
1. Because the algorithm finds all possible matches, the greedy or ungreedy
nature of repetition quantifiers is not relevant (though it may affect
auto-possessification, as just described). During matching, greedy and ungreedy
quantifiers are treated in exactly the same way. However, possessive
quantifiers can make a difference when what follows could also match what is
quantified, for example in a pattern like this:
</p><pre><code>  ^a++\w!&#10;</code></pre><p>
This pattern matches "aaab!" but not "aaa!", which would be matched by a
non-possessive quantifier. Similarly, if an atomic group is present, it is
matched as if it were a standalone pattern at the current point, and the
longest match is then "locked in" for the rest of the overall pattern.
</p><p></p>
<p>
2. When dealing with multiple paths through the tree simultaneously, it is not
straightforward to keep track of captured substrings for the different matching
possibilities, and PCRE2's implementation of this algorithm does not attempt to
do this. This means that no captured substrings are available.
</p>
<p>
3. Because no substrings are captured, a number of related features are not
available:
<br/>
<br/>
(a) Backreferences;
<br/>
<br/>
(b) Conditional expressions that use a backreference as the condition or test
for a specific group recursion;
<br/>
<br/>
(c) Script runs;
<br/>
<br/>
(d) Scan substring assertions.
</p>
<p>
4. Because many paths through the tree may be active, the \K escape sequence,
which resets the start of the match when encountered (but may be on some paths
and not on others), is not supported.
</p>
<p>
5. Callouts are supported, but the value of the <i>capture_top</i> field is
always 1, and the value of the <i>capture_last</i> field is always 0.
</p>
<p>
6. The \C escape sequence, which (in the standard algorithm) always matches a
single code unit, even in a UTF mode, is not supported in UTF modes because
the alternative algorithm moves through the subject string one character (not
code unit) at a time, for all active paths through the tree.
</p>
<p>
7. Except for (*FAIL), the backtracking control verbs such as (*PRUNE) are not
supported. (*FAIL) is supported, and behaves like a failing negative assertion.
</p>
<p>
8. The PCRE2_MATCH_INVALID_UTF option for <b>pcre2_compile()</b> is not
supported by <b>pcre2_dfa_match()</b>.
</p>
<h2 id="SEC5">ADVANTAGES OF THE ALTERNATIVE ALGORITHM</h2>
<p>
The main advantage of the alternative algorithm is that all possible matches
(at a single point in the subject) are automatically found, and in particular,
the longest match is found. To find more than one match at the same point using
the standard algorithm, you have to do kludgy things with callouts.
</p>
<p>
Partial matching is possible with this algorithm, though it has some
limitations. The
<a href="/docs/pcre2/source/v10-49/html/pcre2partial.html"><b>pcre2partial</b></a>
documentation gives details of partial matching and discusses multi-segment
matching.
</p>
<h2 id="SEC6">DISADVANTAGES OF THE ALTERNATIVE ALGORITHM</h2>
<p>
The alternative algorithm suffers from a number of disadvantages:
</p>
<p>
1. It is substantially slower than the standard algorithm. This is partly
because it has to search for all possible matches, but is also because it is
less susceptible to optimization.
</p>
<p>
2. Capturing parentheses and other features such as backreferences that rely on
them are not supported.
</p>
<p>
3. Matching within invalid UTF strings is not supported.
</p>
<p>
4. Although atomic groups are supported, their use does not provide the
performance advantage that it does for the standard algorithm.
</p>
<p>
5. JIT optimization is not supported.
</p>
<h2 id="SEC7">AUTHOR</h2>
<p>
Philip Hazel
<br/>
Retired from University Computing Service
<br/>
Cambridge, England.
<br/>
</p>
<h2 id="SEC8">REVISION</h2>
<p>
Last updated: 22 February 2025
<br/>
Copyright © 1997-2024 University of Cambridge.
<br/>
</p>

</div>
