---
title: "Size and Other Limitations"
description: "Fixed PCRE2 10.49 original manual, with a paired Japanese translation."
documentId: "pcre2:10.49:pcre2limits"
licenseSource: pcre2-manual
---

<div class="pcre2-original-content">



<h2 id="SEC1">
SIZE AND OTHER LIMITATIONS
</h2>
<p>
There are some size limitations in PCRE2 but it is hoped that they will never
in practice be relevant.
</p>
<p>
The maximum size of a compiled pattern is approximately 64 thousand code units
for the 8-bit and 16-bit libraries if PCRE2 is compiled with the default
internal linkage size, which is 2 bytes for these libraries. If you want to
process regular expressions that are truly enormous, you can compile PCRE2 with
an internal linkage size of 3 or 4 (when building the 16-bit library, 3 is
rounded up to 4). See the <b>README</b> file in the source distribution and the
<a href="/docs/pcre2/source/v10-49/html/pcre2build.html"><b>pcre2build</b></a>
documentation for details. In these cases the limit is substantially larger.
However, the speed of execution is slower. In the 32-bit library, the internal
linkage size is always 4.
</p>
<p>
The maximum length of a source pattern string is essentially unlimited; it is
the largest number a PCRE2_SIZE variable can hold. However, the program that
calls <b>pcre2_compile()</b> can specify a smaller limit.
</p>
<p>
The maximum length (in code units) of a subject string is one less than the
largest number a PCRE2_SIZE variable can hold. PCRE2_SIZE is an unsigned
integer type, usually defined as size_t. Its maximum value (that is
~(PCRE2_SIZE)0) is reserved as a special indicator for zero-terminated strings
and unset offsets.
</p>
<p>
All values in repeating quantifiers must be less than 65536.
</p>
<p>
There are two different limits that apply to branches of lookbehind assertions.
If every branch in such an assertion matches a fixed number of characters,
the maximum length of any branch is 65535 characters. If any branch matches a
variable number of characters, then the maximum matching length for every
branch is limited. The default limit is set at compile time, defaulting to 255,
but can be changed by the calling program.
</p>
<p>
There is no limit to the number of parenthesized groups, but there can be no
more than 65535 capture groups, and there is a limit to the depth of nesting of
parenthesized subpatterns of all kinds. This is imposed in order to limit the
amount of system stack used at compile time. The default limit can be specified
when PCRE2 is built; if not, the default is set to 250. An application can
change this limit by calling pcre2_set_parens_nest_limit() to set the limit in
a compile context.
</p>
<p>
The maximum length of the name for a named capture group as well as the number
of such groups is configurable at build time. The maximum length for the name
defaults to
128 code units, and the maximum number of such groups to
10000.
</p>
<p>
The maximum length of a name in a (*MARK), (*PRUNE), (*SKIP), or (*THEN) verb
is 255 code units for the 8-bit library and 65535 code units for the 16-bit and
32-bit libraries.
</p>
<p>
The maximum length of a string argument to a callout is the largest number a
32-bit unsigned integer can hold.
</p>
<p>
The maximum amount of heap memory used for matching is controlled by the heap
limit, which can be set in a pattern or in a match context. The default is a
very large number, effectively unlimited.
</p>
<h2 id="SEC2">
AUTHOR
</h2>
<p>
Philip Hazel
<br/>
Retired from University Computing Service
<br/>
Cambridge, England.
<br/>
</p>
<h2 id="SEC3">
REVISION
</h2>
<p>
Last updated: 03 September 2025
<br/>
Copyright © 1997-2023 University of Cambridge.
<br/>
</p>

</div>
